# API и вебхуки

Панель отдаёт данные по HTTP в формате JSON. Так подключаются внешние системы: amoCRM, виджет на сайте, отчёты.
Есть два направления:

1. **Запросы к панели** — внешняя система приходит с ключом API и читает или создаёт брони.
2. **Вебхуки** — панель сама сообщает внешней системе о событиях с бронями.

Всё настраивается в панели, вкладка **Интеграции** (только у главного).

## 1. Ключи API

Создайте ключ на вкладке «Интеграции». Он показывается один раз; в базе хранится только его хэш.
Есть два уровня доступа:

| Доступ | Что можно |
|---|---|
| Только чтение | Календарь, брони, квартиры, заезды, поиск, доход. С контактами гостей и суммами |
| Чтение и запись | То же + создавать и менять брони и удержания, цены и ограничения, заметки |

Ключ **не** видит пользователей, журнал и настройки Channex, не создаёт другие ключи и не меняет пароли.
Отозванный ключ перестаёт работать сразу.

Ключ передают в заголовке:

```
Authorization: Bearer pms_0123…
```

Если заголовок есть, но ключ неверный, ответ `401`; вход по cookie в этом случае не используется.
Запросы идут на адрес панели, например `https://pms.as1.es/api/...`. Тело запросов — JSON (`Content-Type: application/json`),
ошибки приходят как `{"error": "текст"}` со статусом 400, 403, 404 или 409 (даты заняты).

### Основные запросы

| Запрос | Что делает |
|---|---|
| `GET /api/properties` | Квартиры |
| `GET /api/calendar?from=2026-12-01&days=30` | Квартиры, брони и цены по дням (7–120 дней) |
| `GET /api/bookings?from=&to=&status=&payment=&source=&property_id=&amo_lead_id=&q=` | Список броней; период — по дате заезда. `status`: `confirmed`, `inquiry`, `cancelled`; `payment`: `unpaid`, `partial`, `paid` |
| `GET /api/bookings/123` | Одна бронь |
| `GET /api/agenda?from=&to=` | Заезды и выезды за период |
| `GET /api/search?q=` | Поиск по гостю, телефону, почте, номеру брони |
| `POST /api/quote` | Цена и свободно ли: `{"property_ids":[1],"check_in":"2026-12-01","check_out":"2026-12-04"}` |
| `POST /api/bookings` | Создать бронь (см. ниже) |
| `PUT /api/bookings/123` | Изменить бронь |
| `POST /api/bookings/123/confirm` | Запрос → подтверждённая бронь |
| `POST /api/bookings/123/cancel` | Отменить |
| `POST /api/bookings/123/payment` | `{"payment_status":"paid"}` или `{"payment_status":"partial","paid_amount":100}` |
| `POST /api/bookings/123/checkin` | Отметить заселение |
| `PUT /api/daily` | Цены и ограничения по дням (нужен доступ «Чтение и запись») |
| `GET /api/report?month=2026-12` | Доход за месяц |

Пример: создать запрос на бронь.

```bash
curl -X POST https://pms.as1.es/api/bookings \
  -H "Authorization: Bearer pms_…" -H "Content-Type: application/json" \
  -d '{"property_id": 7, "check_in": "2027-01-10", "check_out": "2027-01-13",
       "guest_name": "Anna", "guest_phone": "+34600111222", "source": "Сайт",
       "status": "inquiry", "total": 450, "amo_lead_id": 12345678}'
```

Поля брони: `property_id`, `check_in`, `check_out`, `status` (`confirmed` или `inquiry`), `guest_name`, `guest_email`, `guest_phone`,
`adults`, `children`, `source`, `total`, `price_accommodation`, `price_cleaning`, `price_extra`, `payment_status`, `paid_amount`,
`check_in_time`, `check_out_time`, `notes`, `tags`, `color`, `amo_lead_id`.

`amo_lead_id` — номер сделки в amoCRM. По нему внешняя система находит бронь (`GET /api/bookings?amo_lead_id=…`), а панель отдаёт его в вебхуках.
Бронь из Booking.com или Airbnb можно привязать к сделке так же: `PUT /api/bookings/123` с `{"amo_lead_id": …}`.

## 2. Вебхуки

Добавьте адрес на вкладке «Интеграции»: название, адрес `https://…` и события. Панель покажет **секрет** — один раз.
Адрес должен быть публичным https (localhost и внутренние сети не принимаются); перенаправления не выполняются.

### События

| Событие | Когда |
|---|---|
| `booking.created` | Новая бронь или запрос: из панели, по API, из Booking.com или Airbnb; удержание, оформленное в бронь |
| `booking.confirmed` | Запрос подтверждён |
| `booking.updated` | Изменены гость, даты, квартира, суммы и т. п. (в том числе изменение в канале) |
| `booking.cancelled` | Бронь или запрос отменены (в том числе в канале) |
| `booking.payment` | Изменён статус или сумма оплаты |
| `booking.checked_in` | Гость заселён |
| `ping` | Проверка связи: кнопка «Проверить» |

Блокировки дат (ремонт, владелец) событий не создают.

### Что приходит

`POST` на ваш адрес, тело — JSON:

```json
{
  "id": "6f1c0c3e-…",
  "event": "booking.created",
  "created_at": "2026-12-01T10:15:00.000Z",
  "data": {
    "booking": {
      "id": 123, "status": "confirmed", "source": "Booking.com", "from_channel": true, "ota_code": "123456",
      "property_id": 7, "property_name": "2.1 Cristina 109",
      "guest_name": "Anna Ivanova", "guest_email": "…", "guest_phone": "+34…",
      "check_in": "2027-01-10", "check_out": "2027-01-13", "check_in_time": "16:00", "check_out_time": "11:00", "nights": 3,
      "adults": 2, "children": 0, "total": 450, "currency": "EUR",
      "payment_status": "unpaid", "paid_amount": null, "checked_in": false,
      "notes": "", "amo_lead_id": null, "created_at": "…", "updated_at": "…"
    }
  }
}
```

Заголовки: `X-PMS-Event`, `X-PMS-Delivery` (номер отправки), `X-PMS-Timestamp` (секунды), `X-PMS-Signature`.

### Проверка подписи

Подпись — HMAC-SHA256 от строки `<X-PMS-Timestamp>.<тело запроса как есть>` с вашим секретом, в hex, с префиксом `sha256=`.
Проверяйте по сырому телу, до разбора JSON, и отклоняйте запросы со старой отметкой времени (например, старше 5 минут).

```js
import { createHmac, timingSafeEqual } from 'node:crypto';
function valid(secret, headers, rawBody) {
  const want = 'sha256=' + createHmac('sha256', secret).update(`${headers['x-pms-timestamp']}.${rawBody}`).digest('hex');
  const got = headers['x-pms-signature'] || '';
  return got.length === want.length && timingSafeEqual(Buffer.from(got), Buffer.from(want))
    && Math.abs(Date.now() / 1000 - Number(headers['x-pms-timestamp'])) < 300;
}
```

### Доставка

- Успех — любой ответ `2xx` в течение 10 секунд. Ответьте быстро, обрабатывайте после.
- Иначе отправка повторяется через 1 мин, 5 мин, 15 мин, 1 ч, 3 ч, 6 ч, 12 ч (всего 8 попыток), затем событие помечается «не доставлено».
  В «Журнале» вебхука есть кнопка «Отправить неудавшиеся заново».
- Доставка «минимум один раз»: возможны повторы и, при сбоях, другой порядок. Отличайте повторы по полю `id` события; актуальность — по `data.booking.updated_at` или повторным запросом `GET /api/bookings/{id}`.
- Событие записывается в очередь в той же операции, что и изменение брони, поэтому при перезапуске сервера не теряется.
