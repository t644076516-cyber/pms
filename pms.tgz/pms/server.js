import { randomBytes } from 'node:crypto';
import { dirname, join } from 'node:path';
import { openDb, getSetting, setSetting } from './lib/db.js';
import { ChannexClient } from './lib/channex.js';
import { Sync } from './lib/sync.js';
import { createApp, channexCallbackUrl, channexConfig } from './lib/app.js';
import { ensureChief } from './lib/auth.js';
import { startWebhooks } from './lib/webhooks.js';
import { scheduleBackups } from './lib/backup.js';
import { today } from './lib/dates.js';

const dbPath = process.env.DB_PATH || './data/pms.db';
const db = openDb(dbPath);
const client = new ChannexClient(() => channexConfig(db));
const sync = new Sync(db, client);

// Первый запуск: создаём главного пользователя. Дальше остальных добавляет он сам в интерфейсе.
const hasUsers = db.prepare('SELECT COUNT(*) n FROM users').get().n > 0;
if (!hasUsers) {
  const password = process.env.ADMIN_PASSWORD;
  if (!password) {
    console.error('Пользователей ещё нет. Задайте ADMIN_PASSWORD (не короче 8 символов): из него создастся главный пользователь.');
    process.exit(1);
  }
  ensureChief(db, process.env.ADMIN_USER || 'admin', password);
  console.log(`Создан главный пользователь «${process.env.ADMIN_USER || 'admin'}». Дальше ADMIN_PASSWORD можно убрать из настроек.`);
}

// Секрет вебхука Channex создаётся один раз и хранится в базе
let webhookSecret = process.env.WEBHOOK_SECRET || getSetting(db, 'webhook_secret');
if (!webhookSecret) {
  webhookSecret = randomBytes(24).toString('hex');
  setSetting(db, 'webhook_secret', webhookSecret);
}

// Фото квартир — в папке photos рядом с базой (в Docker это /data/photos, входит в резервные копии сервера).
const photosDir = process.env.PHOTOS_DIR || join(dirname(dbPath), 'photos');
const app = createApp({ db, client, sync, webhookSecret, publicUrl: process.env.PUBLIC_URL || '', photosDir });

const port = Number(process.env.PORT) || 3000;
app.listen(port, () => {
  console.log(`PMS запущена на порту ${port}`);
  if (!process.env.PUBLIC_URL) console.log('PUBLIC_URL не задан: адрес для вебхука Channex возьмётся из окна настроек Channex; до тех пор брони забираются опросом раз в минуту.');
});

sync.start();
startWebhooks(db);
// вебхук Channex на брони: создать или поправить адрес (если известен адрес сервиса и задан ключ)
const callbackUrl = channexCallbackUrl(db, process.env.PUBLIC_URL || '', webhookSecret);
if (callbackUrl) setTimeout(() => sync.ensureWebhook(callbackUrl).catch((e) => sync.log('webhook', null, false, e.message)), 5000).unref?.();

// Копия базы каждый день после 04:00, хранится 14 последних (BACKUP_DIR, по умолчанию рядом с базой).
const tz = process.env.TZ_NAME || 'Atlantic/Canary';
scheduleBackups(db, {
  dir: process.env.BACKUP_DIR || join(dirname(dbPath), 'backups'),
  keep: Number(process.env.BACKUP_KEEP) || 14,
  today: () => today(tz),
  hourNow: () => Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: tz }).format(new Date())),
});
