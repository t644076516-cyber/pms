# Channex integration — certification notes

PMS for vacation rentals (Tenerife). Every apartment is one physical unit. All ARI changes are made by staff in the PMS
interface; there is no certification-specific code, script or UI.

## How it works

| Part | Where | What it does |
|---|---|---|
| Change capture | `lib/core.js` — `enqueue()`, called from `applyDaily()` / `setDailyBatch()` (rates and restrictions), booking create / update / move / cancel, base price change | Writes an `outbox` row (dates + changed fields) **in the same DB transaction** as the change. Nothing polls the domain tables. |
| Outbox | table `outbox` (`lib/db.js`) | Pending changes. HTTP handlers never call Channex for ARI. |
| Worker | `lib/sync.js` — `Sync.processOutbox()` | Woken by the outbox write (`setOutboxSink` → `kick()`, 2-second debounce to merge neighbouring edits). Groups pending rows per Channex property, reads the current state, compresses dates to ranges and sends **one** `POST /availability` and **one** `POST /restrictions` per Channex property, for all its rooms. Only fields that changed are sent. |
| Rate limits | `lib/sync.js` — `Limiter` | Per Channex property: max 8 availability + 8 restrictions calls per rolling minute (Channex: 10 + 10). 429 → pause the property for max(60 s, Retry-After); 5xx or network error → pause 1, 2, 5, 10, 30 min. Rows stay `pending` and are merged into the next call. A 20-second timer only retries paused rows. |
| Full sync | `lib/sync.js` — `fullSyncGroup()` | 2 calls per Channex property (availability of all rooms, restrictions of all rate plans) over the property horizon (`settings.state_length`, 730 days). Only when an apartment is linked, on the “Full sync” button, and once a day at 03:00 Atlantic/Canary with a 3-second gap between properties. |
| Bookings | `lib/sync.js` — `pollFeed()`, `ensureWebhook()`; `lib/core.js` — `applyRevision()` | Webhook (`event_mask: booking`, global, per-property fallback) → `GET /booking_revisions/feed` → apply → `POST /booking_revisions/:id/ack` for every revision. Feed polled every 60 s as a fallback. After a modification or cancellation the PMS pushes availability itself. A revision for a room that is not mapped to an apartment is acknowledged and parked in “Bookings without an apartment” (`channex_inbox`) until it is mapped. |
| Mapping | `properties.channex_property_id`, `channex_room_type_id`, `channex_rate_plan_id` | One apartment = one room type (1 unit) with one rate plan. Several apartments can be rooms of one Channex property. Created from the PMS (`POST /properties` with `property_type: apartment`, `timezone`, `settings.state_length: 730`, `settings.min_stay_type: arrival`; `POST /room_types`; `POST /rate_plans`) or linked to existing ones. |
| Task IDs | `sync_log.task_id` | Shown in the PMS: Channels (Channex) → Exchange with Channex, with a copy button. |

## Pre-flight answers

- **Does a price save emit a DB change your integration observes?** Yes. `lib/core.js` `applyDaily()` writes `daily` and `outbox` in one transaction and wakes the worker.
- **Is there an outbox between the PMS and the Channex client?** Yes. Table `outbox`, processed only by `Sync.processOutbox()` in `lib/sync.js`.
- **On a 429, does retry logic back off instead of dropping the update?** Yes. `Limiter.backoff()` in `lib/sync.js`; the rows stay pending.
- **Where is `POST /availability` called from?** `lib/sync.js`: `processOutbox()` (changes) and `fullSyncGroup()` (full sync).
- **Would the PMS still push correctly if all certification test code were deleted?** Yes. There is no certification code in the PMS; the automated tests (kept outside the deployed package) only drive the production HTTP API against a mock Channex.

## Answers for the form (extra notes)

- **Min stay:** Min Stay Arrival only (`min_stay_arrival`). Min Stay Through is not used.
- **Restrictions:** rate, min stay arrival, max stay, stop sell, closed to arrival, closed to departure — all supported.
- **Room types and rate plans:** multiple room types per property — yes (each apartment is a room type with 1 unit; several apartments can be rooms of one Channex property). One rate plan per room type; additional OTA rates (e.g. B&B, non-refundable) can be set up as derived rate plans in Channex.
- **Credit cards:** not needed; the PMS does not receive or store card details. Not PCI certified, no PCI service needed.
- **Rate limits:** yes — queue and limiter, at most 8 + 8 calls per property per minute, backoff on 429 / 5xx.
- **Update logic:** yes — only changes are sent; full sync only when linking, by button, and at most once per 24 hours at night.

## Adaptation of the test scenarios (single-unit vacation rentals)

- **Setup:** Channex property “Test Property - …” in USD created from the PMS, with two rooms (apartments) “Twin Room” and “Double Room”, occupancy 2, one rate plan each (“Best Available Rate”, default 100).
- **Test 1:** full sync covers 730 days (the property horizon), not 500.
- **Tests 3–8:** rows for “Bed & Breakfast Rate” are entered on the single rate plan of the same room. Where a B&B row overlaps a Best Available Rate row of the same room (tests 4 and 7), the wider B&B row is entered first and the BAR row after it, so BAR values win on the overlapping dates. All rows of a test are entered as one batch (“Batch of changes”) → one API call.
- **Tests 9–10:** every room is one physical unit, so availability is 0 or 1 and comes from bookings and blocks (owner stay, maintenance) — it is not typed in. Values 7 / 3 / 4 cannot occur. Closing dates: a booking or a block; reopening: cancelling it. One call per action.
- **Test 11:** bookings come through `booking_revisions` and are acknowledged; webhook used.
