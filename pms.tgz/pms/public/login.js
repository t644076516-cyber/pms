import { LANG, LANGS, setUiLang, startI18n } from './i18n.js';

startI18n();
// выбор языка прямо на странице входа
const langs = document.getElementById('langs');
langs.innerHTML = Object.entries(LANGS).map(([k, v]) => `<a href="#" data-l="${k}"${k === LANG ? ' class="on"' : ''}>${v}</a>`).join('');
langs.addEventListener('click', (e) => {
  const a = e.target.closest('[data-l]');
  if (!a) return;
  e.preventDefault();
  setUiLang(a.dataset.l);
});

document.getElementById('f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = document.getElementById('err');
  err.textContent = '';
  try {
    const r = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ login: document.getElementById('login').value, password: document.getElementById('pw').value }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Не удалось войти');
    // у пользователя сохранён свой язык — он и будет в панели
    if (data.user?.lang) setUiLang(data.user.lang, false);
    location.href = '/';
  } catch (ex) {
    err.textContent = ex.message;
  }
});
