// Язык интерфейса.
//
// Тексты в коде написаны по-русски. Для другого языка их переводит словарь lang/<язык>.js:
// точные фразы (exact) и шаблоны для фраз с числами и именами (patterns). Перевод применяется ко всему,
// что появляется на странице (текст, title, placeholder, aria-label), и к окнам confirm().
// Чего нет в словаре, остаётся по-русски и попадает в window.__i18n.missing — так видно, что дописать.
export const LANGS = { ru: 'Русский', en: 'English' };
const KEY = 'pms_lang';

function stored() {
  try { return localStorage.getItem(KEY) || ''; } catch { return ''; }
}
// По умолчанию — русский: английский включают на странице входа, в профиле или главный в карточке пользователя.
export const LANG = LANGS[stored()] ? stored() : 'ru';
export const LOCALE = LANG === 'en' ? 'en-GB' : 'ru-RU';
document.documentElement.lang = LANG;

const dict = LANG === 'ru' ? null : (await import(`./lang/${LANG}.js`)).default;
const exact = new Map();
if (dict) for (const [k, v] of Object.entries(dict.exact)) exact.set(norm(k), v);
const patterns = dict?.patterns || [];
const missing = new Set();
window.__i18n = { lang: LANG, missing };

// Запомнить язык на этом устройстве и перезагрузить страницу (переводы применяются при загрузке).
export function setUiLang(l, reload = true) {
  if (!LANGS[l]) return;
  try { localStorage.setItem(KEY, l); } catch { /* без памяти — по умолчанию русский */ }
  if (reload && l !== LANG) location.reload();
}
// Язык, выбранный пользователем на сервере: если отличается от текущего — переключиться.
export function applyUserLang(l) {
  if (LANGS[l] && l !== LANG) { setUiLang(l); return true; }
  if (LANGS[l]) setUiLang(l, false);
  return false;
}

const CYR = /[А-Яа-яЁё]/;
function norm(s) { return String(s).replace(/\s+/g, ' ').trim(); }
const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);
const low = (s) => (s ? s[0].toLowerCase() + s.slice(1) : s);

// Перевод одной фразы. Возвращает перевод или null.
function core(s, depth = 0) {
  if (!CYR.test(s)) return s;
  let v = exact.get(s);
  if (v !== undefined) return v;
  if (exact.has(low(s)) && low(s) !== s) return cap(exact.get(low(s)));
  if (exact.has(cap(s)) && cap(s) !== s) return low(exact.get(cap(s)));
  for (const [re, rep] of patterns) {
    const m = re.exec(s);
    if (m) return typeof rep === 'function' ? rep(m, tx) : s.replace(re, rep);
  }
  if (depth > 4) return null;
  // части через « · » и « — »: каждую по отдельности, данные (имена, суммы) остаются как есть
  for (const sep of [' · ', ' — ', ' – ', ' / ']) {
    if (!s.includes(sep)) continue;
    const parts = s.split(sep);
    const out = parts.map((p) => (p.trim() ? core(p.trim(), depth + 1) : p));
    if (out.some((x, i) => x !== null && x !== parts[i].trim() && CYR.test(parts[i]))) {
      out.forEach((x, i) => { if (x === null) missing.add(parts[i].trim()); }); // для отладки словаря
      return out.map((x, i) => (x === null ? parts[i] : x)).join(sep);
    }
  }
  // значки и знаки по краям: «🧹 Не готова», «⚠ …», «★ Обложка», «Готово ✓»
  const edge = /^([^0-9A-Za-zА-Яа-яЁё«"(]*)([\s\S]*?)([^0-9A-Za-zА-Яа-яЁё%€$»")\]]*)$/.exec(s);
  if (edge && (edge[1] || edge[3]) && edge[2] && edge[2] !== s) {
    v = core(edge[2], depth + 1);
    if (v !== null) return edge[1] + v + edge[3];
  }
  // «Подпись: значение»
  const ci = s.indexOf(': ');
  if (ci > 0) {
    const head = s.slice(0, ci);
    const rest = s.slice(ci + 2);
    const h = core(head + ':', depth + 1) ?? ((x) => (x === null ? null : x + ':'))(core(head, depth + 1));
    const r = core(rest, depth + 1);
    // переводится подпись (значение — данные) или хотя бы значение при подписи без кириллицы
    if (h !== null && (CYR.test(head) || r !== null)) return `${h} ${r ?? rest}`;
  }
  // перечисление через запятую — только если переводятся все части
  if (s.includes(', ')) {
    const out = s.split(', ').map((p) => core(p.trim(), depth + 1));
    if (out.every((x) => x !== null)) return out.join(', ');
  }
  return null;
}
// Перевод с сохранением пробелов по краям; для фраз из кода и сообщений сервера.
export function tx(s) {
  if (!dict || s == null) return s;
  const str = String(s);
  if (!CYR.test(str)) return str;
  const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(str);
  const key = norm(m[2]);
  const v = core(key);
  if (v === null) {
    missing.add(key);
    return str;
  }
  return m[1] + v + m[3];
}
// Строка с подстановками: t('Загружаю {i} из {n}…', { i, n }). Ключ — русский шаблон.
export function t(tpl, params = {}) {
  const s = dict ? exact.get(norm(tpl)) ?? tpl : tpl;
  return s.replace(/\{(\w+)\}/g, (_, k) => (params[k] ?? ''));
}
// Русское склонение по числу: plural(5, 'ночь', 'ночи', 'ночей'); для английского — по словарю.
export function plural(n, one, few, many) {
  if (dict) {
    const forms = dict.plurals?.[one];
    if (forms) return Math.abs(n) === 1 ? forms[0] : forms[1];
  }
  const a = Math.abs(n) % 100;
  const b = a % 10;
  return b === 1 && a !== 11 ? one : b >= 2 && b <= 4 && (a < 12 || a > 14) ? few : many;
}

// ---------- перевод страницы ----------
const ATTRS = ['title', 'placeholder', 'aria-label'];
// пользовательские данные и служебные поля не трогаем; у textarea — только текст (это значение), подсказки переводим
const SKIP_ATTR = 'code, pre, script, style, [translate="no"], .note, .lbcap';
const SKIP = `textarea, ${SKIP_ATTR}`;

function textNode(n) {
  const v = n.nodeValue;
  if (!v || !CYR.test(v)) return;
  const p = n.parentElement;
  if (!p || p.closest(SKIP)) return;
  const r = tx(v);
  if (r === v) return;
  // у <option> без value значением служит текст — сохраняем исходный, чтобы не сломать выбор
  if (p.tagName === 'OPTION' && !p.hasAttribute('value')) p.setAttribute('value', p.textContent);
  n.nodeValue = r;
}
function attr(el, name) {
  const v = el.getAttribute(name);
  if (!v || !CYR.test(v) || el.closest(SKIP_ATTR)) return;
  const r = tx(v);
  if (r !== v) el.setAttribute(name, r);
}
function tree(root) {
  if (root.nodeType === 3) return textNode(root);
  if (root.nodeType !== 1) return;
  for (const a of ATTRS) if (root.hasAttribute(a)) attr(root, a);
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    if (n.nodeType === 3) textNode(n);
    else for (const a of ATTRS) if (n.hasAttribute(a)) attr(n, a);
  }
}

export function startI18n() {
  if (!dict) return;
  document.title = tx(document.title);
  tree(document.body);
  new MutationObserver((list) => {
    for (const m of list) {
      if (m.type === 'childList') m.addedNodes.forEach(tree);
      else if (m.type === 'characterData') textNode(m.target);
      else if (m.type === 'attributes') attr(m.target, m.attributeName);
    }
  }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  // окна подтверждения
  const confirm0 = window.confirm.bind(window);
  window.confirm = (msg) => confirm0(tx(String(msg)));
}
