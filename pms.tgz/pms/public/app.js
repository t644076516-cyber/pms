// Шахматка — главная панель управления. Внешний вид по образцу AdvanceCM. Без библиотек.
import { LANG, LANGS, LOCALE, applyUserLang, plural, setUiLang, startI18n, tx } from './i18n.js';

startI18n(); // перевод интерфейса, если выбран не русский
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// ---------- иконки (контурные, 24×24) ----------
const ICONS = {
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  calcheck: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>',
  calpause: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M10 14v4M14 14v4"/>',
  calplus: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M12 13v6M9 16h6"/>',
  inbox: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M9 12h6M9 16h6"/>',
  dollar: '<circle cx="12" cy="12" r="10"/><path d="M15 9.2a3 3 0 0 0-2.6-1.5h-.9a2.3 2.3 0 0 0 0 4.6h1a2.3 2.3 0 0 1 0 4.6h-.9A3 3 0 0 1 9 15.4M12 6v1.7M12 16.9v1.7"/>',
  building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  tag: '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><path d="M7 7h.01"/>',
  percent: '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
  coin: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  book: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  refresh: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',
  filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5z"/>',
  filterx: '<path d="M13 3H2l8 9.5V19l4 2v-8.5l1-1.2M17 3l5 5M22 3l-5 5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  plusSq: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 8v8M8 12h8"/>',
  caret: '<path d="m6 9 6 6 6-6"/>',
  left: '<path d="m15 18-6-6 6-6"/>',
  right: '<path d="m9 18 6-6-6-6"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  child: '<circle cx="12" cy="5" r="2.5"/><path d="M9 21v-5H7.5L9 10h6l1.5 6H15v5"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  pencil: '<path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
  chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  note: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  printer: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  wallet: '<path d="M20 12V8H6a2 2 0 0 1 0-4h12v4M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
  ban: '<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
  unlock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  dots: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
  camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
};
const ic = (n, cls = '') => `<svg class="i${cls ? ' ' + cls : ''}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const LS = {
  get(k, d) { try { const v = localStorage.getItem('pms:' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('pms:' + k, JSON.stringify(v)); } catch { /* без памяти */ } },
};

const state = {
  view: 'cal', from: null, days: 42, data: null, perms: {}, me: null, roles: {}, holdTypes: {}, sources: [],
  pending: null, drag: null, sel: null, free: null, rangeMode: 'free', drawer: null, bm: null,
  page: 1, filter: { q: '', hidePrices: false, conflicts: false, notReady: false, tag: '' },
};
const P = () => state.perms;

// ---------- даты ----------
const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return fmt(d); };
const diffDays = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);
const todayStr = () => fmt(new Date());
const EN = LANG === 'en';
const MON_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONF_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WD = EN ? ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] : ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
const WDF = EN ? ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] : ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
const MON = EN ? MON_EN : ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MONS = EN ? MON_EN : ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MONF = EN ? MONF_EN : ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const MONN = EN ? MONF_EN : ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const short = (s) => { const d = parse(s); return `${d.getDate()} ${MON[d.getMonth()]}`; };
const dmy = (s) => { const d = parse(s); return `${pad(d.getDate())} ${MON[d.getMonth()]} ${d.getFullYear()}`; };
const longDay = (s) => { const d = parse(s); return `${WDF[d.getDay()]}, ${d.getDate()} ${MONF[d.getMonth()]}`; };
const nightsWord = (n) => plural(n, 'ночь', 'ночи', 'ночей');
const monthStart = (s) => `${s.slice(0, 7)}-01`;
const addMonths = (s, n) => { const d = parse(monthStart(s)); d.setMonth(d.getMonth() + n); return fmt(d); };
const monthEnd = (s) => addDays(addMonths(monthStart(s), 1), -1);
function fmtTs(ts) {
  if (!ts) return '—';
  const d = new Date(String(ts).replace(' ', 'T') + (String(ts).length <= 19 ? 'Z' : ''));
  if (Number.isNaN(d.getTime())) return String(ts);
  return `${pad(d.getDate())} ${MON[d.getMonth()]} ${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
const CUR = { EUR: '€', USD: '$', RUB: '₽', GBP: '£' };
const money = (n, cur = 'EUR') => (n == null || n === '' ? '' : `${new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 2 }).format(n)} ${CUR[cur] || cur}`);

// ---------- сеть ----------
async function api(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await r.json(); } catch { /* пустой ответ */ }
  if (r.status === 401) { location.href = '/login.html'; throw new Error('Нужен вход'); }
  if (!r.ok) throw new Error(data.error || `Ошибка ${r.status}`);
  return data;
}
function toast(msg, bad = false) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast' + (bad ? ' bad' : '');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.add('hidden'), bad ? 6000 : 3000);
}
async function copyText(text, msg = 'Скопировано') {
  try { await navigator.clipboard.writeText(text); } catch {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }
  toast(msg);
}

// ---------- внешний вид квартир и броней ----------
const PCOLORS = ['#b8d000', '#3f6fd1', '#ef9a3a', '#8ec5e8', '#9c6ade', '#12a398', '#e86fa5', '#a1887f', '#1f3a8a', '#7a8b2e'];
const BCOLORS = ['#7bd148', '#5484ed', '#a4bdfc', '#46d6db', '#7ae7bf', '#51b749', '#fbd75b', '#ffb878', '#ff887c', '#dc2127', '#dbadff', '#9e9e9e'];
const pColor = (p) => p?.color || PCOLORS[(p?.id || 0) % PCOLORS.length];
const thumbText = (name) => { const m = String(name || '').match(/^\s*(\d+(?:[.,]\d+)*)/); return m ? m[1] : String(name || '?').split(/\s+/).slice(0, 2).map((w) => w[0] || '').join('').toUpperCase(); };
const initial = (s) => (String(s || '').trim()[0] || '?').toUpperCase();
const HOLD_ICON = { repair: '🔧', owner: '🏠', tentative: '⏳', other: '⛔' };
const HOLD_NAMES = { repair: 'Ремонт', owner: 'Владелец', tentative: 'Держим для клиента', other: 'Другое' };
const holdName = (t) => state.holdTypes[t] || HOLD_NAMES[t] || 'Удержание';
function srcKind(b) {
  const s = (b.source || '').toLowerCase();
  if (s.includes('booking')) return 'booking';
  if (s.includes('airbnb')) return 'airbnb';
  if (s.includes('expedia')) return 'expedia';
  if (s.includes('vrbo') || s.includes('homeaway')) return 'vrbo';
  return 'direct';
}
function srcIcon(b) {
  if (b.kind === 'hold') return `<span class="ico k-hold" title="${esc(holdName(b.hold_type))}">${HOLD_ICON[b.hold_type] || '⛔'}</span>`;
  const k = srcKind(b);
  const t = { booking: 'B.', airbnb: 'A', expedia: 'E', vrbo: 'V' }[k];
  return `<span class="ico k-${k}" title="${esc(b.source || '')}">${t || esc(initial(tx(b.source || '•')))}</span>`;
}
const barLabel = (b) => (b.kind === 'hold' ? `${holdName(b.hold_type)}${b.title ? ': ' + b.title : ''}` : b.guest_name || b.source || 'Бронь');
const PAY_RU = { paid: 'Оплачено', partial: 'Частично', unpaid: 'Не оплачено' };
const STATUS_RU = { confirmed: 'Бронь', inquiry: 'Запрос', cancelled: 'Отменена' };
const payPill = (s) => (s ? `<span class="pill ${s}">${PAY_RU[s] || s}</span>` : '');
const expiresTxt = (ms) => { const l = timeLeft(ms); return l === 'истекает' ? l : `снимется через ${l}`; };
function timeLeft(ms) {
  const m = Math.round((ms - Date.now()) / 60000);
  if (m <= 0) return 'истекает';
  if (m < 60) return `${m} мин`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} ч` : `${Math.round(h / 24)} дн`;
}
const guestsTxt = (b) => (b.adults != null ? `${b.adults}${b.children ? ' + ' + b.children : ''}` : '—');
const cpy = (t) => `<button class="cpy" data-copy="${esc(t)}" title="Скопировать" aria-label="Скопировать">${ic('copy')}</button>`;

// ---------- каркас: левая панель, вкладки, нижняя панель ----------
const SIDE = [
  { view: 'cal', icon: 'calendar', label: 'Шахматка' },
  { view: 'agenda', icon: 'calcheck', label: 'Заезды' },
  { view: 'list', icon: 'inbox', label: 'Брони' },
  { view: 'report', icon: 'dollar', label: 'Доход', perm: 'money' },
];
const TABS = [
  { id: 'props', label: 'Квартиры', icon: 'building', color: '#fe8832', perm: 'properties', run: () => setView('props') },
  { id: 'prices', label: 'Цены и ограничения', icon: 'coin', color: '#957bff', perm: 'prices', run: () => openPriceDrawer({ property_ids: [], date_from: todayStr(), date_to: addDays(todayStr(), 29) }) },
  { id: 'channex', label: 'Каналы (Channex)', icon: 'layers', color: '#4580f5', perm: 'channex', run: () => openChannex() },
  { id: 'comm', label: 'Комиссии', icon: 'percent', color: '#66b749', perm: 'properties', run: () => openCommissions() },
  { id: 'sources', label: 'Источники', icon: 'tag', color: '#ea77f4', perm: 'properties', run: () => openSources() },
  { id: 'users', label: 'Пользователи', icon: 'users', color: '#1ab2a7', perm: 'users', run: () => openUsers() },
  { id: 'integr', label: 'Интеграции', icon: 'key', color: '#e8618c', perm: 'users', run: () => openIntegrations() },
  { id: 'audit', label: 'Журнал', icon: 'book', color: '#f989a4', perm: 'audit', run: () => openAudit() },
];
function initChrome() {
  const can = P();
  $('snav').innerHTML = SIDE.filter((s) => !s.perm || can[s.perm])
    .map((s) => `<button class="si${s.view === state.view ? ' on' : ''}" data-view="${s.view}" title="${s.label}" aria-label="${s.label}">${ic(s.icon)}</button>`).join('');
  $('bnav').innerHTML = SIDE.filter((s) => !s.perm || can[s.perm])
    .map((s) => `<button data-view="${s.view}"${s.view === state.view ? ' class="on"' : ''}>${ic(s.icon)}${s.label}</button>`).join('')
    + `<button data-me="1">${ic('user')}Профиль</button>`;
  const tabs = TABS.filter((t) => !t.perm || can[t.perm]);
  $('tabs').innerHTML = tabs.map((t) => `<button class="tab" data-tab="${t.id}" style="--tc:${t.color}">${ic(t.icon)}${t.label}</button>`).join('');
  $('tabs').hidden = !tabs.length;
  $('meBtn').textContent = initial(state.me.name);
  $('meBtn').title = `${state.me.name} · ${state.me.role_label}`;
  document.querySelectorAll('[data-i]').forEach((el) => { el.innerHTML = ic(el.dataset.i); });
  $('refreshBtn').innerHTML = ic('refresh');
  $('clearFilters').innerHTML = ic('filterx');
  $('plusBtn').innerHTML = ic('plus');
  $('plusBtn').hidden = !(can.edit_bookings || can.block || can.prices);
  $('addBtn').hidden = $('plusBtn').hidden;
  for (const id of ['yPrev', 'mPrev']) $(id).innerHTML = ic('left');
  for (const id of ['yNext', 'mNext']) $(id).innerHTML = ic('right');
  $('vswitchCal').innerHTML = vswitch('cal');
}
const vswitch = (cur) => [['cal', 'calendar', 'Шахматка'], ['agenda', 'calcheck', 'Заезды и выезды'], ['list', 'inbox', 'Брони']]
  .map(([v, i, t]) => `<button data-view="${v}" class="${v === cur ? 'on' : ''}" title="${t}" aria-label="${t}">${ic(i)}</button>`).join('');

document.addEventListener('click', (e) => {
  const v = e.target.closest('[data-view]');
  if (v && (v.closest('#snav') || v.closest('#bnav') || v.closest('.vswitch'))) return setView(v.dataset.view);
  const tb = e.target.closest('[data-tab]');
  if (tb) return TABS.find((t) => t.id === tb.dataset.tab)?.run();
  if (e.target.closest('[data-me]') || e.target.closest('#meBtn')) return openMeMenu(e.target.closest('button'));
});

// ---------- шахматка ----------
async function load() {
  state.data = await api('GET', `/api/calendar?from=${state.from}&days=${state.days}`);
  render();
}

function filtersActive() {
  const f = state.filter;
  return !!(f.hidePrices || f.conflicts || f.notReady || f.tag || f.q || state.free);
}
function visibleProps() {
  const { properties, bookings } = state.data;
  const f = state.filter;
  const fr = state.free;
  const q = f.q.trim().toLowerCase();
  return properties.filter((p) => {
    if (q && !p.name.toLowerCase().includes(q)) return false;
    if (f.tag && !(p.tags || '').split(',').map((s) => s.trim().toLowerCase()).includes(f.tag.toLowerCase())) return false;
    if (f.notReady && p.ready !== 0) return false;
    if (f.conflicts && !bookings.some((b) => b.property_id === p.id && b.conflict)) return false;
    if (fr && fr.only) {
      const m = fr.map.get(p.id);
      if (!m || (state.rangeMode === 'busy' ? m.free : !m.free)) return false;
    }
    return true;
  });
}

function render() {
  if (!state.data) return;
  const { bookings, daily } = state.data;
  const { from, days } = state;
  const can = P();
  const dailyMap = new Map(daily.map((d) => [`${d.property_id}|${d.date}`, d]));
  const t = todayStr();
  const fr = state.free;
  const inFree = (ds) => fr && ds >= fr.from && ds < fr.to;
  // все квартиры одним списком, без страниц
  const rows = visibleProps();

  let html = `<div class="grid${state.filter.hidePrices ? ' hideprices' : ''}"><div class="hrow">
    <div class="corner"><div class="csearch">${ic('search')}<input id="csq" type="search" placeholder="Поиск квартиры" value="${esc(state.filter.q)}" autocomplete="off" aria-label="Поиск квартиры"></div></div>
    <button class="navarrow l" data-shift="-7" title="Неделя назад" aria-label="Неделя назад">${ic('left')}</button>`;
  for (let i = 0; i < days; i++) {
    const ds = addDays(from, i);
    const d = parse(ds);
    const we = d.getDay() === 0 || d.getDay() === 6;
    html += `<div class="hd${we ? ' we' : ''}${ds === t ? ' today' : ''}${inFree(ds) ? ' frange' : ''}" data-h="${ds}">${d.getDate() === 1 || i === 0 ? `<span class="dm">${MONS[d.getMonth()]}</span>` : ''}<span class="dn">${WD[d.getDay()]}</span><span class="dd">${pad(d.getDate())}</span></div>`;
  }
  html += `<button class="navarrow r" data-shift="7" title="Неделя вперёд" aria-label="Неделя вперёд">${ic('right')}</button></div>`;

  for (const p of rows) {
    const list = bookings.filter((x) => x.property_id === p.id);
    const busy = new Set();
    const ends = new Set();
    for (const b of list) {
      if (b.status !== 'confirmed') continue;
      ends.add(b.check_out);
      for (let ds = b.check_in; ds < b.check_out; ds = addDays(ds, 1)) busy.add(ds);
    }
    const fq = fr?.map.get(p.id);
    const match = fq && (state.rangeMode === 'busy' ? !fq.free : fq.free);
    const dim = fr && !fr.only && fq && !match ? ' dim' : '';
    const chip = fr && fq
      ? fq.free
        ? `<button class="fchip" data-fbook="${p.id}" title="Оформить бронь на эти даты">${fq.total != null && can.money ? money(fq.total, p.currency) : 'свободно'}${fq.warnings.length ? ' ⚠' : ''}</button>`
        : '<span class="fchip busy">занято</span>'
      : '';
    html += `<div class="row${dim}" data-p="${p.id}" style="--pc:${esc(pColor(p))}"><div class="pcell" title="${esc(p.name)}${p.ready === 0 ? ' — не готова после выезда' : ''}">
      <div class="thumb">${esc(thumbText(p.name))}</div>
      <div class="pinfo"><div class="pn">${esc(p.name)}</div><div class="pm"><i class="st${p.ready === 0 ? ' no' : ''}" title="${p.ready === 0 ? 'Не готова после выезда' : 'Готова'}"></i>${p.max_guests ? `<span title="Макс. гостей">${ic('user')} ${p.max_guests}</span>` : ''}${p.ready === 0 ? '<span title="Нужна уборка">🧹</span>' : ''}</div></div>${chip}</div>`;
    for (let i = 0; i < days; i++) {
      const ds = addDays(from, i);
      const d = parse(ds);
      const we = d.getDay() === 0 || d.getDay() === 6;
      const dl = dailyMap.get(`${p.id}|${ds}`) || {};
      const price = dl.price != null ? dl.price : p.base_price;
      const minStay = dl.min_stay > 1 ? dl.min_stay : null;
      const occupied = busy.has(ds);
      const cls = ['cell', we ? 'we' : '', ds === t ? 'today' : '', dl.price != null ? 'custom' : '', dl.stop_sell ? 'stop' : '', dl.cta ? 'cta' : '', dl.ctd ? 'ctd' : '', inFree(ds) ? 'frange' : '', ds < t ? 'past' : '', !occupied && ends.has(ds) ? 'co' : ''];
      const tip = [dl.stop_sell ? 'продажи закрыты' : '', dl.cta ? 'заезд запрещён' : '', dl.ctd ? 'выезд запрещён' : '', minStay ? `мин. ${minStay} ноч.` : ''].filter(Boolean).join(', ');
      html += `<div class="${cls.filter(Boolean).join(' ')}" data-p="${p.id}" data-d="${ds}"${tip ? ` title="${tip}"` : ''}>${!occupied && can.money && price != null ? `<span class="pr">${CUR[p.currency] || ''}${Math.round(price)}</span>` : ''}${!occupied && minStay ? `<span class="ms">${minStay}</span>` : ''}</div>`;
    }
    html += barsFor(p, list);
    html += '</div>';
  }
  html += '</div>';
  if (!state.data.properties.length) html = `<div class="empty">Квартир пока нет.${can.properties ? ' Откройте вкладку «Квартиры» и добавьте первую.' : ''}</div>`;
  else if (!rows.length) html += `<div class="empty">${fr ? (state.rangeMode === 'busy' ? 'На эти даты занятых квартир нет.' : 'На эти даты свободных квартир нет.') : 'Ничего не найдено. Измените поиск или фильтры.'}</div>`;

  const sc = $('cscroll');
  const keepFocus = document.activeElement?.id === 'csq';
  const caret = keepFocus ? document.activeElement.selectionStart : 0;
  const { scrollTop, scrollLeft } = sc;
  sc.innerHTML = html;
  sc.scrollTop = scrollTop;
  sc.scrollLeft = scrollLeft;
  if (keepFocus && $('csq')) { $('csq').focus(); $('csq').setSelectionRange(caret, caret); }
  updateToolbar();
  paintSelection();
}

function barsFor(p, list) {
  const { from, days } = state;
  const can = P();
  const confirmed = list.filter((b) => b.status === 'confirmed');
  let html = '';
  for (const b of list) {
    const s = diffDays(from, b.check_in);
    const e = diffDays(from, b.check_out);
    if (e <= 0 || s >= days) continue;
    const clipL = s < 0;
    const clipR = e > days;
    // от середины дня заезда до середины дня выезда; срезанный край уходит под колонку квартир
    const x0 = clipL ? -1 : s + 0.5;
    const x1 = clipR ? days : e + 0.5;
    const cls = ['bar'];
    if (b.kind === 'hold') cls.push('hold', `hold-${b.hold_type || 'other'}`);
    if (b.status === 'inquiry') {
      cls.push('inquiry');
      if (confirmed.some((c) => c.check_in < b.check_out && c.check_out > b.check_in)) cls.push('low');
    }
    if (b.conflict) cls.push('conflict');
    if (b.color) cls.push('custom');
    let l1;
    let l2 = '';
    if (b.kind === 'hold') {
      l1 = barLabel(b);
      l2 = b.expires_at ? expiresTxt(b.expires_at) : `до ${short(b.check_out)}`;
    } else {
      l1 = `${b.conflict ? '⚠ ' : ''}${b.guest_name || 'Без имени'} (${b.source || '—'}) (${b.status === 'inquiry' ? 'запрос' : 'подтв.'}) – ${p.name}`;
      if (can.money && b.total != null) l2 = money(b.total, b.currency || p.currency);
    }
    const marks = [];
    if (b.kind === 'booking' && b.status === 'confirmed' && can.money && !b.from_channel && b.payment_status && b.payment_status !== 'paid') {
      marks.push(`<span class="mk-pay ${b.payment_status}" title="${b.payment_status === 'partial' ? 'Оплачено частично' : 'Не оплачено'}"></span>`);
    }
    if (b.checked_in) marks.push('<span title="Заселён">✓</span>');
    if (b.notes_count) marks.push(`<span title="Заметок: ${b.notes_count}">💬</span>`);
    const style = `left:calc(var(--name) + ${x0} * var(--w) + 2px);width:calc(${x1 - x0} * var(--w) - 4px)${b.color ? `;--bc:${esc(b.color)}` : ''}`;
    html += `<div class="${cls.join(' ')}" data-b="${b.id}" style="${style}"><div class="bin">${srcIcon(b)}<div class="bt"><div class="l1">${esc(l1)}</div>${l2 ? `<div class="l2">${esc(l2)}</div>` : ''}</div>${marks.length ? `<span class="marks">${marks.join('')}</span>` : ''}</div></div>`;
  }
  return html;
}

function pagerHtml(total, shown, page, per, pfx) {
  const pages = Math.max(1, Math.ceil(total / per));
  const lo = Math.max(1, Math.min(page - 2, pages - 4));
  const hi = Math.min(pages, lo + 4);
  const nums = [];
  for (let i = lo; i <= hi; i++) nums.push(i);
  const b = (pg, label, dis, on = false) => `<button data-${pfx}pg="${pg}"${dis ? ' disabled' : ''}${on ? ' class="on"' : ''}>${label}</button>`;
  return `<span>${shown} из ${total}</span><span class="grow"></span>
    <span class="ppl">На странице</span><select data-${pfx}per aria-label="Сколько на странице">${[10, 25, 50, 100].map((n) => `<option${n === per ? ' selected' : ''}>${n}</option>`).join('')}</select>
    <div class="pages">${b(1, '«', page === 1)}${b(page - 1, '‹', page === 1)}${nums.map((n) => b(n, n, false, n === page)).join('')}${b(page + 1, '›', page === pages)}${b(pages, '»', page === pages)}</div>`;
}

function updateToolbar() {
  const d = parse(state.from);
  $('yLabel').textContent = d.getFullYear();
  $('mLabel').textContent = MONS[d.getMonth()];
  $('modeFree').classList.toggle('on', state.rangeMode === 'free');
  $('modeBusy').classList.toggle('on', state.rangeMode === 'busy');
  const fr = state.free;
  $('rangeLabel').textContent = fr ? `${short(fr.from)} – ${short(fr.to)}` : 'Период';
  $('rangeBtn').classList.toggle('on', !!fr);
  const f = state.filter;
  $('fdot').hidden = !(f.hidePrices || f.conflicts || f.notReady || f.tag);
  renderFreeInfo();
}
function renderFreeInfo() {
  const fr = state.free;
  const box = $('freeinfo');
  if (!fr || !state.data) { box.hidden = true; return; }
  const total = state.data.properties.length;
  const n = state.data.properties.filter((p) => { const m = fr.map.get(p.id); return m && (state.rangeMode === 'busy' ? !m.free : m.free); }).length;
  const nights = diffDays(fr.from, fr.to);
  box.innerHTML = `<b>${state.rangeMode === 'busy' ? 'Занято' : 'Свободно'} ${n} из ${total}</b><span>${short(fr.from)} → ${short(fr.to)} · ${nights} ${nightsWord(nights)}${fr.guests ? ` · гостей: ${fr.guests}` : ''}</span>
    <label><input type="checkbox" id="frAll"${fr.only ? '' : ' checked'}> показать все квартиры</label>
    ${state.rangeMode === 'free' ? '<span class="muted">Нажмите на цену у квартиры — откроется бронь.</span>' : ''}
    <button id="frX" title="Сбросить даты" aria-label="Сбросить даты">✕</button>`;
  box.hidden = false;
  $('frAll').onchange = () => { fr.only = !$('frAll').checked; state.page = 1; render(); };
  $('frX').onclick = () => { state.free = null; render(); };
}

// поиск квартиры в углу шахматки
$('cscroll').addEventListener('input', (e) => {
  if (e.target.id !== 'csq') return;
  state.filter.q = e.target.value;
  state.page = 1;
  render();
});

// ---------- карточка при наведении на полосу ----------
let hoverTimer = null;
function hideHover() { clearTimeout(hoverTimer); $('hover').hidden = true; }
$('cscroll').addEventListener('pointerover', (e) => {
  if (e.pointerType !== 'mouse' || state.drag) return;
  const bar = e.target.closest('.bar');
  if (!bar) return;
  clearTimeout(hoverTimer);
  hoverTimer = setTimeout(() => showHover(bar, e.clientX), 280);
});
$('cscroll').addEventListener('pointerout', (e) => {
  const bar = e.target.closest('.bar');
  if (bar && !bar.contains(e.relatedTarget)) hideHover();
});
$('cscroll').addEventListener('scroll', hideHover, { passive: true });
function showHover(bar, x) {
  const b = state.data?.bookings.find((q) => q.id === Number(bar.dataset.b));
  if (!b || !bar.isConnected) return;
  const can = P();
  const p = state.data.properties.find((q) => q.id === b.property_id);
  const cur = b.currency || p?.currency || 'EUR';
  const nights = diffDays(b.check_in, b.check_out);
  const item = (icon, cls, label, value, w = '') => `<div class="hi${w}">${icon ? ic(icon, cls) : ''}<div><div class="il">${label}</div><div class="iv">${value}</div></div></div>`;
  let body;
  if (b.kind === 'hold') {
    body = `<div class="hh"><div class="hn">${srcIcon(b)}<span>${esc(barLabel(b))}</span></div>
      <div class="hs">${ic('moon')} ${nights}${b.expires_at ? ` · ${expiresTxt(b.expires_at)}` : ''}</div></div>
      <div class="hgrid">${item('calendar', 'c-pink', EN ? 'From' : 'С', dmy(b.check_in))}${item('calendar', 'c-pink', EN ? 'To' : 'До', dmy(b.check_out), ' w2')}
      ${item('user', 'c-green', 'Поставил(а)', esc(b.created_by_name || '—'), ' w3')}</div>`;
  } else {
    const due = b.total != null ? Math.max(0, b.total - (b.paid_amount || (b.payment_status === 'paid' ? b.total : 0))) : null;
    body = `<div class="hh"><div class="hn">${srcIcon(b)}<span>${esc(b.guest_name || 'Без имени')}</span></div>
      <div class="hs">${b.status === 'inquiry' ? '<span class="pill inquiry">Запрос</span>' : can.money ? payPill(b.payment_status) : ''}<span>${ic('moon')} ${nights}</span><span>${ic('user')} ${guestsTxt(b)}</span>${b.checked_in ? '<span class="pill in">Заселён</span>' : ''}</div></div>
      <div class="hgrid">${item('calendar', 'c-pink', 'Заезд', dmy(b.check_in))}${item('calendar', 'c-pink', 'Выезд', dmy(b.check_out), ' w2')}
      ${can.money && b.total != null ? `${item('wallet', 'c-orange', 'К оплате', money(due, cur))}${item('', '', 'Оплачено', money(b.paid_amount || (b.payment_status === 'paid' ? b.total : 0), cur))}${item('', '', 'Итого', money(b.total, cur))}` : ''}
      ${item('clock', 'c-green', 'Создано', esc(fmtTs(b.created_at)), ' w3')}</div>`;
  }
  const h = $('hover');
  h.innerHTML = body;
  h.hidden = false;
  const r = bar.getBoundingClientRect();
  const hr = h.getBoundingClientRect();
  const left = Math.max(8, Math.min(x - hr.width / 2, innerWidth - hr.width - 8));
  const top = r.top - hr.height - 8 > 8 ? r.top - hr.height - 8 : r.bottom + 8;
  h.style.left = `${left}px`;
  h.style.top = `${top}px`;
}

// ---------- выделение дат мышью или двумя касаниями ----------
function cellAt(x, y) {
  const el = document.elementFromPoint(x, y);
  return el?.closest?.('.cell') || null;
}
function paintSelection() {
  document.querySelectorAll('.cell.sel, .cell.start').forEach((c) => c.classList.remove('sel', 'start'));
  const r = state.drag || state.sel;
  if (r) {
    const [a, b] = r.d0 <= r.d1 ? [r.d0, r.d1] : [r.d1, r.d0];
    document.querySelectorAll(`.row[data-p="${r.pid}"] .cell`).forEach((c) => {
      if (c.dataset.d >= a && c.dataset.d <= b) c.classList.add('sel');
    });
  }
  if (state.pending) document.querySelector(`.row[data-p="${state.pending.pid}"] .cell[data-d="${state.pending.d}"]`)?.classList.add('start');
}
$('cscroll').addEventListener('pointerdown', (e) => {
  if (e.button !== 0 || e.target.closest('.bar, .fchip, .pcell, .corner, .navarrow')) return;
  const cell = e.target.closest('.cell');
  if (!cell) return;
  closePop();
  hideHover();
  state.drag = { pid: Number(cell.dataset.p), d0: cell.dataset.d, d1: cell.dataset.d, moved: false };
  paintSelection();
});
document.addEventListener('pointermove', (e) => {
  const dr = state.drag;
  if (!dr) return;
  const cell = cellAt(e.clientX, e.clientY);
  if (cell && Number(cell.dataset.p) === dr.pid && cell.dataset.d !== dr.d1) {
    dr.d1 = cell.dataset.d;
    dr.moved = true;
    paintSelection();
  }
});
document.addEventListener('pointercancel', () => { if (state.drag) { state.drag = null; paintSelection(); } });
document.addEventListener('pointerup', (e) => {
  const dr = state.drag;
  if (!dr) return;
  state.drag = null;
  let range;
  if (dr.moved && dr.d0 !== dr.d1) range = { pid: dr.pid, d0: dr.d0, d1: dr.d1 };
  else if (state.pending && state.pending.pid === dr.pid) range = { pid: dr.pid, d0: state.pending.d, d1: dr.d0 };
  if (!range) {
    state.pending = { pid: dr.pid, d: dr.d0 };
    paintSelection();
    toast('Заезд выбран. Нажмите последнюю ночь — или ту же дату для одной ночи');
    return;
  }
  state.pending = null;
  $('toast').classList.add('hidden');
  const [a, b] = range.d0 <= range.d1 ? [range.d0, range.d1] : [range.d1, range.d0];
  state.sel = { pid: range.pid, d0: a, d1: b, checkIn: a, checkOut: addDays(b, 1) };
  paintSelection();
  openSelectionPop(e.clientX, e.clientY);
});

// ---------- меню выделенных дат ----------
function closePop() { $('pop').hidden = true; $('pop').innerHTML = ''; }
function clearSel() { state.sel = null; state.pending = null; paintSelection(); }
function placeFixed(el, x, y) {
  const r = el.getBoundingClientRect();
  el.style.left = `${Math.max(8, Math.min(x, innerWidth - r.width - 8))}px`;
  el.style.top = `${Math.max(8, Math.min(y, innerHeight - r.height - 8))}px`;
}
async function openSelectionPop(x, y) {
  const s = state.sel;
  const p = state.data.properties.find((q) => q.id === s.pid);
  const nights = diffDays(s.checkIn, s.checkOut);
  const can = P();
  const items = [
    can.edit_bookings && ['book', 'calplus', 'Добавить бронь'],
    can.edit_bookings && ['inquiry', 'chat', 'Добавить запрос'],
    (can.edit_bookings || can.block) && ['hold', 'calpause', 'Удержать даты'],
    can.prices && ['price', 'coin', 'Цена и мин. ночей'],
    can.prices && ['stop', 'ban', 'Закрыть продажи'],
    can.prices && ['open', 'unlock', 'Открыть продажи'],
  ].filter(Boolean);
  const pop = $('pop');
  pop.innerHTML = `<div class="ph"><b>${esc(p.name)}</b><br>${short(s.checkIn)} → ${short(s.checkOut)} · ${nights} ${nightsWord(nights)}</div>
    <div class="pq" id="popq">Проверяю…</div>
    ${items.length ? `<div class="mlist">${items.map(([a, i, t]) => `<button data-act="${a}">${ic(i)}${t}</button>`).join('')}</div>` : ''}`;
  pop.hidden = false;
  placeFixed(pop, x + 8, y + 8);
  try {
    const [q] = await api('POST', '/api/quote', { property_ids: [s.pid], check_in: s.checkIn, check_out: s.checkOut });
    s.quote = q;
    const el = $('popq');
    if (!el) return;
    el.innerHTML = `${q.free ? '<span class="ok">Свободно</span>' : '<span class="no">Занято</span>'}
      ${q.total != null && can.money ? ` · ${money(q.accommodation, p.currency)}${q.cleaning ? ` + уборка ${money(q.cleaning, p.currency)}` : ''} = <b>${money(q.total, p.currency)}</b>` : ''}
      ${q.warnings.length ? `<div class="warn">⚠ ${esc(q.warnings.join(', '))}</div>` : ''}`;
  } catch (e) { if ($('popq')) $('popq').textContent = e.message; }
}
$('pop').addEventListener('click', async (e) => {
  const act = e.target.closest('button')?.dataset.act;
  if (!act) return;
  const s = state.sel;
  closePop();
  if (act === 'book' || act === 'inquiry') {
    openBookingDrawer(null, { property_id: s.pid, check_in: s.checkIn, check_out: s.checkOut, status: act === 'inquiry' ? 'inquiry' : 'confirmed', quote: s.quote });
  } else if (act === 'hold') {
    openHoldDrawer(null, { property_id: s.pid, check_in: s.checkIn, check_out: s.checkOut });
  } else if (act === 'price') {
    openPriceDrawer({ property_ids: [s.pid], date_from: s.checkIn, date_to: addDays(s.checkOut, -1) });
  } else if (act === 'stop' || act === 'open') {
    try {
      await api('PUT', '/api/daily', { property_ids: [s.pid], date_from: s.checkIn, date_to: addDays(s.checkOut, -1), stop_sell: act === 'stop' });
      toast(act === 'stop' ? 'Продажи закрыты — уходит в каналы' : 'Продажи открыты — уходит в каналы');
      clearSel();
      await refreshAll();
    } catch (err) { toast(err.message, true); }
  }
});

document.addEventListener('pointerdown', (e) => {
  if (!$('pop').hidden && !e.target.closest('#pop') && !e.target.closest('.cell') && !e.target.closest('#rangeBtn, #filtersBtn')) { closePop(); clearSel(); }
  if (!$('dmenu').hidden && !e.target.closest('#dmenu')) closeMenu();
  if (!$('qres').hidden && !e.target.closest('.tsearch')) $('qres').hidden = true;
});

$('cscroll').addEventListener('click', (e) => {
  const sh = e.target.closest('[data-shift]');
  if (sh) { state.from = addDays(state.from, Number(sh.dataset.shift)); load(); return; }
  const fb = e.target.closest('[data-fbook]');
  if (fb) {
    const pid = Number(fb.dataset.fbook);
    const q = state.free.map.get(pid);
    return openBookingDrawer(null, { property_id: pid, check_in: state.free.from, check_out: state.free.to, status: 'confirmed', quote: q, adults: state.free.guests || undefined });
  }
  const bar = e.target.closest('.bar');
  if (bar) {
    hideHover();
    const b = state.data.bookings.find((x) => x.id === Number(bar.dataset.b));
    if (b?.kind === 'hold') openHoldDrawer(b.id);
    else if (b) openBooking(b.id);
  }
});

// ---------- панель над шахматкой ----------
$('refreshBtn').onclick = () => refreshAll().then(() => toast('Обновлено')).catch((e) => toast(e.message, true));
$('todayBtn').onclick = () => { state.from = todayStr(); if (state.view !== 'cal') setView('cal'); load(); };
$('yPrev').onclick = () => { state.from = addMonths(state.from, -12); load(); };
$('yNext').onclick = () => { state.from = addMonths(state.from, 12); load(); };
$('mPrev').onclick = () => { state.from = addMonths(state.from, -1); load(); };
$('mNext').onclick = () => { state.from = addMonths(state.from, 1); load(); };
$('modeFree').onclick = () => { state.rangeMode = 'free'; state.page = 1; render(); if (!state.free) openRangePop(); };
$('modeBusy').onclick = () => { state.rangeMode = 'busy'; state.page = 1; render(); if (!state.free) openRangePop(); };
$('rangeBtn').onclick = () => openRangePop();
$('clearFilters').onclick = () => {
  state.filter = { q: '', hidePrices: false, conflicts: false, notReady: false, tag: '' };
  state.free = null;
  state.page = 1;
  render();
  toast('Фильтры сброшены');
};
$('filtersBtn').onclick = () => {
  const pop = $('pop');
  const f = state.filter;
  const tags = [...new Set(state.data.properties.flatMap((p) => (p.tags || '').split(',').map((s) => s.trim()).filter(Boolean)))];
  pop.innerHTML = `<div class="ph"><b>Фильтры</b></div>
    <label class="chk"><input type="checkbox" id="f_hp"${f.hidePrices ? ' checked' : ''}> Скрыть цены</label>
    <label class="chk"><input type="checkbox" id="f_cf"${f.conflicts ? ' checked' : ''}> Только с пересечением броней</label>
    <label class="chk"><input type="checkbox" id="f_nr"${f.notReady ? ' checked' : ''}> Только не готовые после выезда 🧹</label>
    ${tags.length ? `<label>Тег квартиры</label><select id="f_tag"><option value="">Все</option>${tags.map((t) => `<option${t === f.tag ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>` : ''}
    <div class="pb"><button class="primary" id="f_ok">Готово</button></div>`;
  pop.hidden = false;
  const r = $('filtersBtn').getBoundingClientRect();
  placeFixed(pop, r.left, r.bottom + 6);
  const apply = () => {
    f.hidePrices = $('f_hp').checked; f.conflicts = $('f_cf').checked; f.notReady = $('f_nr').checked; f.tag = $('f_tag')?.value || '';
    state.page = 1;
    render();
  };
  pop.querySelectorAll('input, select').forEach((el) => (el.onchange = apply));
  $('f_ok').onclick = closePop;
};
function openRangePop() {
  const pop = $('pop');
  const f = state.free;
  const from = f?.from || todayStr();
  pop.innerHTML = `<div class="ph"><b>${state.rangeMode === 'busy' ? 'Какие квартиры заняты?' : 'Какие квартиры свободны?'}</b></div>
    <div class="g2"><div><label>Заезд</label><input type="date" id="fr_in" value="${from}"></div>
    <div><label>Выезд</label><input type="date" id="fr_out" value="${f?.to || addDays(from, 7)}"></div></div>
    <label>Гостей</label><input type="number" id="fr_g" min="1" value="${f?.guests || ''}" placeholder="любое число">
    <div class="pb"><button class="primary" id="frGo">Показать</button>${f ? '<button id="frClear">Сбросить</button>' : ''}</div>`;
  pop.hidden = false;
  const r = $('rangeBtn').getBoundingClientRect();
  placeFixed(pop, r.left, r.bottom + 6);
  $('frGo').onclick = async () => {
    try {
      const ci = $('fr_in').value;
      const co = $('fr_out').value;
      if (!ci || !co || co <= ci) return toast('Выезд должен быть позже заезда', true);
      const rows = await api('POST', '/api/quote', { check_in: ci, check_out: co });
      const guests = $('fr_g').value ? Number($('fr_g').value) : null;
      const map = new Map(rows.map((q) => [q.property_id, q]));
      if (guests) for (const p of state.data.properties) if (p.max_guests && p.max_guests < guests && map.get(p.id)) map.get(p.id).free = false;
      state.free = { from: ci, to: co, guests, map, only: true };
      state.page = 1;
      closePop();
      state.from = addDays(ci, -1);
      if (diffDays(state.from, co) > state.days) state.days = Math.min(120, diffDays(state.from, co) + 7);
      await load();
    } catch (err) { toast(err.message, true); }
  };
  if ($('frClear')) $('frClear').onclick = () => { state.free = null; closePop(); render(); };
}

// ---------- выпадающие меню ----------
function openMenu(anchor, html, alignRight = false) {
  const m = $('dmenu');
  m.innerHTML = html;
  m.hidden = false;
  const r = anchor.getBoundingClientRect();
  const mr = m.getBoundingClientRect();
  const x = alignRight ? r.right - mr.width : r.left;
  const y = r.bottom + 6 + mr.height > innerHeight ? r.top - mr.height - 6 : r.bottom + 6;
  placeFixed(m, x, y);
}
function closeMenu() { $('dmenu').hidden = true; $('dmenu').innerHTML = ''; $('dmenu').onclick = null; }
function openAddMenu(anchor) {
  const can = P();
  const items = [
    can.edit_bookings && ['book', 'calplus', 'Новая бронь'],
    can.edit_bookings && ['inquiry', 'chat', 'Новый запрос'],
    (can.edit_bookings || can.block) && ['hold', 'calpause', 'Удержать даты'],
    can.prices && ['price', 'coin', 'Цены и ограничения'],
    can.properties && ['prop', 'building', 'Квартира'],
  ].filter(Boolean);
  openMenu(anchor, items.map(([a, i, t]) => `<button data-add="${a}">${ic(i)}${t}</button>`).join(''), anchor.id === 'plusBtn');
  $('dmenu').onclick = (e) => {
    const a = e.target.closest('[data-add]')?.dataset.add;
    if (!a) return;
    closeMenu();
    const p = (state.data && visibleProps()[0]) || state.data?.properties[0];
    if (a !== 'price' && a !== 'prop' && !p) return toast('Сначала добавьте квартиру', true);
    const t = todayStr();
    if (a === 'book' || a === 'inquiry') openBookingDrawer(null, { property_id: p.id, check_in: t, check_out: addDays(t, 1), status: a === 'inquiry' ? 'inquiry' : 'confirmed' });
    if (a === 'hold') openHoldDrawer(null, { property_id: p.id, check_in: t, check_out: addDays(t, 1) });
    if (a === 'price') openPriceDrawer({ property_ids: [], date_from: t, date_to: addDays(t, 29) });
    if (a === 'prop') openNewProp();
  };
}
$('addBtn').onclick = (e) => openAddMenu(e.currentTarget);
$('plusBtn').onclick = (e) => openAddMenu(e.currentTarget);
function openMeMenu(anchor) {
  openMenu(anchor, `<div class="dmh"><b>${esc(state.me.name)}</b><br>${esc(state.me.role_label)} · ${esc(state.me.login)}</div>
    ${Object.entries(LANGS).map(([k, v]) => `<button data-mm="lang" data-l="${k}" translate="no"${k === LANG ? ' class="on" disabled' : ''}>${ic('globe')}${v}</button>`).join('')}
    <button data-mm="pw">${ic('lock')}Сменить пароль</button><button data-mm="out">${ic('logout')}Выйти</button>`);
  $('dmenu').onclick = async (e) => {
    const btn = e.target.closest('[data-mm]');
    const a = btn?.dataset.mm;
    if (!a) return;
    closeMenu();
    if (a === 'lang') {
      // язык сохраняется у пользователя — на всех его устройствах
      try { await api('PUT', '/api/me/lang', { lang: btn.dataset.l }); } catch { /* сохраним хотя бы на этом устройстве */ }
      return setUiLang(btn.dataset.l);
    }
    if (a === 'pw') openPassword();
    if (a === 'out') { await fetch('/api/logout', { method: 'POST' }); location.href = '/login.html'; }
  };
}

// ---------- карточка брони (просмотр, как во всплывающем окне AdvanceCM) ----------
function closeBooking() { $('bm').hidden = true; $('bmbox').innerHTML = ''; state.bm = null; clearSel(); }
$('bm').addEventListener('mousedown', (e) => { if (e.target === $('bm')) closeBooking(); });

async function openBooking(id) {
  closePop();
  hideHover();
  let b;
  try { b = await api('GET', `/api/bookings/${id}`); } catch (e) { return toast(e.message, true); }
  if (b.kind === 'hold') return openHoldDrawer(id);
  state.bm = b.id;
  const can = P();
  const p = state.data.properties.find((q) => q.id === b.property_id) || { id: b.property_id, name: b.property_name, currency: b.currency };
  const cur = b.currency || p.currency || 'EUR';
  const nights = diffDays(b.check_in, b.check_out);
  const editable = can.edit_bookings && b.status !== 'cancelled';
  const item = (icon, cls, label, value) => `<div class="ii">${ic(icon, cls)}<div><div class="il">${label}</div><div class="iv">${value}</div></div></div>`;
  const charge = (label, v) => (v == null || v === '' ? '' : `<div class="charge"><span class="cl">${label}</span><span class="cv">${money(v, cur)}</span></div>`);
  const paidAmount = b.paid_amount ?? (b.payment_status === 'paid' ? b.total : null);
  const pay = b.status === 'confirmed' && can.money ? payPill(b.payment_status) : '';
  const st = b.status === 'inquiry' ? '<span class="pill inquiry">Запрос</span>' : b.status === 'cancelled' ? '<span class="pill cancelled">Отменена</span>' : '';
  const info = [
    p.address && ['Адрес', p.address],
    p.registration_number && ['Лицензия VV', p.registration_number],
    can.notes && p.wifi_name && ['Wi-Fi', `${p.wifi_name}${p.wifi_password ? ' / ' + p.wifi_password : ''}`],
    can.notes && p.door_code && ['Код', p.door_code],
  ].filter(Boolean);
  const notes = (b.notes_list || []).map((n) => `<div class="note"><div class="nmeta">${esc(n.user_name || '—')} · ${esc(fmtTs(n.created_at))}</div>${esc(n.text)}</div>`).join('');
  const hasPhone = (b.guest_phone || '').replace(/\D/g, '').length >= 8;

  $('bmbox').innerHTML = `
    <button class="bclose" data-bx aria-label="Закрыть">${ic('x')}</button>
    <div class="bhead" style="--pc:${esc(pColor(p))}">
      <div class="bhl">
        <div class="bnrow"><span class="bav">${esc(initial(b.guest_name))}</span><span class="bname">${esc(b.guest_name || 'Без имени')}</span>${srcIcon(b)}${pay}${st}${b.checked_in ? '<span class="pill in">Заселён</span>' : ''}</div>
        <div class="bapt"><i></i>${esc(p.name)}${b.ota_code && can.contacts ? ` · № ${esc(b.ota_code)}` : ''}</div>
      </div>
      <div class="bacts">
        ${can.contacts && b.status !== 'cancelled' ? `<button data-ba="text" title="Текст для гостя">${ic('chat')}</button>` : ''}
        ${can.notes ? `<button data-ba="notes" title="Заметки персонала">${ic('note')}</button>` : ''}
        <button data-ba="copy" title="Скопировать сведения о брони">${ic('copy')}</button>
        ${editable ? `<button data-ba="edit" title="Изменить бронь">${ic('pencil')}</button>` : ''}
      </div>
    </div>
    ${b.conflict ? '<div class="bwarn">⚠ Пересекается с другой бронью. Перенесите одну из них в другую квартиру.</div>' : ''}
    ${b.from_channel ? '<div class="binfo">Бронь из канала: даты меняются только в Booking.com / Airbnb. Перенести в другую квартиру можно здесь.</div>' : ''}
    ${editable ? `<div class="bquick">
      ${b.status === 'inquiry' ? `<button class="primary" data-q="confirm">Подтвердить бронь</button>` : ''}
      ${b.status === 'confirmed' && can.money ? `<button data-q="${b.payment_status === 'paid' ? 'unpay' : 'pay'}">${b.payment_status === 'paid' ? 'Снять «оплачено»' : 'Оплачено'}</button>` : ''}
      ${b.status === 'confirmed' ? `<button data-q="checkin">${b.checked_in ? 'Снять «заселён»' : 'Заселён'}</button>` : ''}
      <button data-q="move">Перенести в другую квартиру</button>
      <button class="danger" data-q="cancel">${b.status === 'inquiry' ? 'Отменить запрос' : 'Отменить бронь'}</button>
    </div>` : ''}
    <div class="bbody">
      <div><h6>Детали брони</h6><div class="ilist">
        ${item('calendar', 'c-indigo', 'Заезд', dmy(b.check_in))}
        ${item('calendar', 'c-indigo', 'Выезд', dmy(b.check_out))}
        ${item('login', 'c-green', 'Время заезда', esc(b.check_in_time || '—'))}
        ${item('logout', 'c-orange', 'Время выезда', esc(b.check_out_time || '—'))}
        ${item('user', 'c-orange', 'Взрослые', b.adults ?? '—')}
        ${item('child', 'c-blue', 'Дети', b.children ?? '—')}
        ${item('sun', 'c-red', 'Дней', nights + 1)}
        ${item('moon', 'c-blue', 'Ночей', nights)}
        ${item('layers', 'c-teal', 'Источник', esc(b.source || '—'))}
        ${item('clock', 'c-green', 'Создано', `${esc(fmtTs(b.created_at))}${b.created_by_name ? `<div class="il">${esc(b.created_by_name)}</div>` : ''}`)}
      </div></div>
      ${can.money ? `<div><h6>Начисления</h6><div class="gbox">
        ${charge('Проживание', b.price_accommodation)}${charge('Уборка', b.price_cleaning)}${charge('Доплата / скидка', b.price_extra)}
        ${b.net != null && b.total != null && b.net !== b.total ? charge('Чистыми после комиссии', b.net) : ''}
        ${b.status === 'confirmed' && b.total != null ? `${charge('Оплачено', paidAmount ?? 0)}${b.payment_status !== 'paid' ? charge('К оплате', Math.max(0, Math.round((b.total - (paidAmount || 0)) * 100) / 100)) : ''}` : charge('Оплачено', paidAmount)}
        <div class="charge total${b.payment_status === 'paid' ? ' paid' : ''}"><span class="cl">Итого</span><span class="cv">${b.total != null ? money(b.total, cur) : '—'}</span></div>
      </div></div>` : ''}
      ${can.contacts ? `<div><h6>Гость</h6><ul class="glist gbox">
        <li>${ic('user', 'c-blue')}<span>${esc(b.guest_name || '—')}</span>${b.guest_name ? cpy(b.guest_name) : ''}</li>
        <li>${ic('phone', 'c-green')}<span>${b.guest_phone ? `<a href="tel:${esc(b.guest_phone)}">${esc(b.guest_phone)}</a>` : '—'}</span>${b.guest_phone ? cpy(b.guest_phone) : ''}</li>
        <li>${ic('mail', 'c-red')}<span>${esc(b.guest_email || '—')}</span>${b.guest_email ? cpy(b.guest_email) : ''}</li>
        ${b.notes ? `<li>${ic('note', 'c-orange')}<span style="white-space:normal">${esc(b.notes)}</span></li>` : ''}
      </ul></div>` : ''}
      ${editable ? `<div><h6>Цвет брони</h6><div class="gbox"><div class="palette">
        <button class="none${b.color ? '' : ' on'}" data-color="" title="Без цвета">авто</button>
        ${BCOLORS.map((c) => `<button data-color="${c}" style="background:${c}"${b.color === c ? ' class="on"' : ''} title="${c}"></button>`).join('')}
      </div>${b.tags ? `<div class="small" style="margin-top:10px">Теги: ${esc(b.tags)}</div>` : ''}</div></div>` : ''}
    </div>
    ${can.contacts && b.status !== 'cancelled' ? `<div class="bsec" id="bmText" hidden><h6>Текст для гостя</h6>
      <div class="row-btns">${['ru', 'en', 'es'].map((l) => `<button type="button" class="gtl" data-l="${l}">${l.toUpperCase()}</button>`).join('')}</div>
      <textarea id="gtText" rows="9"></textarea>
      <div class="row-btns"><button class="primary" id="gtCopy">Скопировать</button>${hasPhone ? `<a class="btnlink" id="gtWa" target="_blank" rel="noopener">${ic('chat')} Открыть WhatsApp</a>` : ''}</div></div>` : ''}
    ${info.length || (can.notes && p.staff_notes) || p.photo_count ? `<div class="bsec"><h6>Квартира и заселение</h6>
      ${p.photo_count ? '<div class="pstrip" id="bmPhotos"></div>' : ''}
      ${info.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${esc(v)}</b></div>`).join('')}
      ${can.notes && p.staff_notes ? `<div class="note">${esc(p.staff_notes)}</div>` : ''}</div>` : ''}
    ${can.notes ? `<div class="bsec" id="bmNotes"><h6>Заметки персонала</h6>${notes || '<div class="muted small">Пока нет</div>'}
      <textarea id="bmNote" rows="2" placeholder="Например: поздний выезд, оставили ключи у соседа"></textarea>
      <div class="row-btns"><button id="bmNoteAdd">Добавить заметку</button></div><div class="err" id="bmErr"></div></div>` : '<div class="err" id="bmErr" style="padding:0 24px 12px"></div>'}
  `;
  $('bm').hidden = false;
  $('bm').scrollTop = 0;
  if ($('bmPhotos')) fillPhotoStrip($('bmPhotos'), p);

  const setLang = (l) => {
    $('gtText').value = guestText(p, b, l);
    document.querySelectorAll('.gtl').forEach((x) => x.classList.toggle('on', x.dataset.l === l));
    syncWa();
  };
  const syncWa = () => { if ($('gtWa')) $('gtWa').href = `https://wa.me/${(b.guest_phone || '').replace(/\D/g, '')}?text=${encodeURIComponent($('gtText').value)}`; };
  if ($('gtText')) $('gtText').oninput = syncWa;
  const err = (m) => { if ($('bmErr')) $('bmErr').textContent = m || ''; };

  $('bmbox').onclick = async (e) => {
    const t = e.target;
    if (t.closest('[data-bx]')) return closeBooking();
    const c = t.closest('[data-copy]');
    if (c) return copyText(c.dataset.copy);
    const ba = t.closest('[data-ba]')?.dataset.ba;
    if (ba === 'edit') { closeBooking(); return openBookingDrawer(b.id); }
    if (ba === 'text') { $('bmText').hidden = !$('bmText').hidden; if (!$('gtText').value) setLang(EN ? 'en' : 'ru'); if (!$('bmText').hidden) $('bmText').scrollIntoView({ block: 'nearest', behavior: 'smooth' }); return; }
    if (ba === 'notes') { $('bmNotes').scrollIntoView({ block: 'nearest', behavior: 'smooth' }); $('bmNote').focus(); return; }
    if (ba === 'copy') {
      return copyText([
        `${b.guest_name || 'Без имени'} · ${p.name}`,
        `Заезд: ${dmy(b.check_in)}${b.check_in_time ? ' ' + b.check_in_time : ''}`,
        `Выезд: ${dmy(b.check_out)}${b.check_out_time ? ' ' + b.check_out_time : ''}`,
        `${nights} ${nightsWord(nights)} · гостей: ${guestsTxt(b)}`,
        `Источник: ${b.source || '—'}`,
        can.money && b.total != null ? `Итого: ${money(b.total, cur)}${b.payment_status ? ' · ' + (PAY_RU[b.payment_status] || '') : ''}` : '',
        can.contacts && b.guest_phone ? `Телефон: ${b.guest_phone}` : '',
      ].filter(Boolean).map(tx).join('\n'), 'Сведения о брони скопированы');
    }
    const lb = t.closest('.gtl');
    if (lb) return setLang(lb.dataset.l);
    if (t.closest('#gtCopy')) return copyText($('gtText').value, 'Текст скопирован');
    const col = t.closest('[data-color]');
    if (col && !col.disabled) {
      try { await api('PUT', `/api/bookings/${b.id}`, { color: col.dataset.color || null }); await refreshAll(); openBooking(b.id); } catch (ex) { err(ex.message); }
      return;
    }
    if (t.closest('#bmNoteAdd')) {
      try { await api('POST', `/api/bookings/${b.id}/notes`, { text: $('bmNote').value }); await refreshAll(); openBooking(b.id); } catch (ex) { err(ex.message); }
      return;
    }
    const q = t.closest('[data-q]')?.dataset.q;
    if (!q) return;
    try {
      if (q === 'move') { closeBooking(); await openBookingDrawer(b.id); $('d_p')?.focus(); return; }
      if (q === 'cancel') {
        if (!confirm(b.status === 'inquiry' ? 'Отменить запрос?' : 'Отменить бронь? Даты освободятся во всех каналах.')) return;
        await api('POST', `/api/bookings/${b.id}/cancel`);
        toast('Отменено');
        closeBooking();
        return refreshAll();
      }
      if (q === 'confirm') await api('POST', `/api/bookings/${b.id}/confirm`);
      if (q === 'pay') await api('POST', `/api/bookings/${b.id}/payment`, { payment_status: 'paid' });
      if (q === 'unpay') await api('POST', `/api/bookings/${b.id}/payment`, { payment_status: 'unpaid' });
      if (q === 'checkin') await api('POST', `/api/bookings/${b.id}/checkin`, { checked_in: !b.checked_in });
      await refreshAll();
      openBooking(b.id);
    } catch (ex) { err(ex.message); }
  };
}

// ---------- боковая панель: формы ----------
function openDrawer(html) {
  const d = $('drawer');
  d.innerHTML = `<button class="dclose" id="dClose" aria-label="Закрыть">${ic('x')}</button>${html}`;
  d.hidden = false;
  d.scrollTop = 0;
  $('dClose').onclick = closeDrawer;
}
function closeDrawer() {
  $('drawer').hidden = true;
  $('drawer').innerHTML = '';
  state.drawer = null;
  clearSel();
}
const val = (id) => $(id)?.value ?? '';
const numVal = (id) => (val(id) === '' ? null : Number(val(id)));
const propOptions = (sel) => state.data.properties.map((p) => `<option value="${p.id}"${p.id === sel ? ' selected' : ''}>${esc(p.name)}</option>`).join('');
const colorPicker = (cur, dis, list = ['', ...BCOLORS]) => `<div class="colors">${list.map((c) => `<label class="sw" style="${c ? `background:${c}` : ''}" title="${c ? c : 'автоматически'}"><input type="radio" name="d_color" value="${c}"${(cur || '') === c ? ' checked' : ''}${dis}>${c ? '' : 'авто'}</label>`).join('')}</div>`;
function setErr(m) { const e = $('dErr') || $('err'); if (e) e.textContent = m || ''; }

function notesBlock(b) {
  if (!P().notes || !b.id) return '';
  const list = (b.notes_list || []).map((n) => `<div class="note"><div class="nmeta">${esc(n.user_name || '—')} · ${esc(fmtTs(n.created_at))}</div>${esc(n.text)}</div>`).join('');
  return `<section class="dsec"><h3>Заметки персонала</h3>${list || '<div class="muted small">Пока нет</div>'}
    <textarea id="d_note" rows="2" placeholder="Например: поздний выезд, оставили ключи у соседа"></textarea>
    <div class="row-btns"><button id="dNoteAdd">Добавить заметку</button></div></section>`;
}
function bindNotes(b, reopen) {
  if (!$('dNoteAdd')) return;
  $('dNoteAdd').onclick = async () => {
    try { await api('POST', `/api/bookings/${b.id}/notes`, { text: val('d_note') }); await reopen(); refreshAll(); } catch (e) { setErr(e.message); }
  };
}

// ----- бронь / запрос: создание и изменение -----
async function openBookingDrawer(id, draft = null) {
  closePop();
  hideHover();
  let b;
  if (id) {
    try { b = await api('GET', `/api/bookings/${id}`); } catch (e) { return toast(e.message, true); }
  } else {
    const p = state.data.properties.find((q) => q.id === draft.property_id);
    b = {
      kind: 'booking', status: draft.status || 'confirmed', property_id: draft.property_id, check_in: draft.check_in, check_out: draft.check_out,
      check_in_time: p?.check_in_time || '16:00', check_out_time: p?.check_out_time || '11:00', adults: draft.adults ?? 2, children: 0,
      source: state.sources[0] || 'Прямая', guest_name: draft.guest_name || '', guest_phone: '', guest_email: '', notes: '', tags: '', color: null,
      price_accommodation: draft.quote?.accommodation ?? null, price_cleaning: draft.quote?.cleaning ?? null, price_extra: null,
      payment_status: 'unpaid', paid_amount: null,
    };
  }
  state.drawer = { type: 'booking', id: b.id || null };
  const isNew = !b.id;
  const can = P();
  const editable = can.edit_bookings && b.status !== 'cancelled';
  const dis = editable ? '' : ' disabled';
  const dateDis = editable && !b.from_channel ? '' : ' disabled';
  const prop = state.data.properties.find((q) => q.id === b.property_id);
  const cur = prop?.currency || 'EUR';
  const nights = diffDays(b.check_in, b.check_out);
  const sources = [...new Set([...(state.sources || []), b.source].filter(Boolean))];

  openDrawer(`
    <div class="dhead">
      <h2>${isNew ? (b.status === 'inquiry' ? 'Новый запрос' : 'Новая бронь') : `Изменить: ${esc(b.guest_name || 'без имени')}`}</h2>
      <div class="badges">${srcIcon(b)} <span class="badge">${esc(b.source)}${b.ota_code ? ' · ' + esc(b.ota_code) : ''}</span>${b.status === 'inquiry' ? '<span class="pill inquiry">Запрос</span>' : ''}</div>
      ${b.conflict ? '<div class="alert">⚠ Пересекается с другой бронью — перенесите в другую квартиру.</div>' : ''}
      ${b.from_channel ? '<div class="muted small">Бронь из канала: даты меняются только в Booking.com / Airbnb. Перенести в другую квартиру можно здесь.</div>' : ''}
    </div>
    <section class="dsec">
      <label>Квартира</label><select id="d_p"${dis}>${propOptions(b.property_id)}</select>
      <div class="g2">
        <div><label>Заезд</label><input type="date" id="d_in" value="${b.check_in}"${dateDis}></div>
        <div><label>Время заезда</label><input type="time" id="d_tin" value="${esc(b.check_in_time || '')}"${dis}></div>
        <div><label>Выезд</label><input type="date" id="d_out" value="${b.check_out}"${dateDis}></div>
        <div><label>Время выезда</label><input type="time" id="d_tout" value="${esc(b.check_out_time || '')}"${dis}></div>
      </div>
      <div class="muted small" id="d_n" style="margin-top:6px">${nights} ${nightsWord(nights)}</div>
      <div id="d_quote" class="small"></div>
    </section>
    <section class="dsec"><h3>Гость</h3>
      <div class="g2">
        <div class="span2"><label>Имя гостя</label><input id="d_name" value="${esc(b.guest_name)}"${dis} autocomplete="off"></div>
        ${can.contacts ? `<div><label>Телефон</label><input id="d_phone" type="tel" value="${esc(b.guest_phone)}"${dis}></div>
        <div><label>E-mail</label><input id="d_email" type="email" value="${esc(b.guest_email)}"${dis}></div>` : ''}
        <div><label>Взрослые</label><input id="d_ad" type="number" min="0" value="${b.adults ?? ''}"${dis}></div>
        <div><label>Дети</label><input id="d_ch" type="number" min="0" value="${b.children ?? ''}"${dis}></div>
        <div class="span2"><label>Источник</label><select id="d_src"${b.from_channel ? ' disabled' : dis}>${sources.map((s) => `<option${s === b.source ? ' selected' : ''}>${esc(s)}</option>`).join('')}</select></div>
      </div>
    </section>
    ${can.money ? `<section class="dsec">
      <h3>Начисления, ${esc(CUR[cur] || cur)}</h3>
      <div class="g2">
        <div><label>Проживание</label><input id="d_acc" type="number" step="0.01" value="${b.price_accommodation ?? ''}"${dis}></div>
        <div><label>Уборка</label><input id="d_cln" type="number" step="0.01" value="${b.price_cleaning ?? ''}"${dis}></div>
        <div><label>Доплата (−скидка)</label><input id="d_ext" type="number" step="0.01" value="${b.price_extra ?? ''}"${dis}></div>
        <div><label>Итого</label><input id="d_tot" type="number" step="0.01" value="${b.total ?? ''}"${dis}></div>
        ${b.status !== 'inquiry' || !isNew ? `<div><label>Оплачено</label><input id="d_paid" type="number" step="0.01" value="${b.paid_amount ?? ''}"${dis}></div>` : ''}
      </div>
    </section>` : ''}
    <section class="dsec">
      <label>Цвет на шахматке</label>${colorPicker(b.color, dis)}
      <label>Теги</label><input id="d_tags" value="${esc(b.tags)}" placeholder="через запятую: VIP, повторный"${dis}>
      ${can.contacts ? `<label>Комментарий к брони</label><textarea id="d_notes" rows="2"${dis}>${esc(b.notes)}</textarea>` : ''}
    </section>
    <div class="dErr" id="dErr"></div>
    ${editable ? `<div class="dfoot">${isNew ? '' : '<button id="dBack">Отмена</button>'}<button class="primary" id="dSave">${isNew ? (b.status === 'inquiry' ? 'Создать запрос' : 'Создать бронь') : 'Сохранить'}</button></div>` : ''}
  `);

  const dirty = new Set();
  ['d_acc', 'd_cln', 'd_ext', 'd_tot'].forEach((k) => $(k)?.addEventListener('input', () => dirty.add(k)));
  const recalcTotal = () => {
    if (!$('d_tot') || dirty.has('d_tot')) return;
    const parts = ['d_acc', 'd_cln', 'd_ext'].map(numVal).filter((x) => x != null);
    if (parts.length) $('d_tot').value = Math.round(parts.reduce((a, c) => a + c, 0) * 100) / 100;
  };
  ['d_acc', 'd_cln', 'd_ext'].forEach((k) => $(k)?.addEventListener('input', recalcTotal));
  const requote = async () => {
    const ci = val('d_in');
    const co = val('d_out');
    if (!ci || !co || co <= ci) { $('d_n').textContent = 'Проверьте даты'; return; }
    const n = diffDays(ci, co);
    $('d_n').textContent = `${n} ${nightsWord(n)}`;
    try {
      const [q] = await api('POST', '/api/quote', { property_ids: [Number(val('d_p'))], check_in: ci, check_out: co, exclude_id: b.id || 0 });
      $('d_quote').innerHTML = `${q.free ? '<span class="ok">Свободно</span>' : '<span class="no">Занято другой бронью</span>'}${q.warnings.length ? ` · <span class="warn">⚠ ${esc(q.warnings.join(', '))}</span>` : ''}${q.total != null && can.money ? ` · по тарифу ${money(q.total, cur)}` : ''}`;
      if (isNew && q.total != null) {
        if ($('d_acc') && !dirty.has('d_acc')) $('d_acc').value = q.accommodation;
        if ($('d_cln') && !dirty.has('d_cln')) $('d_cln').value = q.cleaning || '';
        recalcTotal();
      }
    } catch { /* без расчёта */ }
  };
  if (editable) {
    ['d_in', 'd_out', 'd_p'].forEach((k) => $(k)?.addEventListener('change', requote));
    requote();
  }
  const collect = () => {
    const body = {
      property_id: Number(val('d_p')), check_in: val('d_in'), check_out: val('d_out'),
      check_in_time: val('d_tin'), check_out_time: val('d_tout'),
      guest_name: val('d_name'), adults: numVal('d_ad'), children: numVal('d_ch'),
      tags: val('d_tags'), color: document.querySelector('input[name="d_color"]:checked')?.value || null,
    };
    if (!b.from_channel) body.source = val('d_src');
    if ($('d_phone')) { body.guest_phone = val('d_phone'); body.guest_email = val('d_email'); }
    if ($('d_notes')) body.notes = val('d_notes');
    if ($('d_acc')) {
      body.price_accommodation = numVal('d_acc'); body.price_cleaning = numVal('d_cln'); body.price_extra = numVal('d_ext'); body.total = numVal('d_tot');
      if ($('d_paid')) body.paid_amount = numVal('d_paid');
    }
    if (b.from_channel) { delete body.check_in; delete body.check_out; }
    return body;
  };
  if ($('dBack')) $('dBack').onclick = () => { closeDrawer(); openBooking(b.id); };
  if ($('dSave')) {
    $('dSave').onclick = async () => {
      try {
        if (isNew) {
          const r = await api('POST', '/api/bookings', { ...collect(), kind: 'booking', status: b.status });
          toast(b.status === 'inquiry' ? 'Запрос создан' : 'Бронь создана — даты закрываются в каналах');
          closeDrawer();
          await refreshAll();
          openBooking(r.id);
        } else {
          await api('PUT', `/api/bookings/${b.id}`, collect());
          toast('Сохранено');
          closeDrawer();
          await refreshAll();
          openBooking(b.id);
        }
      } catch (e) { setErr(e.message); }
    };
  }
  $('d_name')?.focus();
}

// ----- текст для гостя -----
const GT = {
  ru: { hi: 'Здравствуйте', wait: 'Ждём вас', from: 'с', checkout: 'Выезд', by: 'до', addr: 'Адрес', wifi: 'Wi-Fi', pass: 'пароль', code: 'Код двери', rules: 'Правила дома', bye: 'Хорошего отдыха!', loc: 'ru-RU' },
  en: { hi: 'Hello', wait: 'We look forward to welcoming you on', from: 'from', checkout: 'Check-out on', by: 'by', addr: 'Address', wifi: 'Wi-Fi', pass: 'password', code: 'Door code', rules: 'House rules', bye: 'Enjoy your stay!', loc: 'en-GB' },
  es: { hi: 'Hola', wait: 'Le esperamos el', from: 'a partir de las', checkout: 'Salida el', by: 'antes de las', addr: 'Dirección', wifi: 'Wi-Fi', pass: 'contraseña', code: 'Código de la puerta', rules: 'Normas de la casa', bye: '¡Feliz estancia!', loc: 'es-ES' },
};
function guestText(p, b, lang) {
  const t = GT[lang];
  const day = (s) => new Intl.DateTimeFormat(t.loc, { day: 'numeric', month: 'long' }).format(parse(s));
  const first = (b.guest_name || '').trim().split(/\s+/)[0];
  const arrive = `${t.wait} ${day(b.check_in)}${b.check_in_time ? ` ${t.from} ${b.check_in_time}` : ''}.`;
  const leave = `${t.checkout} ${day(b.check_out)}${b.check_out_time ? ` ${t.by} ${b.check_out_time}` : ''}.`;
  return [
    `${t.hi}${first ? ', ' + first : ''}!`,
    `${arrive} ${leave}`,
    p.address && `${t.addr}: ${p.address}`,
    p.checkin_instructions,
    p.wifi_name && `${t.wifi}: ${p.wifi_name}${p.wifi_password ? `, ${t.pass}: ${p.wifi_password}` : ''}`,
    p.door_code && `${t.code}: ${p.door_code}`,
    p.house_rules && `${t.rules}: ${p.house_rules}`,
    t.bye,
  ].filter(Boolean).join('\n');
}

// ----- удержание дат -----
async function openHoldDrawer(id, draft = null) {
  closePop();
  hideHover();
  let h;
  if (id) {
    try { h = await api('GET', `/api/bookings/${id}`); } catch (e) { return toast(e.message, true); }
  } else {
    const types = Object.keys(state.holdTypes);
    h = { kind: 'hold', status: 'confirmed', hold_type: types.includes('tentative') ? 'tentative' : types[0], title: '', notes: '', expires_at: Date.now() + 24 * 3600_000, ...draft };
  }
  state.drawer = { type: 'hold', id: h.id || null };
  const isNew = !h.id;
  const can = P();
  const editable = h.status !== 'cancelled' && (can.edit_bookings || (can.block && Object.keys(state.holdTypes).includes(h.hold_type)));
  const dis = editable ? '' : ' disabled';
  const expLocal = h.expires_at ? new Date(h.expires_at - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
  const typeBtns = Object.entries({ ...HOLD_NAMES, ...state.holdTypes })
    .filter(([k]) => state.holdTypes[k] || k === h.hold_type)
    .map(([k, v]) => `<label class="tbtn"><input type="radio" name="h_type" value="${k}"${k === h.hold_type ? ' checked' : ''}${dis}>${HOLD_ICON[k]} ${esc(v)}</label>`).join('');

  openDrawer(`
    <div class="dhead"><h2>${isNew ? 'Удержать даты' : `${HOLD_ICON[h.hold_type] || ''} ${esc(holdName(h.hold_type))}`}</h2>
      <div class="muted small">Даты закрываются во всех каналах, как при брони.</div></div>
    <section class="dsec">
      <div class="types">${typeBtns}</div>
      <label>Название</label><input id="h_title" value="${esc(h.title)}" placeholder="Например: замена бойлера / Андрей, ждём предоплату"${dis}>
      <label>Квартира</label><select id="h_p"${dis}>${propOptions(h.property_id)}</select>
      <div class="g2">
        <div><label>${EN ? 'From' : 'С'}</label><input type="date" id="h_in" value="${h.check_in}"${dis}></div>
        <div><label>До (день выезда)</label><input type="date" id="h_out" value="${h.check_out}"${dis}></div>
      </div>
      <div id="h_expwrap">
        <label>Снять автоматически</label>
        <div class="row-btns">
          ${[[2, '2 ч'], [6, '6 ч'], [24, '24 ч'], [72, '3 дня']].map(([hh, t]) => `<button type="button" data-exp="${hh}"${dis}>${t}</button>`).join('')}
        </div>
        <input type="datetime-local" id="h_exp" value="${expLocal}"${dis}>
      </div>
      ${can.contacts ? `<label>Комментарий</label><textarea id="h_notes" rows="2"${dis}>${esc(h.notes)}</textarea>` : ''}
      ${!isNew ? `<div class="muted small" style="margin-top:8px">Поставил(а): ${esc(h.created_by_name || '—')} · ${esc(fmtTs(h.created_at))}</div>` : ''}
    </section>
    ${notesBlock(h)}
    <div class="dErr" id="dErr"></div>
    ${editable ? `<div class="dfoot">
      ${!isNew && can.edit_bookings ? '<button id="hConvert">Оформить в бронь</button>' : ''}
      ${!isNew ? '<button class="danger" id="hCancel">Снять удержание</button>' : ''}
      <button class="primary" id="hSave">${isNew ? 'Удержать' : 'Сохранить'}</button></div>` : ''}
  `);
  const syncExp = () => { $('h_expwrap').hidden = document.querySelector('input[name="h_type"]:checked')?.value !== 'tentative'; };
  document.querySelectorAll('input[name="h_type"]').forEach((r) => (r.onchange = syncExp));
  syncExp();
  document.querySelectorAll('[data-exp]').forEach((btn) => (btn.onclick = () => {
    const t = Date.now() + Number(btn.dataset.exp) * 3600_000;
    $('h_exp').value = new Date(t - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }));
  const reopen = () => openHoldDrawer(h.id);
  if ($('hSave')) {
    $('hSave').onclick = async () => {
      const type = document.querySelector('input[name="h_type"]:checked')?.value;
      const body = {
        kind: 'hold', hold_type: type, title: val('h_title'), property_id: Number(val('h_p')), check_in: val('h_in'), check_out: val('h_out'),
        expires_at: type === 'tentative' && val('h_exp') ? new Date(val('h_exp')).getTime() : null,
      };
      if ($('h_notes')) body.notes = val('h_notes');
      try {
        if (isNew) {
          const r = await api('POST', '/api/bookings', body);
          toast('Даты удержаны');
          clearSel();
          await refreshAll();
          openHoldDrawer(r.id);
        } else {
          delete body.kind;
          await api('PUT', `/api/bookings/${h.id}`, body);
          toast('Сохранено');
          await refreshAll();
          reopen();
        }
      } catch (e) { setErr(e.message); }
    };
  }
  if ($('hCancel')) {
    $('hCancel').onclick = async () => {
      if (!confirm('Снять удержание? Даты откроются для продажи.')) return;
      try { await api('POST', `/api/bookings/${h.id}/cancel`); toast('Удержание снято'); await refreshAll(); closeDrawer(); } catch (e) { setErr(e.message); }
    };
  }
  if ($('hConvert')) {
    $('hConvert').onclick = async () => {
      try { const r = await api('POST', `/api/bookings/${h.id}/convert`); toast('Оформлено в бронь — заполните гостя и стоимость'); closeDrawer(); await refreshAll(); openBookingDrawer(r.id); } catch (e) { setErr(e.message); }
    };
  }
  bindNotes(h, reopen);
}

// ----- цены и ограничения на выбранные даты -----
function openPriceDrawer(init) {
  closePop();
  state.drawer = { type: 'price' };
  const pid = init.property_ids?.[0];
  openDrawer(`
    <div class="dhead"><h2>Цены и ограничения</h2><div class="muted small">Пустое поле — не менять. Изменения уходят в каналы.</div></div>
    <section class="dsec">
      <label>Квартиры</label>
      <div class="plist">${state.data.properties.map((p) => `<label class="chk"><input type="checkbox" class="pp_chk" value="${p.id}"${(init.property_ids || []).includes(p.id) ? ' checked' : ''}> ${esc(p.name)}</label>`).join('')}</div>
      <div class="row-btns"><button type="button" id="ppAll">Все</button><button type="button" id="ppNone">Ни одной</button></div>
      <div class="g2">
        <div><label>С даты</label><input type="date" id="pp_from" value="${init.date_from}"></div>
        <div><label>По дату (последняя ночь)</label><input type="date" id="pp_to" value="${init.date_to}"></div>
      </div>
      <label>Дни недели</label>
      <div class="wdays">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<label class="wd${w === 0 || w === 6 ? ' we' : ''}"><input type="checkbox" class="pp_wd" value="${w}" checked>${WD[w]}</label>`).join('')}</div>
      <div class="row-btns"><button type="button" id="ppWeekend">Только пт–сб</button><button type="button" id="ppWeekdays">Только вс–чт</button><button type="button" id="ppEvery">Все дни</button></div>
      <div class="g2">
        <div><label>Цена</label><select id="pp_mode"><option value="set">новая цена за ночь</option><option value="percent">изменить на %</option><option value="amount">изменить на €</option></select></div>
        <div><label id="pp_vlabel">Цена за ночь</label><input type="number" step="0.01" id="pp_price" placeholder="${pid ? Math.round(state.data.properties.find((p) => p.id === pid)?.base_price || 0) : ''}"></div>
        <div><label>Мин. ночей</label><input type="number" min="1" id="pp_min"></div>
        <div><label>Продажи</label><select id="pp_stop"><option value="">не менять</option><option value="0">открыть</option><option value="1">закрыть</option></select></div>
        <div class="span2"><label>Заезд / выезд</label><select id="pp_cta"><option value="">не менять</option><option value="0">разрешены</option><option value="1">без заезда</option><option value="2">без выезда</option></select></div>
      </div>
      <div class="muted small" id="pp_hint"></div>
    </section>
    <div class="dErr" id="dErr"></div>
    <div class="dfoot"><button class="primary" id="ppSave">Применить</button></div>`);
  $('ppAll').onclick = () => document.querySelectorAll('.pp_chk').forEach((c) => (c.checked = true));
  $('ppNone').onclick = () => document.querySelectorAll('.pp_chk').forEach((c) => (c.checked = false));
  const setWd = (list) => document.querySelectorAll('.pp_wd').forEach((c) => (c.checked = list.includes(Number(c.value))));
  $('ppWeekend').onclick = () => setWd([5, 6]);
  $('ppWeekdays').onclick = () => setWd([0, 1, 2, 3, 4]);
  $('ppEvery').onclick = () => setWd([0, 1, 2, 3, 4, 5, 6]);
  $('pp_mode').onchange = () => {
    const mode = val('pp_mode');
    $('pp_vlabel').textContent = mode === 'set' ? 'Цена за ночь' : mode === 'percent' ? 'На сколько %, например 10 или −15' : 'На сколько €, например 20 или −10';
    $('pp_hint').textContent = mode === 'set' ? '' : 'Меняется текущая цена каждого дня (ручная или базовая).';
  };
  $('ppSave').onclick = async () => {
    const body = { property_ids: [...document.querySelectorAll('.pp_chk:checked')].map((c) => Number(c.value)), date_from: val('pp_from'), date_to: val('pp_to') };
    const wd = [...document.querySelectorAll('.pp_wd:checked')].map((c) => Number(c.value));
    if (!wd.length) return setErr('Выберите хотя бы один день недели');
    if (wd.length < 7) body.weekdays = wd;
    if (val('pp_price') !== '') {
      if (val('pp_mode') === 'set') body.price = Number(val('pp_price'));
      else body.price_change = { mode: val('pp_mode'), value: Number(val('pp_price')) };
    }
    if (val('pp_min') !== '') body.min_stay = Number(val('pp_min'));
    if (val('pp_stop') !== '') body.stop_sell = val('pp_stop') === '1';
    if (val('pp_cta') !== '') { body.cta = val('pp_cta') === '1'; body.ctd = val('pp_cta') === '2'; }
    if (!['price', 'price_change', 'min_stay', 'stop_sell', 'cta'].some((k) => k in body)) return setErr('Укажите, что поменять');
    if (!body.property_ids.length) return setErr('Выберите квартиры');
    try {
      const r = await api('PUT', '/api/daily', body);
      toast(`Применено: ${r.days} дн. × ${body.property_ids.length} кв. — уходит в каналы`);
      closeDrawer();
      await refreshAll();
    } catch (e) { setErr(e.message); }
  };
}

// ---------- быстрый поиск ----------
let qTimer;
$('q').addEventListener('input', () => {
  clearTimeout(qTimer);
  qTimer = setTimeout(async () => {
    const q = $('q').value.trim();
    if (q.length < 2) { $('qres').hidden = true; return; }
    try {
      const rows = await api('GET', `/api/search?q=${encodeURIComponent(q)}`);
      $('qres').innerHTML = rows.length
        ? rows.map((b) => `<button data-sid="${b.id}" data-kind="${b.kind}" data-ci="${b.check_in}">${srcIcon(b)}<span class="qt"><b>${esc(barLabel(b))}</b> · ${esc(b.property_name)}<br><span class="muted small">${short(b.check_in)} → ${short(b.check_out)}${b.status === 'cancelled' ? ' · отменена' : b.status === 'inquiry' ? ' · запрос' : ''}</span></span></button>`).join('')
        : '<div class="muted pad">Ничего не найдено</div>';
      $('qres').hidden = false;
    } catch (e) { toast(e.message, true); }
  }, 250);
});
$('qres').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-sid]');
  if (!btn) return;
  $('qres').hidden = true;
  state.from = addDays(btn.dataset.ci, -3);
  if (state.view !== 'cal') setView('cal');
  await load();
  if (btn.dataset.kind === 'hold') openHoldDrawer(Number(btn.dataset.sid));
  else openBooking(Number(btn.dataset.sid));
  document.querySelector(`.bar[data-b="${btn.dataset.sid}"]`)?.scrollIntoView({ block: 'center', inline: 'center' });
});

// ---------- заезды и выезды ----------
const agenda = { mode: 'week', from: null, prop: '', type: '', q: '' };
function agendaRange() {
  if (!agenda.from) agenda.from = todayStr();
  if (agenda.mode === 'day') return [agenda.from, agenda.from];
  if (agenda.mode === 'month') return [monthStart(agenda.from), monthEnd(agenda.from)];
  return [agenda.from, addDays(agenda.from, 6)];
}
let agendaEvents = [];
async function loadAgenda() {
  const [from, to] = agendaRange();
  agendaEvents = await api('GET', `/api/agenda?from=${from}&to=${to}`);
  const props = new Map(state.data.properties.map((p) => [p.id, p]));
  const can = P();
  const q = agenda.q.trim().toLowerCase();
  const events = agendaEvents.filter((e) => (!agenda.prop || e.booking.property_id === Number(agenda.prop))
    && (!agenda.type || e.type === agenda.type)
    && (!q || `${e.booking.guest_name || ''} ${e.booking.property_name || ''} ${e.booking.title || ''}`.toLowerCase().includes(q)));
  const range = from === to ? dmy(from) : `${dmy(from)} – ${dmy(to)}`;
  let html = `<div class="phead"><h1>Заезды и выезды</h1><div class="vswitch">${vswitch('agenda')}</div><span class="grow"></span>
    <div class="seg">${[['day', 'День'], ['week', 'Неделя'], ['month', 'Месяц']].map(([m, t]) => `<button data-am="${m}"${agenda.mode === m ? ' class="on"' : ''}>${t}</button>`).join('')}</div>
    <div class="stepper"><button id="agPrev" aria-label="Назад">${ic('left')}</button><span style="min-width:220px">${range}</span><button id="agNext" aria-label="Вперёд">${ic('right')}</button></div>
    <button class="obtn" id="agToday">Сегодня</button>
    <button class="sbtn orange" id="agActions">Действия ${ic('caret')}</button></div>
    <div class="tcard"><div class="tfilters">
      <select id="ag_prop"><option value="">Все квартиры</option>${state.data.properties.map((p) => `<option value="${p.id}"${String(p.id) === agenda.prop ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select>
      <select id="ag_type"><option value="">Все события</option><option value="arrival"${agenda.type === 'arrival' ? ' selected' : ''}>Заезды</option><option value="departure"${agenda.type === 'departure' ? ' selected' : ''}>Выезды</option><option value="hold"${agenda.type === 'hold' ? ' selected' : ''}>Удержания</option></select>
      <button class="ibtn line" id="agClear" title="Сбросить фильтры">${ic('filterx')}</button>
      <button class="ibtn soft" id="agRefresh" title="Обновить">${ic('refresh')}</button>
      <span class="grow"></span><input id="ag_q" type="search" placeholder="Поиск…" value="${esc(agenda.q)}">
    </div>`;
  if (!events.length) html += '<div class="empty">В этот период нет заездов и выездов.</div>';
  else {
    html += `<div class="tscroll"><table class="ltable"><thead><tr><th>Дата</th><th>Время</th><th>Событие</th><th>Гость</th><th>Квартира</th><th>${ic('user')} Взр.</th><th>${ic('child')} Дети</th><th>Заметки</th><th>Уборка</th></tr></thead><tbody>`;
    let lastDay = '';
    for (const e of events) {
      const b = e.booking;
      const p = props.get(b.property_id);
      const ev = e.type === 'arrival' ? `<span class="ev in">${ic('login')} Заезд</span>` : e.type === 'departure' ? `<span class="ev out">${ic('logout')} Выезд</span>` : `<span class="ev hold">${HOLD_ICON[b.hold_type] || '⛔'} Удержание</span>`;
      const ready = e.type === 'arrival' && p && (can.notes || can.properties) ? `<button class="rdy ${p.ready === 0 ? 'no' : 'yes'}" data-ready="${p.id}" data-v="${p.ready === 0 ? 1 : 0}">${p.ready === 0 ? '🧹 Не готова' : '✓ Готова'}</button>` : e.type === 'arrival' && p?.ready === 0 ? '🧹' : '';
      html += `<tr data-open="${b.id}" data-kind="${b.kind}">
        <td class="datecell">${e.date !== lastDay ? `${dmy(e.date)}<div class="small muted">${WDF[parse(e.date).getDay()]}</div>` : ''}</td>
        <td>${e.time ? `${ic('clock')} ${esc(e.time)}` : ''}</td>
        <td>${ev}${e.turnover ? ' <span class="badge warn" title="Выезд и заезд в один день">смена</span>' : ''}</td>
        <td><span class="gname">${srcIcon(b)}<span>${esc(barLabel(b))}</span></span></td>
        <td><span class="apt"><i class="${p?.ready === 0 ? 'no' : ''}"></i>${esc(b.property_name)}</span></td>
        <td>${b.adults ?? ''}</td><td>${b.children ?? ''}</td>
        <td>${b.notes_count ? `${ic('note', 'c-blue')} ${b.notes_count}` : ''}${b.checked_in ? ' <span class="pill in">заселён</span>' : ''}</td>
        <td>${ready}</td></tr>`;
      lastDay = e.date;
    }
    html += '</tbody></table></div>';
  }
  html += '</div>';
  $('agenda').innerHTML = html;
  const reload = () => loadAgenda().catch((er) => toast(er.message, true));
  $('agenda').querySelectorAll('[data-am]').forEach((btn) => (btn.onclick = () => { agenda.mode = btn.dataset.am; if (agenda.mode === 'month') agenda.from = monthStart(agenda.from); reload(); }));
  const step = (dir) => {
    if (agenda.mode === 'day') agenda.from = addDays(agenda.from, dir);
    else if (agenda.mode === 'week') agenda.from = addDays(agenda.from, 7 * dir);
    else agenda.from = addMonths(agenda.from, dir);
    reload();
  };
  $('agPrev').onclick = () => step(-1);
  $('agNext').onclick = () => step(1);
  $('agToday').onclick = () => { agenda.from = agenda.mode === 'month' ? monthStart(todayStr()) : todayStr(); reload(); };
  $('ag_prop').onchange = () => { agenda.prop = $('ag_prop').value; reload(); };
  $('ag_type').onchange = () => { agenda.type = $('ag_type').value; reload(); };
  $('agClear').onclick = () => { agenda.prop = ''; agenda.type = ''; agenda.q = ''; reload(); };
  $('agRefresh').onclick = () => refreshAll().catch((er) => toast(er.message, true));
  let t;
  $('ag_q').oninput = () => { clearTimeout(t); t = setTimeout(() => { agenda.q = $('ag_q').value; reload().then(() => { const el = $('ag_q'); el.focus(); el.setSelectionRange(el.value.length, el.value.length); }); }, 300); };
  $('agActions').onclick = (e) => {
    openMenu(e.currentTarget, `<button data-aa="print">${ic('printer')}Печать</button><button data-aa="csv">${ic('download')}Скачать CSV</button>`, true);
    $('dmenu').onclick = (ev) => {
      const a = ev.target.closest('[data-aa]')?.dataset.aa;
      if (!a) return;
      closeMenu();
      if (a === 'print') print();
      if (a === 'csv') {
        downloadCsv(`zaezdy-${from}_${to}.csv`, [['Дата', 'Время', 'Событие', 'Квартира', 'Гость', 'Взрослые', 'Дети'],
          ...events.map((x) => [x.date, x.time || '', { arrival: 'Заезд', departure: 'Выезд', hold: 'Удержание' }[x.type], x.booking.property_name, barLabel(x.booking), x.booking.adults ?? '', x.booking.children ?? ''])]);
      }
    };
  };
}
$('agenda').addEventListener('click', async (e) => {
  const rb = e.target.closest('[data-ready]');
  if (rb) {
    e.stopPropagation();
    try { await api('POST', `/api/properties/${rb.dataset.ready}/ready`, { ready: rb.dataset.v === '1' }); await load(); loadAgenda(); } catch (err) { toast(err.message, true); }
    return;
  }
  const tr = e.target.closest('tr[data-open]');
  if (!tr) return;
  if (tr.dataset.kind === 'hold') openHoldDrawer(Number(tr.dataset.open));
  else openBooking(Number(tr.dataset.open));
});

// ---------- список броней ----------
const list = { from: null, to: null, property_id: '', status: '', source: '', payment: '', q: '', page: 1, per: LS.get('listPer', 25) };
async function loadList() {
  if (!list.from) { list.from = monthStart(todayStr()); list.to = monthEnd(todayStr()); }
  const qs = new URLSearchParams(Object.entries({ from: list.from, to: list.to, property_id: list.property_id, status: list.status, source: list.source, payment: list.payment, q: list.q }).filter(([, v]) => v !== '' && v != null));
  const rows = await api('GET', `/api/bookings?${qs}`);
  const can = P();
  const props = state.data.properties;
  const pmap = new Map(props.map((p) => [p.id, p]));
  const cur = props[0]?.currency || 'EUR';
  const sources = [...new Set([...state.sources, 'Booking.com', 'Airbnb', ...rows.map((r) => r.source)])].filter(Boolean);
  const sel = (id, opts, v) => `<select id="${id}">${opts.map(([k, t]) => `<option value="${esc(k)}"${String(v) === String(k) ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
  const live = rows.filter((r) => r.status === 'confirmed');
  const sum = (k) => live.reduce((t, r) => t + (r[k] || 0), 0);
  const pages = Math.max(1, Math.ceil(rows.length / list.per));
  if (list.page > pages) list.page = pages;
  const pageRows = rows.slice((list.page - 1) * list.per, list.page * list.per);
  const t = todayStr();
  const period = list.from === monthStart(t) && list.to === monthEnd(t) ? 'this'
    : list.from === monthStart(addMonths(t, -1)) && list.to === monthEnd(addMonths(t, -1)) ? 'prev'
      : list.from === monthStart(addMonths(t, 1)) && list.to === monthEnd(addMonths(t, 1)) ? 'next' : 'custom';
  const AV = ['#e0faf1|#2fb383', '#e8f0fe|#3f6fd1', '#fde8f5|#d6337a', '#fff1e6|#e8590c', '#f3e8ff|#7c3aed'];
  const av = (name) => { const [bg, fg] = AV[(name || '').length % AV.length].split('|'); return `<span class="gav" style="background:${bg};color:${fg}">${esc(initial(name))}</span>`; };
  let html = `<div class="phead"><h1>Брони</h1><div class="vswitch">${vswitch('list')}</div><span class="grow"></span>
    <button class="sbtn orange" id="lActions">Действия ${ic('caret')}</button>
    ${can.edit_bookings ? `<button class="sbtn blue" id="lAdd">${ic('plus')} Добавить бронь</button>` : ''}</div>
    <div class="tcard"><div class="tfilters">
      <button class="ibtn soft" id="lRefresh" title="Обновить">${ic('refresh')}</button>
      ${sel('l_prop', [['', 'Все квартиры'], ...props.map((p) => [p.id, p.name])], list.property_id)}
      ${sel('l_src', [['', 'Все источники'], ...sources.map((s) => [s, s])], list.source)}
      ${sel('l_status', [['', 'Брони и запросы'], ['confirmed', 'Только брони'], ['inquiry', 'Только запросы'], ['cancelled', 'Отменённые']], list.status)}
      ${can.money ? sel('l_pay', [['', 'Любая оплата'], ['unpaid', 'Не оплачено'], ['partial', 'Частично'], ['paid', 'Оплачено']], list.payment) : ''}
      ${sel('l_period', [['this', 'Заезд в этом месяце'], ['prev', 'В прошлом месяце'], ['next', 'В следующем месяце'], ['30', 'Ближайшие 30 дней'], ['custom', 'Свой период']], period)}
      <input type="date" id="l_from" value="${list.from}" title="Заезд с"><input type="date" id="l_to" value="${list.to}" title="Заезд по">
      <button class="ibtn line" id="lClear" title="Сбросить фильтры">${ic('filterx')}</button>
      <span class="grow"></span><input id="l_q" type="search" placeholder="Гость, телефон, № брони" value="${esc(list.q)}">
    </div>
    <div class="ltotal"><b>${live.length}</b> броней · <b>${live.reduce((a, r) => a + r.nights, 0)}</b> ночей${can.money ? ` · сумма <b>${money(sum('total'), cur)}</b> · чистыми <b>${money(sum('net'), cur)}</b> · оплачено <b>${money(sum('paid_amount'), cur)}</b>` : ''}${rows.length - live.length ? ` · запросов и отмен: ${rows.length - live.length}` : ''}</div>`;
  if (!rows.length) html += '<div class="empty">Ничего не найдено. Измените период или фильтры.</div>';
  else {
    html += `<div class="tscroll"><table class="ltable"><thead><tr><th>Создана</th><th>Источник</th><th>Квартира</th><th>Гость</th><th>Заезд</th><th>Выезд</th>${can.money ? '<th>Оплата</th>' : ''}<th title="Ночей">${ic('moon')}</th><th title="Гостей">${ic('users')}</th><th>Статус</th>${can.money ? '<th class="num">Сумма</th><th class="num">Чистыми</th><th class="num">Оплачено</th>' : ''}</tr></thead><tbody>`;
    for (const r of pageRows) {
      const p = pmap.get(r.property_id);
      html += `<tr data-open="${r.id}" class="${r.status}">
        <td class="gd">${r.created_at ? dmy(String(r.created_at).slice(0, 10)) : ''}</td>
        <td>${srcIcon(r)}</td>
        <td><span class="apt"><i style="background:${esc(pColor(p))}"></i>${esc(r.property_name)}</span></td>
        <td><span class="gname">${av(r.guest_name)}<span>${esc(r.guest_name || '—')}</span></span></td>
        <td class="gd">${dmy(r.check_in)}</td><td class="gd">${dmy(r.check_out)}</td>
        ${can.money ? `<td>${r.status === 'confirmed' ? payPill(r.payment_status) : ''}</td>` : ''}
        <td class="gd">${r.nights}</td><td class="gd">${guestsTxt(r)}</td>
        <td><span class="pill ${r.status}">${STATUS_RU[r.status] || r.status}</span></td>
        ${can.money ? `<td class="num">${money(r.total, r.currency)}</td><td class="num">${money(r.net, r.currency)}</td><td class="num">${money(r.paid_amount, r.currency)}</td>` : ''}</tr>`;
    }
    html += `</tbody></table></div><div class="pager">${pagerHtml(rows.length, pageRows.length, list.page, list.per, 'l')}</div>`;
  }
  html += '</div>';
  $('list').innerHTML = html;
  const reload = () => loadList().catch((e) => toast(e.message, true));
  const on = (id, fn) => { if ($(id)) $(id).onchange = () => { fn($(id).value); list.page = 1; reload(); }; };
  on('l_prop', (v) => { list.property_id = v; });
  on('l_src', (v) => { list.source = v; });
  on('l_status', (v) => { list.status = v; });
  on('l_pay', (v) => { list.payment = v; });
  on('l_from', (v) => { list.from = v; });
  on('l_to', (v) => { list.to = v; });
  on('l_period', (v) => {
    if (v === '30') { list.from = t; list.to = addDays(t, 30); } else if (v !== 'custom') { const base = v === 'prev' ? addMonths(t, -1) : v === 'next' ? addMonths(t, 1) : t; list.from = monthStart(base); list.to = monthEnd(base); }
  });
  $('lRefresh').onclick = reload;
  $('lClear').onclick = () => { Object.assign(list, { from: null, to: null, property_id: '', status: '', source: '', payment: '', q: '', page: 1 }); reload(); };
  if ($('lAdd')) $('lAdd').onclick = (e) => openAddMenu(e.currentTarget);
  let qt;
  $('l_q').oninput = () => { clearTimeout(qt); qt = setTimeout(() => { list.q = $('l_q').value; list.page = 1; reload().then(() => { const q = $('l_q'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }); }, 350); };
  $('lActions').onclick = (e) => {
    openMenu(e.currentTarget, `<button data-la="csv">${ic('download')}Скачать CSV</button>`, true);
    $('dmenu').onclick = (ev) => {
      if (!ev.target.closest('[data-la]')) return;
      closeMenu();
      downloadCsv(`broni-${list.from}_${list.to}.csv`, [
        ['Создана', 'Заезд', 'Выезд', 'Ночей', 'Квартира', 'Гость', 'Взрослые', 'Дети', 'Источник', 'Статус', ...(can.money ? ['Оплата', 'Сумма', 'Чистыми', 'Оплачено'] : [])],
        ...rows.map((r) => [r.created_at || '', r.check_in, r.check_out, r.nights, r.property_name, r.guest_name, r.adults ?? '', r.children ?? '', r.source, STATUS_RU[r.status] || r.status,
          ...(can.money ? [PAY_RU[r.payment_status] || '', r.total ?? '', r.net ?? '', r.paid_amount ?? ''] : [])]),
      ]);
    };
  };
}
$('list').addEventListener('click', (e) => {
  const pg = e.target.closest('[data-lpg]')?.dataset.lpg;
  if (pg) { list.page = Number(pg); loadList().catch((er) => toast(er.message, true)); return; }
  const tr = e.target.closest('tr[data-open]');
  if (tr) openBooking(Number(tr.dataset.open));
});
$('list').addEventListener('change', (e) => {
  if (e.target.matches('[data-lper]')) { list.per = Number(e.target.value); LS.set('listPer', list.per); list.page = 1; loadList().catch((er) => toast(er.message, true)); }
});
function downloadCsv(name, rows) {
  const csv = rows.map((r) => r.map((c) => `"${tx(String(c ?? '')).replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
  a.download = name;
  a.click();
}

// ---------- доход за месяц ----------
const report = { month: null, details: false };
async function loadReport() {
  if (!report.month) report.month = todayStr().slice(0, 7);
  const r = await api('GET', `/api/report?month=${report.month}`);
  const cur = state.data.properties[0]?.currency || 'EUR';
  const [y, m] = report.month.split('-').map(Number);
  let html = `<div class="phead"><h1>Доход</h1><span class="grow"></span>
    <div class="stepper"><button id="rPrev" aria-label="Предыдущий месяц">${ic('left')}</button><span style="min-width:150px">${MONN[m - 1]} ${y}</span><button id="rNext" aria-label="Следующий месяц">${ic('right')}</button></div>
    <label class="obtn"><input type="checkbox" id="rDet"${report.details ? ' checked' : ''}> показать брони</label>
    <button class="sbtn orange" id="rCsv">${ic('download')} Скачать CSV</button></div>
    <div class="kpis">
      <div><span>Загрузка</span><b>${r.totals.occupancy} %</b></div>
      <div><span>Ночей продано</span><b>${r.totals.nights}</b></div>
      <div><span>Доход</span><b>${money(r.totals.gross, cur)}</b></div>
      <div><span>Чистыми</span><b>${money(r.totals.net, cur)}</b></div>
    </div>
    <div class="tcard"><div class="tscroll"><table class="ltable"><thead><tr><th>Квартира</th><th class="num">Ночей</th><th class="num">Загрузка</th><th class="num">Броней</th><th class="num">Средняя цена</th><th class="num">Доход</th><th class="num">Чистыми</th><th class="num">Удержано ноч.</th></tr></thead><tbody>`;
  for (const row of r.rows) {
    html += `<tr><td><b>${esc(row.name)}</b>${row.no_amount ? ` <span class="badge warn" title="У части броней не указана сумма">без суммы: ${row.no_amount}</span>` : ''}</td>
      <td class="num">${row.nights}</td><td class="num"><span class="occ" style="--o:${Math.min(100, row.occupancy)}%">${row.occupancy} %</span></td><td class="num">${row.bookings}</td>
      <td class="num">${money(row.adr, row.currency)}</td><td class="num">${money(row.gross, row.currency)}</td><td class="num">${money(row.net, row.currency)}</td><td class="num">${row.hold_nights || ''}</td></tr>`;
  }
  html += `</tbody><tfoot><tr><td>Итого</td><td class="num">${r.totals.nights}</td><td class="num">${r.totals.occupancy} %</td><td class="num">${r.totals.bookings}</td><td></td>
    <td class="num">${money(r.totals.gross, cur)}</td><td class="num">${money(r.totals.net, cur)}</td><td class="num">${r.totals.hold_nights || ''}</td></tr></tfoot></table></div></div>
    <div class="muted small" style="margin:0 2px 14px">Доход распределён по ночам этого месяца. «Чистыми» — после комиссий каналов (вкладка «Комиссии»).</div>`;
  if (report.details) {
    html += `<div class="tcard"><div class="tscroll"><table class="ltable"><thead><tr><th>Квартира</th><th>Гость</th><th>Источник</th><th>Заезд</th><th>Выезд</th><th class="num">Ночей в месяце</th><th class="num">Сумма брони</th><th class="num">Доход месяца</th><th class="num">Чистыми</th></tr></thead><tbody>
      ${r.items.map((i) => `<tr data-open="${i.id}"><td>${esc(i.property_name)}</td><td>${esc(i.guest_name || '—')}</td><td>${esc(i.source)}</td><td>${short(i.check_in)}</td><td>${short(i.check_out)}</td>
        <td class="num">${i.nights_in_month} из ${i.nights}</td><td class="num">${money(i.total, cur)}</td><td class="num">${money(i.gross_month, cur)}</td><td class="num">${money(i.net_month, cur)}</td></tr>`).join('')}
      </tbody></table></div></div>`;
  }
  $('report').innerHTML = html;
  const go = (mm) => { report.month = mm; loadReport().catch((e) => toast(e.message, true)); };
  $('rPrev').onclick = () => go(addMonths(`${report.month}-01`, -1).slice(0, 7));
  $('rNext').onclick = () => go(addMonths(`${report.month}-01`, 1).slice(0, 7));
  $('rDet').onchange = () => { report.details = $('rDet').checked; loadReport(); };
  $('rCsv').onclick = () => downloadCsv(`dohod-${report.month}.csv`, [
    ['Квартира', 'Гость', 'Источник', 'Заезд', 'Выезд', 'Ночей в месяце', 'Ночей всего', 'Сумма брони', 'Доход месяца', 'Чистыми'],
    ...r.items.map((i) => [i.property_name, i.guest_name, i.source, i.check_in, i.check_out, i.nights_in_month, i.nights, i.total ?? '', i.gross_month, i.net_month]),
  ]);
}
$('report').addEventListener('click', (e) => {
  const tr = e.target.closest('tr[data-open]');
  if (tr) openBooking(Number(tr.dataset.open));
});

// ---------- квартиры (список, как Rental List) ----------
const plist = { q: '', tag: '' };
function renderProps() {
  const can = P();
  const all = state.data.properties;
  const tags = [...new Set(all.flatMap((p) => (p.tags || '').split(',').map((s) => s.trim()).filter(Boolean)))];
  const q = plist.q.trim().toLowerCase();
  const rows = all.filter((p) => (!q || `${p.name} ${p.address || ''} ${p.registration_number || ''}`.toLowerCase().includes(q))
    && (!plist.tag || (p.tags || '').split(',').map((s) => s.trim()).includes(plist.tag)));
  let html = `<div class="phead"><h1>Квартиры</h1><span class="grow"></span>
    ${can.prices ? `<button class="sbtn orange" id="pPrices">${ic('coin')} Цены и ограничения</button>` : ''}
    ${can.properties ? `<button class="sbtn blue" id="pAdd">${ic('plus')} Добавить квартиру</button>` : ''}</div>
    <div class="tcard"><div class="tfilters">
      ${tags.length ? `<select id="p_tag"><option value="">Все теги</option>${tags.map((t) => `<option${t === plist.tag ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>` : ''}
      <button class="ibtn line" id="pClear" title="Сбросить фильтры">${ic('filterx')}</button>
      <span class="grow"></span><input id="p_q" type="search" placeholder="Поиск…" value="${esc(plist.q)}">
    </div>`;
  if (!rows.length) html += `<div class="empty">${all.length ? 'Ничего не найдено.' : 'Квартир пока нет. Нажмите «Добавить квартиру».'}</div>`;
  else {
    html += `<div class="tscroll"><table class="ltable"><thead><tr><th>Название</th><th>${ic('user')} Гостей</th><th>Адрес</th><th>Лицензия VV</th>${can.money ? '<th class="num">Цена</th><th class="num">Уборка</th>' : ''}<th>Заезд / выезд</th><th>Channex</th><th>Готова</th><th></th></tr></thead><tbody>`;
    for (const p of rows) {
      html += `<tr data-pid="${p.id}"${p.active === 0 ? ' class="cancelled"' : ''}>
        <td><span class="gname" style="--pc:${esc(pColor(p))}"><span class="thumb${p.cover_photo_id ? ' ph' : ''}" style="width:30px;height:30px;font-size:10px">${p.cover_photo_id ? `<img src="${photoUrl(p.cover_photo_id)}" alt="" loading="lazy">` : esc(thumbText(p.name))}</span><span>${esc(p.name)}</span>${p.photo_count ? `<span class="pcnt" title="Фотографий: ${p.photo_count}">${ic('image')} ${p.photo_count}</span>` : ''}</span></td>
        <td>${p.max_guests || '—'}</td><td>${esc(p.address || '—')}</td><td>${esc(p.registration_number || '—')}</td>
        ${can.money ? `<td class="num">${money(p.base_price, p.currency)}</td><td class="num">${money(p.cleaning_fee || 0, p.currency)}</td>` : ''}
        <td>${esc(p.check_in_time || '—')} / ${esc(p.check_out_time || '—')}</td>
        <td>${p.channex_property_id ? '<span class="pill confirmed">связана</span>' : '<span class="muted">—</span>'}</td>
        <td>${p.ready === 0 ? '🧹' : `<span class="rdycheck">${ic('check')}</span>`}</td>
        <td>${can.properties ? `<button class="cpy" title="Изменить" aria-label="Изменить">${ic('dots')}</button>` : ''}</td></tr>`;
    }
    html += '</tbody></table></div>';
    html += `<div class="pager"><span>${rows.length} из ${all.length}</span><span class="grow"></span><span class="muted">${all.filter((p) => p.channex_property_id).length} связано с Channex</span></div>`;
  }
  html += '</div>';
  $('props').innerHTML = html;
  if ($('pAdd')) $('pAdd').onclick = openNewProp;
  if ($('pPrices')) $('pPrices').onclick = () => openPriceDrawer({ property_ids: [], date_from: todayStr(), date_to: addDays(todayStr(), 29) });
  if ($('p_tag')) $('p_tag').onchange = () => { plist.tag = $('p_tag').value; renderProps(); };
  $('pClear').onclick = () => { plist.q = ''; plist.tag = ''; renderProps(); };
  $('p_q').oninput = () => { plist.q = $('p_q').value; renderProps(); const el = $('p_q'); el.focus(); el.setSelectionRange(el.value.length, el.value.length); };
}
$('props').addEventListener('click', async (e) => {
  const tr = e.target.closest('tr[data-pid]');
  if (!tr) return;
  const p = state.data.properties.find((x) => x.id === Number(tr.dataset.pid));
  if (!p) return;
  if (P().properties) return openPropForm(p);
  // остальным — просто посмотреть фото квартиры
  if (p.photo_count) {
    try { openLightbox(await api('GET', `/api/properties/${p.id}/photos`), 0, { property: p }); } catch (ex) { toast(ex.message, true); }
  }
});

// ---------- переключение разделов ----------
const VIEWS = ['cal', 'agenda', 'list', 'report', 'props'];
function setView(v) {
  if (!VIEWS.includes(v)) return;
  state.view = v;
  for (const k of VIEWS) $(k).hidden = k !== v;
  document.querySelectorAll('#snav .si, #bnav [data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
  document.querySelectorAll('#tabs .tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === v));
  closePop();
  hideHover();
  const loaders = { agenda: loadAgenda, list: loadList, report: loadReport, props: async () => renderProps() };
  if (loaders[v]) loaders[v]().catch((e) => toast(e.message, true));
  if (v === 'cal') render();
  $('cal').closest('.page').scrollTop = 0;
}

// ---------- окна настроек ----------
function openModal(html) { $('box').innerHTML = html; $('modal').classList.remove('hidden'); }
function closeModal() { $('modal').classList.add('hidden'); $('box').innerHTML = ''; }
$('modal').addEventListener('mousedown', (e) => { if (e.target === $('modal')) closeModal(); });

function openNewProp() {
  openModal(`<h2>Новая квартира</h2>
    <div class="g2"><div class="span2"><label>Название</label><input id="n_name" placeholder="0.1 Olympia Studio"></div>
    <div><label>Цена за ночь</label><input id="n_price" type="number" value="100"></div>
    <div><label>Уборка за проживание</label><input id="n_clean" type="number" value="0"></div></div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button><button class="primary" id="n_add">Добавить</button></div>`);
  $('x_close').onclick = closeModal;
  $('n_name').focus();
  $('n_add').onclick = async () => {
    try {
      await api('POST', '/api/properties', { name: val('n_name'), base_price: Number(val('n_price')), cleaning_fee: Number(val('n_clean')) || 0 });
      closeModal(); await refreshAll(); toast('Квартира добавлена');
    } catch (e) { setErr(e.message); }
  };
}
function openPropForm(p) {
  if (!p) return;
  openModal(`<h2>${esc(p.name)}</h2>
    <h3 style="margin-top:6px">Фотографии</h3>
    <div class="gal" id="pf_gal"><div class="muted small">Загружаю фото…</div></div>
    <input type="file" id="pf_files" accept="image/*" multiple hidden>
    <div class="g2">
      <div class="span2"><label>Название</label><input id="pf_name" value="${esc(p.name)}"></div>
      <div><label>Базовая цена за ночь</label><input id="pf_price" type="number" step="0.01" value="${p.base_price ?? ''}"></div>
      <div><label>Уборка за проживание</label><input id="pf_clean" type="number" step="0.01" value="${p.cleaning_fee ?? 0}"></div>
      <div><label>Время заезда</label><input id="pf_in" type="time" value="${esc(p.check_in_time || '16:00')}"></div>
      <div><label>Время выезда</label><input id="pf_out" type="time" value="${esc(p.check_out_time || '11:00')}"></div>
      <div><label>Макс. гостей</label><input id="pf_max" type="number" min="1" value="${p.max_guests ?? ''}"></div>
      <div><label>Теги</label><input id="pf_tags" value="${esc(p.tags || '')}" placeholder="Адехе, студия"></div>
    </div>
    <label>Цвет полоски на шахматке</label>${colorPicker(p.color, '', ['', ...PCOLORS])}
    <h3>Адрес и заселение</h3>
    <div class="g2">
      <div class="span2"><label>Адрес</label><input id="pf_addr" value="${esc(p.address || '')}" placeholder="Avenida de España, 5, Costa Adeje"></div>
      <div><label>Лицензия VV</label><input id="pf_reg" value="${esc(p.registration_number || '')}" placeholder="VV-38-4-00…"></div>
      <div><label>Код двери / сейфа</label><input id="pf_code" value="${esc(p.door_code || '')}"></div>
      <div><label>Wi-Fi сеть</label><input id="pf_wn" value="${esc(p.wifi_name || '')}"></div>
      <div><label>Wi-Fi пароль</label><input id="pf_wp" value="${esc(p.wifi_password || '')}"></div>
    </div>
    <label>Как заселиться (для гостя)</label><textarea id="pf_ci" rows="3" placeholder="Где ключ, как пройти, парковка">${esc(p.checkin_instructions || '')}</textarea>
    <label>Правила дома</label><textarea id="pf_rules" rows="2">${esc(p.house_rules || '')}</textarea>
    <label>Служебные заметки (видит только персонал)</label><textarea id="pf_staff" rows="2">${esc(p.staff_notes || '')}</textarea>
    <label class="chk" style="margin-top:12px"><input type="checkbox" id="pf_active"${p.active !== 0 ? ' checked' : ''}> Показывать на шахматке</label>
    ${P().channex && !p.channex_property_id ? '<div class="btns" style="justify-content:flex-start"><button id="pf_cx">Создать в Channex</button></div>' : ''}
    <div class="err" id="err"></div>
    <div class="btns"><button id="pf_back">Закрыть</button><button class="primary" id="pf_save">Сохранить</button></div>`);
  $('pf_back').onclick = closeModal;
  bindGallery(p);
  $('pf_save').onclick = async () => {
    try {
      await api('PUT', `/api/properties/${p.id}`, {
        name: val('pf_name'), base_price: Number(val('pf_price')), cleaning_fee: Number(val('pf_clean')) || 0, check_in_time: val('pf_in'), check_out_time: val('pf_out'),
        max_guests: numVal('pf_max'), tags: val('pf_tags'), color: document.querySelector('input[name="d_color"]:checked')?.value || null, active: $('pf_active').checked,
        address: val('pf_addr'), registration_number: val('pf_reg'), door_code: val('pf_code'), wifi_name: val('pf_wn'), wifi_password: val('pf_wp'),
        checkin_instructions: val('pf_ci'), house_rules: val('pf_rules'), staff_notes: val('pf_staff'),
      });
      closeModal(); await refreshAll(); toast('Сохранено');
    } catch (e) { setErr(e.message); }
  };
  if ($('pf_cx')) $('pf_cx').onclick = async () => {
    try { await api('POST', `/api/channex/setup/${p.id}`); closeModal(); await refreshAll(); toast('Создано в Channex, цены и доступность отправлены'); } catch (e) { setErr(e.message); }
  };
}
async function openSources() {
  openModal(`<h2>Источники броней</h2><div class="muted small">По одному в строке. Брони из Booking.com и Airbnb получают источник автоматически.</div>
    <textarea id="src_list" rows="10" style="margin-top:10px">${esc(state.sources.join('\n'))}</textarea><div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button><button class="primary" id="src_save">Сохранить</button></div>`);
  $('x_close').onclick = closeModal;
  $('src_save').onclick = async () => {
    try { state.sources = await api('PUT', '/api/sources', { sources: val('src_list').split('\n') }); closeModal(); toast('Сохранено'); } catch (e) { setErr(e.message); }
  };
}
async function openCommissions(editId = null) {
  const rules = await api('GET', '/api/commission-rules');
  const props = state.data.properties;
  const pname = (id) => (id ? props.find((p) => p.id === id)?.name || `#${id}` : 'Все квартиры');
  const channels = [...new Set(['Booking.com', 'Airbnb', 'Expedia', ...state.sources])];
  const e = rules.find((r) => r.id === editId) || { channel: 'Booking.com', property_id: null, percent: 15, add_fixed: 0, sub_fixed: 0, note: '' };
  openModal(`<h2>Комиссии каналов</h2>
    <div class="muted small">Чистыми = (сумма брони + прибавка) × (1 − комиссия %) − вычет. Правило для квартиры важнее общего. Пример из AdvanceCM: Booking.com, 17,4 %, прибавка 50 (уборка).</div>
    <div class="plist" style="margin-top:10px">${rules.map((r) => `<div class="prow"><span><b>${esc(r.channel === '*' ? 'Любой канал' : r.channel)}</b> · ${esc(pname(r.property_id))}<br>
      <span class="muted small">${r.percent} %${r.add_fixed ? ` · +${r.add_fixed}` : ''}${r.sub_fixed ? ` · −${r.sub_fixed}` : ''}${r.note ? ' · ' + esc(r.note) : ''}</span></span>
      <span><button data-ce="${r.id}">Изменить</button> <button class="danger" data-cd="${r.id}" aria-label="Удалить">×</button></span></div>`).join('') || '<div class="muted">Правил пока нет — чистый доход равен сумме брони.</div>'}</div>
    <h3>${editId ? 'Изменить правило' : 'Новое правило'}</h3>
    <div class="g2">
      <div><label>Канал</label><select id="cm_ch"><option value="*"${e.channel === '*' ? ' selected' : ''}>Любой канал</option>${channels.map((c) => `<option${c === e.channel ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
      <div><label>Квартира</label><select id="cm_p"><option value="">Все квартиры</option>${props.map((p) => `<option value="${p.id}"${p.id === e.property_id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>
      <div><label>Комиссия, %</label><input id="cm_pct" type="number" step="0.01" value="${e.percent}"></div>
      <div><label>Прибавить до комиссии</label><input id="cm_add" type="number" step="0.01" value="${e.add_fixed}"></div>
      <div><label>Вычесть после комиссии</label><input id="cm_sub" type="number" step="0.01" value="${e.sub_fixed}"></div>
      <div><label>Заметка</label><input id="cm_note" value="${esc(e.note)}"></div>
    </div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button>${editId ? '<button id="cm_new">Новое правило</button>' : ''}<button class="primary" id="cm_save">${editId ? 'Сохранить' : 'Добавить'}</button></div>`);
  $('x_close').onclick = closeModal;
  if ($('cm_new')) $('cm_new').onclick = () => openCommissions();
  document.querySelectorAll('[data-ce]').forEach((b) => (b.onclick = () => openCommissions(Number(b.dataset.ce))));
  document.querySelectorAll('[data-cd]').forEach((b) => (b.onclick = async () => {
    if (!confirm('Удалить правило?')) return;
    try { await api('DELETE', `/api/commission-rules/${b.dataset.cd}`); openCommissions(); } catch (err) { setErr(err.message); }
  }));
  $('cm_save').onclick = async () => {
    try {
      await api('POST', '/api/commission-rules', { id: editId || undefined, channel: val('cm_ch'), property_id: val('cm_p') || null, percent: Number(val('cm_pct')), add_fixed: Number(val('cm_add')) || 0, sub_fixed: Number(val('cm_sub')) || 0, note: val('cm_note') });
      toast('Сохранено');
      openCommissions();
    } catch (err) { setErr(err.message); }
  };
}
async function openChannex() {
  const st = await api('GET', '/api/sync/status');
  openModal(`<h2>Каналы (Channex)</h2>
    <div class="muted small">Адрес: ${esc(st.base_url)} · ключ: ${esc(st.api_key) || 'не задан'} · связано квартир: ${st.linked} из ${st.total} · в очереди: ${st.pending} · ошибок: ${st.failed}</div>
    <label>API-ключ</label><input id="c_key" placeholder="вставьте ключ, чтобы заменить" autocomplete="off">
    <label>Адрес API (staging — для тестов, app.channex.io/api/v1 — боевой)</label><input id="c_url" value="${esc(st.base_url)}">
    <div class="btns" style="justify-content:flex-start"><button id="c_save">Сохранить</button><button id="c_poll">Забрать брони сейчас</button></div>
    <div class="log">${st.log.map((l) => `<div class="${l.ok ? '' : 'bad'}">${esc(l.ts)} · ${esc(l.kind)} · ${esc(l.message)}</div>`).join('')}</div>
    <div class="err" id="err"></div><div class="btns"><button id="x_close">Закрыть</button></div>`);
  $('x_close').onclick = closeModal;
  $('c_save').onclick = async () => { try { await api('POST', '/api/channex/settings', { api_key: val('c_key'), base_url: val('c_url') }); toast('Сохранено'); refreshStatus(); } catch (e) { setErr(e.message); } };
  $('c_poll').onclick = async () => { try { await api('POST', '/api/channex/poll'); await refreshAll(); toast('Готово'); } catch (e) { setErr(e.message); } };
}
const ROLE_HINT = {
  chief: 'всё, включая пользователей и Channex', admin: 'брони, цены, квартиры, журнал', manager: 'брони и цены',
  housekeeper: 'шахматка и заезды без денег и контактов, заметки, «готова»', technician: 'удержания на ремонт, заметки', owner: 'только свои квартиры, без контактов гостей',
};
async function openUsers() {
  const users = await api('GET', '/api/users');
  openModal(`<h2>Пользователи</h2>
    <div class="plist">${users.map((u) => `<div class="prow urow" data-id="${u.id}"><span>${esc(u.name)} <span class="badge">${esc(u.login)}</span> ${u.active ? '' : '<span class="badge warn">отключён</span>'}<br><span class="muted small">${esc(state.roles[u.role])}${u.role === 'owner' ? ' · квартир: ' + u.property_ids.length : ''}${u.lang ? ` · <span translate="no">${u.lang.toUpperCase()}</span>` : ''}</span></span><button class="u_edit">Изменить</button></div>`).join('')}</div>
    <div class="btns"><button id="u_close">Закрыть</button><button class="primary" id="u_new">Добавить пользователя</button></div><div class="err" id="err"></div>`);
  $('u_close').onclick = closeModal;
  $('u_new').onclick = () => userForm(null);
  document.querySelectorAll('.u_edit').forEach((b) => (b.onclick = () => userForm(users.find((u) => u.id === Number(b.closest('.urow').dataset.id)))));
}
function userForm(u) {
  openModal(`<h2>${u ? 'Пользователь' : 'Новый пользователь'}</h2>
    <div class="g2"><div><label>Имя</label><input id="u_name" value="${esc(u?.name)}"></div>
    <div><label>Логин</label><input id="u_login" value="${esc(u?.login)}"${u ? ' disabled' : ''} autocapitalize="none"></div></div>
    <label>Роль</label><select id="u_role">${Object.entries(state.roles).map(([k, v]) => `<option value="${k}"${k === (u?.role || 'manager') ? ' selected' : ''}>${esc(v)} — ${esc(ROLE_HINT[k] || '')}</option>`).join('')}</select>
    <div id="u_props_wrap"><label>Какие квартиры видит собственник</label><div class="plist">${state.data.properties.map((p) => `<label class="chk"><input type="checkbox" class="u_prop" value="${p.id}"${(u?.property_ids || []).includes(p.id) ? ' checked' : ''}> ${esc(p.name)}</label>`).join('')}</div></div>
    <label>Язык интерфейса</label><select id="u_lang"><option value="">Как выбрано на устройстве</option>${Object.entries(LANGS).map(([k, v]) => `<option value="${k}" translate="no"${u?.lang === k ? ' selected' : ''}>${v}</option>`).join('')}</select>
    <label>${u ? 'Новый пароль (пусто — не менять)' : 'Пароль (не короче 8 символов)'}</label><input id="u_pw" type="text" autocomplete="off">
    ${u ? `<label class="chk" style="margin-top:12px"><input type="checkbox" id="u_active"${u.active ? ' checked' : ''}> Доступ разрешён</label>` : ''}
    <div class="err" id="err"></div>
    <div class="btns"><button id="u_back">Назад</button><button class="primary" id="u_save">Сохранить</button></div>`);
  const sync = () => { $('u_props_wrap').hidden = $('u_role').value !== 'owner'; };
  $('u_role').onchange = sync; sync();
  $('u_back').onclick = openUsers;
  $('u_save').onclick = async () => {
    const body = { name: val('u_name'), role: val('u_role'), lang: val('u_lang'), property_ids: [...document.querySelectorAll('.u_prop:checked')].map((c) => Number(c.value)) };
    if (val('u_pw')) body.password = val('u_pw');
    try {
      if (u) { body.active = $('u_active').checked; await api('PUT', `/api/users/${u.id}`, body); } else { body.login = val('u_login'); body.password = val('u_pw'); await api('POST', '/api/users', body); }
      toast('Сохранено'); openUsers();
    } catch (e) { setErr(e.message); }
  };
}
async function openAudit() {
  const rows = await api('GET', '/api/audit');
  openModal(`<h2>Журнал действий</h2><div class="log tall">${rows.map((r) => `<div><b>${esc(r.ts)}</b> · ${esc(r.user_name)} · ${esc(r.action)}${r.details ? ' · ' + esc(r.details) : ''}</div>`).join('') || 'Пока пусто'}</div>
    <div class="btns"><button id="a_close">Закрыть</button></div>`);
  $('a_close').onclick = closeModal;
}
// ---------- фото квартир ----------
// Браузер сам уменьшает снимок (длинная сторона до 2048 px) и делает миниатюру 480 px.
// При перекодировании в JPEG пропадают EXIF-данные, в том числе геометка.
const PHOTO_SIDE = 2048;
const THUMB_SIDE = 480;
const photoUrl = (id, size = 'thumb') => `/api/photos/${id}/${size}`;
const isImageFile = (f) => /^image\//.test(f.type) || /\.(jpe?g|png|webp|heic|heif|gif|bmp|avif)$/i.test(f.name);

async function loadImage(file) {
  if (window.createImageBitmap) {
    // учитывает поворот снимка из EXIF
    try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch { /* попробуем через <img> */ }
  }
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.src = url;
  try { await img.decode(); } catch {
    URL.revokeObjectURL(url);
    throw new Error(`«${file.name}»: этот формат браузер не открывает — сохраните фото как JPEG`);
  }
  img.dataset.url = url;
  return img;
}
function scaledCanvas(src, max) {
  const w0 = src.naturalWidth || src.width;
  const h0 = src.naturalHeight || src.height;
  const k = Math.min(1, max / Math.max(w0, h0));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w0 * k));
  c.height = Math.max(1, Math.round(h0 * k));
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; // прозрачный PNG — на белом фоне
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(src, 0, 0, c.width, c.height);
  return c;
}
const canvasJpeg = (c, q) => new Promise((ok, no) => c.toBlob((b) => (b ? ok(b) : no(new Error('Не удалось сжать фото'))), 'image/jpeg', q));
async function preparePhoto(file) {
  const src = await loadImage(file);
  try {
    const full = scaledCanvas(src, PHOTO_SIDE);
    const thumb = scaledCanvas(full, THUMB_SIDE);
    return { full: await canvasJpeg(full, 0.86), thumb: await canvasJpeg(thumb, 0.8) };
  } finally {
    if (src.close) src.close();
    if (src.dataset?.url) URL.revokeObjectURL(src.dataset.url);
  }
}
async function uploadPhoto(propertyId, file) {
  const { full, thumb } = await preparePhoto(file);
  const fd = new FormData();
  fd.append('photo', full, 'photo.jpg');
  fd.append('thumb', thumb, 'thumb.jpg');
  const r = await fetch(`/api/properties/${propertyId}/photos`, { method: 'POST', body: fd });
  let data = {};
  try { data = await r.json(); } catch { /* пустой ответ */ }
  if (r.status === 401) { location.href = '/login.html'; throw new Error('Нужен вход'); }
  if (!r.ok) throw new Error(data.error || `Ошибка ${r.status}`);
  return data;
}

// Галерея в карточке квартиры: загрузка (кнопкой или перетаскиванием), просмотр, обложка, порядок.
async function renderGallery(p) {
  if (!$('pf_gal')) return;
  let photos;
  try { photos = await api('GET', `/api/properties/${p.id}/photos`); } catch (e) {
    if ($('pf_gal')) $('pf_gal').innerHTML = `<div class="err">${esc(e.message)}</div>`;
    return;
  }
  const box = $('pf_gal');
  if (!box) return; // окно уже закрыли
  box.photos = photos;
  box.innerHTML = `<div class="gal-grid">${photos.map((f, i) => `<button type="button" class="gt" data-ph="${i}" title="${esc(f.caption || 'Открыть')}">
      <img src="${f.thumb_url}" alt="${esc(f.caption || '')}" loading="lazy">${i === 0 ? '<span class="gcover">Обложка</span>' : ''}</button>`).join('')}
    <button type="button" class="gt gadd" id="pf_add">${ic('camera')}<span>Добавить фото</span></button></div>
    <div class="muted small gmsg" id="pf_galmsg">${photos.length
      ? `${photos.length} фото. Нажмите на фото, чтобы посмотреть, сделать обложкой, подписать или удалить.`
      : 'Можно выбрать сразу несколько. Фото уменьшаются до 2048 px, геометка удаляется.'}</div>`;
}
function bindGallery(p) {
  const box = $('pf_gal');
  const busy = (on) => { box.classList.toggle('busy', on); if ($('pf_add')) $('pf_add').disabled = on; };
  const msg = (t) => { if ($('pf_galmsg')) $('pf_galmsg').textContent = t; };
  const afterChange = async () => { await renderGallery(p); refreshAll().catch(() => {}); };
  async function addFiles(files) {
    const list = [...files].filter(isImageFile);
    if (!list.length) return toast('Выберите фотографии', true);
    busy(true);
    let ok = 0;
    const errors = [];
    for (let i = 0; i < list.length; i++) {
      msg(`Загружаю ${i + 1} из ${list.length}…`);
      try { await uploadPhoto(p.id, list[i]); ok++; } catch (e) {
        errors.push(e.message);
        if (/Не больше|место|Нужен вход/.test(e.message)) break;
      }
    }
    busy(false);
    if (!$('pf_gal')) return;
    await afterChange();
    if (errors.length) toast(`${ok ? `Добавлено: ${ok}. ` : ''}${errors[0]}${errors.length > 1 ? ` (ошибок: ${errors.length})` : ''}`, true);
    else toast(ok === 1 ? 'Фото добавлено' : `Добавлено фото: ${ok}`);
  }
  $('pf_files').onchange = () => { const f = [...$('pf_files').files]; $('pf_files').value = ''; if (f.length) addFiles(f); };
  box.onclick = (e) => {
    if (e.target.closest('#pf_add')) return $('pf_files').click();
    const t = e.target.closest('[data-ph]');
    if (t) openLightbox(box.photos, Number(t.dataset.ph), { property: p, edit: true, onChange: afterChange });
  };
  box.ondragover = (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { e.preventDefault(); box.classList.add('drop'); } };
  box.ondragleave = (e) => { if (!box.contains(e.relatedTarget)) box.classList.remove('drop'); };
  box.ondrop = (e) => { e.preventDefault(); box.classList.remove('drop'); if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files); };
  renderGallery(p);
}

// Лента миниатюр в карточке брони — горничной и менеджеру видно, как выглядит квартира.
async function fillPhotoStrip(el, p) {
  try {
    const list = await api('GET', `/api/properties/${p.id}/photos`);
    if (!el.isConnected) return;
    if (!list.length) return el.remove();
    el.innerHTML = list.map((f, i) => `<button type="button" class="pst" data-i="${i}" title="${esc(f.caption || 'Открыть')}"><img src="${f.thumb_url}" alt="${esc(f.caption || '')}" loading="lazy"></button>`).join('');
    el.onclick = (e) => { const b = e.target.closest('[data-i]'); if (b) openLightbox(list, Number(b.dataset.i), { property: p }); };
  } catch { el.remove(); }
}

// Просмотр на весь экран: стрелки, клавиши ← →, свайп; у кого есть «Квартиры» — обложка, порядок, подпись, удаление.
const lb = { list: [], i: 0, p: null, edit: false, onChange: null, capEdit: false };
function openLightbox(list, i = 0, opts = {}) {
  if (!list || !list.length) return;
  Object.assign(lb, { list, i: Math.min(Math.max(0, i), list.length - 1), p: opts.property || null, edit: !!opts.edit, onChange: opts.onChange || null, capEdit: false });
  let el = $('lb');
  if (!el) {
    el = document.createElement('div');
    el.id = 'lb';
    el.className = 'lb';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    document.body.appendChild(el);
    bindLightbox(el);
  }
  el.hidden = false;
  drawLightbox();
}
function closeLightbox() { const el = $('lb'); if (el) { el.hidden = true; el.innerHTML = ''; } }
function lbGo(d) {
  if (lb.list.length < 2) return;
  lb.i = (lb.i + d + lb.list.length) % lb.list.length;
  lb.capEdit = false;
  drawLightbox();
}
function drawLightbox() {
  const el = $('lb');
  const f = lb.list[lb.i];
  if (!el || !f) return closeLightbox();
  const n = lb.list.length;
  el.innerHTML = `<div class="lbtop"><span class="lbn">${lb.i + 1} / ${n}${lb.p ? ` · ${esc(lb.p.name)}` : ''}</span>
      <button type="button" class="lbx" data-lb="close" aria-label="Закрыть">${ic('x')}</button></div>
    <div class="lbstage" data-lb="stage">
      <img class="lbimg" src="${f.url}" alt="${esc(f.caption || '')}">
      ${n > 1 ? `<button type="button" class="lbnav prev" data-lb="prev" aria-label="Предыдущее фото">‹</button><button type="button" class="lbnav next" data-lb="next" aria-label="Следующее фото">›</button>` : ''}
    </div>
    <div class="lbbot">
      ${lb.capEdit
        ? `<div class="lbcapedit"><input id="lbCap" maxlength="120" value="${esc(f.caption || '')}" placeholder="Например: спальня, вид с балкона"><button type="button" data-lb="capsave">Сохранить</button></div>`
        : f.caption ? `<div class="lbcap">${esc(f.caption)}</div>` : ''}
      ${lb.edit ? `<div class="lbacts">
        <button type="button" data-lb="cover"${lb.i === 0 ? ' disabled' : ''}>${lb.i === 0 ? '★ Обложка' : '☆ Сделать обложкой'}</button>
        <button type="button" data-lb="left"${lb.i === 0 ? ' disabled' : ''} title="Переставить раньше">← Раньше</button>
        <button type="button" data-lb="right"${lb.i === n - 1 ? ' disabled' : ''} title="Переставить позже">Позже →</button>
        <button type="button" data-lb="caption">Подпись</button>
        <button type="button" class="danger" data-lb="del">Удалить</button>
      </div>` : ''}
    </div>`;
  if (lb.capEdit) { const inp = $('lbCap'); inp.focus(); inp.onkeydown = (e) => { if (e.key === 'Enter') el.querySelector('[data-lb="capsave"]').click(); }; }
  for (const j of [lb.i + 1, lb.i - 1]) if (lb.list[j]) new Image().src = lb.list[j].url; // соседние — заранее
}
function bindLightbox(el) {
  let sx = null;
  let sy = 0;
  el.addEventListener('touchstart', (e) => { if (e.touches.length === 1) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; } }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (sx === null) return;
    const dx = e.changedTouches[0].clientX - sx;
    const dy = e.changedTouches[0].clientY - sy;
    sx = null;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5 && !e.target.closest('input')) lbGo(dx < 0 ? 1 : -1);
  });
  el.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-lb]')?.dataset.lb;
    if (!a) return;
    if (a === 'close' || (a === 'stage' && e.target.classList.contains('lbstage'))) return closeLightbox(); // клик по тёмному полю
    if (a === 'stage') return;
    if (a === 'prev') return lbGo(-1);
    if (a === 'next') return lbGo(1);
    if (a === 'caption') { lb.capEdit = !lb.capEdit; return drawLightbox(); }
    if (!lb.edit || !lb.p) return;
    const f = lb.list[lb.i];
    const order = lb.list.map((x) => x.id);
    try {
      if (a === 'capsave') {
        const r = await api('PUT', `/api/photos/${f.id}`, { caption: $('lbCap').value });
        lb.list[lb.i] = { ...f, caption: r.caption };
        lb.capEdit = false;
        toast('Подпись сохранена');
      } else if (a === 'cover' || a === 'left' || a === 'right') {
        const to = a === 'cover' ? 0 : a === 'left' ? lb.i - 1 : lb.i + 1;
        order.splice(lb.i, 1);
        order.splice(to, 0, f.id);
        lb.list = await api('PUT', `/api/properties/${lb.p.id}/photos/order`, { ids: order });
        lb.i = to;
        if (a === 'cover') toast('Это фото теперь обложка');
      } else if (a === 'del') {
        if (!confirm('Удалить это фото?')) return;
        await api('DELETE', `/api/photos/${f.id}`);
        lb.list = lb.list.filter((x) => x.id !== f.id);
        lb.i = Math.min(lb.i, lb.list.length - 1);
        toast('Фото удалено');
      } else return;
      if (lb.onChange) lb.onChange();
      if (!lb.list.length) return closeLightbox();
      drawLightbox();
    } catch (ex) { toast(ex.message, true); }
  });
}

// ---------- интеграции: ключи API и вебхуки ----------
const shortTs = (t) => (t ? String(t).slice(0, 16).replace('T', ' ') : '');
const DELIVERY = { done: 'доставлено', pending: 'в очереди', failed: 'не доставлено' };
// Секрет показывается один раз: после закрытия окна посмотреть его уже нельзя.
function secretBox(sec) {
  return `<div class="secretbox"><b>${esc(sec.title)}</b><br><code id="sec_val">${esc(sec.value)}</code>
    <div class="muted small" style="margin:6px 0">${esc(sec.note)}</div><button id="sec_copy">Скопировать</button></div>`;
}
function bindSecret(sec) {
  if (!sec || !$('sec_copy')) return;
  $('sec_copy').onclick = async () => {
    try { await navigator.clipboard.writeText(sec.value); toast('Скопировано'); } catch { toast('Не удалось скопировать — выделите вручную', true); }
  };
}
function eventChecks(events, picked) {
  return Object.entries(events).map(([k, v]) => `<label class="chk"><input type="checkbox" class="h_ev" value="${k}"${picked.includes('*') || picked.includes(k) ? ' checked' : ''}> ${esc(v)}</label>`).join('');
}
const pickedEvents = (events) => {
  const on = [...document.querySelectorAll('.h_ev:checked')].map((c) => c.value);
  return on.length === Object.keys(events).length ? ['*'] : on;
};
async function openIntegrations(sec = null) {
  const d = await api('GET', '/api/integrations');
  const evText = (h) => (h.events[0] === '*' ? 'все события' : h.events.map((e) => d.events[e] || e).join(', '));
  openModal(`<h2>Интеграции</h2>
    ${sec ? secretBox(sec) : ''}
    <h3>Ключи API</h3>
    <div class="muted small">Ключ нужен внешней системе (например, amoCRM или сайту), чтобы читать и создавать брони. Его передают в заголовке <code>Authorization: Bearer ключ</code>, адрес — <code>${esc(location.origin)}/api/…</code>. Права ключа ограничены: ни пользователей, ни Channex, ни журнала он не видит. Описание — файл API.md в репозитории.</div>
    <div class="plist">${d.api_keys.map((k) => `<div class="prow"><span><b>${esc(k.name)}</b> <span class="badge">${esc(k.prefix)}…</span><br><span class="muted small">${esc(k.access)} · ${k.last_used_at ? 'использован ' + esc(shortTs(k.last_used_at)) + ' UTC' : 'ещё не использовался'}</span></span><button class="danger" data-kdel="${k.id}" data-kname="${esc(k.name)}">Отозвать</button></div>`).join('') || '<div class="muted">Ключей пока нет.</div>'}</div>
    <div class="g2"><div><label>Название нового ключа</label><input id="k_name" placeholder="например, amoCRM" maxlength="60"></div>
    <div><label>Доступ</label><select id="k_preset">${Object.entries(d.presets).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select></div></div>
    <div class="btns" style="justify-content:flex-start;margin-top:10px"><button id="k_add">Создать ключ</button></div>

    <h3>Вебхуки</h3>
    <div class="muted small">Панель сама отправляет событие (новая бронь, отмена, оплата…) на указанный адрес. Каждое сообщение подписано секретом; при ошибке отправка повторяется до 8 раз.</div>
    <div class="plist">${d.webhooks.map((h) => `<div class="prow" data-h="${h.id}" style="flex-wrap:wrap"><span style="min-width:0"><b>${esc(h.name)}</b> ${h.active ? '' : '<span class="badge warn">выключен</span>'}<br>
      <span class="muted small" style="word-break:break-all">${esc(h.url)}<br>${esc(evText(h))} · доставлено: ${h.stats.done}${h.stats.pending ? ` · в очереди: ${h.stats.pending}` : ''}${h.stats.failed ? ` · <span style="color:var(--red)">не доставлено: ${h.stats.failed}</span>` : ''}</span></span>
      <span class="rb"><button data-htest>Проверить</button><button data-hlog>Журнал</button><button data-hedit>Изменить</button></span></div>`).join('') || '<div class="muted">Вебхуков пока нет.</div>'}</div>
    <div class="g2"><div><label>Название</label><input id="h_name" placeholder="например, amoCRM" maxlength="60"></div>
    <div><label>Адрес (https://…)</label><input id="h_url" placeholder="https://…" autocapitalize="none"></div></div>
    <label>Какие события отправлять</label><div class="plist">${eventChecks(d.events, ['*'])}</div>
    <div class="btns" style="justify-content:flex-start;margin-top:10px"><button id="h_add">Добавить вебхук</button></div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button></div>`);
  bindSecret(sec);
  $('box').scrollTop = 0;
  $('x_close').onclick = closeModal;
  $('k_add').onclick = async () => {
    try {
      const k = await api('POST', '/api/api-keys', { name: val('k_name'), preset: val('k_preset') });
      openIntegrations({ title: `Ключ «${k.name}» создан. Скопируйте его сейчас:`, value: k.key, note: 'Потом посмотреть его будет нельзя; если потеряете, отзовите ключ и создайте новый.' });
    } catch (e) { setErr(e.message); }
  };
  document.querySelectorAll('[data-kdel]').forEach((b) => (b.onclick = async () => {
    if (!confirm(`Отозвать ключ «${b.dataset.kname}»? Система, которая им пользуется, сразу потеряет доступ.`)) return;
    try { await api('DELETE', `/api/api-keys/${b.dataset.kdel}`); openIntegrations(); } catch (e) { setErr(e.message); }
  }));
  $('h_add').onclick = async () => {
    const events = pickedEvents(d.events);
    if (!events.length) return setErr('Выберите хотя бы одно событие');
    try {
      const h = await api('POST', '/api/webhooks', { name: val('h_name'), url: val('h_url'), events });
      openIntegrations({ title: `Вебхук «${h.name}» добавлен. Секрет для проверки подписи:`, value: h.secret, note: 'Покажется только сейчас. Внешняя система проверяет по нему подпись X-PMS-Signature.' });
    } catch (e) { setErr(e.message); }
  };
  const hook = (el) => d.webhooks.find((h) => h.id === Number(el.closest('[data-h]').dataset.h));
  document.querySelectorAll('[data-htest]').forEach((b) => (b.onclick = async () => {
    try { await api('POST', `/api/webhooks/${hook(b).id}/test`); toast('Проверочное событие отправляется — смотрите «Журнал»'); } catch (e) { setErr(e.message); }
  }));
  document.querySelectorAll('[data-hlog]').forEach((b) => (b.onclick = () => openDeliveries(hook(b))));
  document.querySelectorAll('[data-hedit]').forEach((b) => (b.onclick = () => hookForm(hook(b), d.events)));
}
function hookForm(h, events) {
  openModal(`<h2>Вебхук «${esc(h.name)}»</h2>
    <div class="g2"><div><label>Название</label><input id="h_name" value="${esc(h.name)}" maxlength="60"></div>
    <div><label>Адрес (https://…)</label><input id="h_url" value="${esc(h.url)}" autocapitalize="none"></div></div>
    <label>Какие события отправлять</label><div class="plist">${eventChecks(events, h.events)}</div>
    <label class="chk" style="margin-top:12px"><input type="checkbox" id="h_active"${h.active ? ' checked' : ''}> Отправлять события</label>
    <label class="chk"><input type="checkbox" id="h_rotate"> Выпустить новый секрет (старый перестанет подходить)</label>
    <div class="err" id="err"></div>
    <div class="btns"><button id="h_back">Назад</button><button class="danger" id="h_del">Удалить</button><button class="primary" id="h_save">Сохранить</button></div>`);
  $('h_back').onclick = () => openIntegrations();
  $('h_del').onclick = async () => {
    if (!confirm(`Удалить вебхук «${h.name}» вместе с очередью отправки?`)) return;
    try { await api('DELETE', `/api/webhooks/${h.id}`); openIntegrations(); } catch (e) { setErr(e.message); }
  };
  $('h_save').onclick = async () => {
    const ev = pickedEvents(events);
    if (!ev.length) return setErr('Выберите хотя бы одно событие');
    try {
      const r = await api('PUT', `/api/webhooks/${h.id}`, { name: val('h_name'), url: val('h_url'), events: ev, active: $('h_active').checked, rotate_secret: $('h_rotate').checked });
      toast('Сохранено');
      openIntegrations(r.secret ? { title: 'Новый секрет:', value: r.secret, note: 'Покажется только сейчас. Обновите его во внешней системе.' } : null);
    } catch (e) { setErr(e.message); }
  };
}
async function openDeliveries(h) {
  const rows = await api('GET', `/api/webhooks/${h.id}/deliveries`);
  const failed = rows.filter((r) => r.status === 'failed').length;
  openModal(`<h2>Журнал отправки · ${esc(h.name)}</h2>
    <div class="muted small">Последние 40 событий. «В очереди» значит, что отправка ещё идёт или ждёт повтора.</div>
    <div class="log tall">${rows.map((r) => `<div class="${r.status === 'failed' ? 'bad' : ''}"><b>${esc(shortTs(r.created_at))}</b> · ${esc(r.event)} · ${DELIVERY[r.status] || r.status}${r.attempts ? ` · попыток: ${r.attempts}` : ''}${r.last_error ? ` · ${esc(r.last_error)}` : ''}</div>`).join('') || 'Пока ничего не отправлялось'}</div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="d_back">Назад</button>${failed ? `<button id="d_retry">Отправить неудавшиеся заново (${failed})</button>` : ''}<button id="d_refresh">Обновить</button></div>`);
  $('d_back').onclick = () => openIntegrations();
  $('d_refresh').onclick = () => openDeliveries(h);
  if ($('d_retry')) $('d_retry').onclick = async () => {
    try { await api('POST', `/api/webhooks/${h.id}/retry`); toast('Поставлено в очередь'); setTimeout(() => openDeliveries(h), 1500); } catch (e) { setErr(e.message); }
  };
}
function openPassword() {
  openModal(`<h2>Сменить пароль</h2><div class="muted small">${esc(state.me.name)} · ${esc(state.me.role_label)} · логин ${esc(state.me.login)}</div>
    <label>Текущий пароль</label><input id="m_old" type="password" autocomplete="current-password">
    <label>Новый пароль (не короче 8 символов)</label><input id="m_new" type="password" autocomplete="new-password">
    <div class="err" id="err"></div>
    <div class="btns"><button id="m_close">Закрыть</button><button class="primary" id="m_save">Сменить пароль</button></div>`);
  $('m_close').onclick = closeModal;
  $('m_save').onclick = async () => { try { await api('POST', '/api/me/password', { old_password: val('m_old'), new_password: val('m_new') }); closeModal(); toast('Пароль изменён'); } catch (e) { setErr(e.message); } };
}

// ---------- статус синхронизации ----------
async function refreshStatus() {
  if (!P().prices) return;
  const pill = $('syncPill');
  try {
    const s = await api('GET', '/api/sync/status');
    pill.hidden = false;
    if (!s.configured) { pill.className = 'cxpill warn'; pill.innerHTML = '<i></i>Channex не настроен'; return; }
    pill.className = 'cxpill' + (s.failed ? ' bad' : s.pending ? ' warn' : '');
    pill.innerHTML = `<i></i>${s.failed ? `Channex: ошибок ${s.failed}` : s.pending ? `Channex: в очереди ${s.pending}` : 'Channex: всё отправлено'}`;
  } catch { pill.hidden = false; pill.className = 'cxpill bad'; pill.innerHTML = '<i></i>Нет связи'; }
}
$('syncPill').onclick = () => { if (P().channex) openChannex(); };

async function refreshAll() {
  await Promise.all([load(), refreshStatus()]);
  if (state.view === 'agenda') await loadAgenda();
  if (state.view === 'list' && !document.activeElement?.closest?.('#list')) await loadList();
  if (state.view === 'report') await loadReport();
  if (state.view === 'props' && !document.activeElement?.closest?.('#props')) renderProps();
}

document.addEventListener('keydown', (e) => {
  if ($('lb') && !$('lb').hidden) {
    if (e.key === 'Escape') { e.preventDefault(); return closeLightbox(); }
    if (e.target.closest?.('input, textarea')) return;
    if (e.key === 'ArrowLeft') return lbGo(-1);
    if (e.key === 'ArrowRight') return lbGo(1);
    return;
  }
  if (e.key !== 'Escape') return;
  if (!$('modal').classList.contains('hidden')) return closeModal();
  if (!$('dmenu').hidden) return closeMenu();
  if (!$('pop').hidden) { closePop(); return clearSel(); }
  if (!$('drawer').hidden) return closeDrawer();
  if (!$('bm').hidden) return closeBooking();
  if (state.pending) clearSel();
});

async function start() {
  const me = await api('GET', '/api/me');
  if (applyUserLang(me.user.lang)) return; // язык пользователя другой — страница перезагрузится
  state.me = me.user;
  state.perms = me.perms;
  state.roles = me.roles;
  state.holdTypes = me.hold_types || {};
  state.sources = me.sources || [];
  state.from = todayStr();
  initChrome();
  await refreshAll();
  if (state.me.role === 'housekeeper') setView('agenda');
}
start().catch((e) => toast(e.message, true));
setInterval(() => {
  if (document.hidden || state.drag || state.sel || !$('pop').hidden || !$('modal').classList.contains('hidden') || !$('bm').hidden) return;
  if (state.drawer) return;
  refreshAll().catch(() => {});
}, 30000);
