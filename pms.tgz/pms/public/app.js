// Шахматка — главная панель управления. Без библиотек.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const state = {
  view: 'cal', from: null, days: 30, data: null, perms: {}, me: null, roles: {}, holdTypes: {}, sources: [],
  pending: null, drag: null, sel: null, free: null, drawer: null, busy: false,
};
const P = () => state.perms;

// ---------- даты ----------
const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return fmt(d); };
const diffDays = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);
const todayStr = () => fmt(new Date());
const WD = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
const WDF = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
const MON = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MONF = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const short = (s) => { const d = parse(s); return `${d.getDate()} ${MON[d.getMonth()]}`; };
const longDay = (s) => { const d = parse(s); return `${WDF[d.getDay()]}, ${d.getDate()} ${MONF[d.getMonth()]}`; };
const nightsWord = (n) => (n % 10 === 1 && n % 100 !== 11 ? 'ночь' : [2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100) ? 'ночи' : 'ночей');
const CUR = { EUR: '€', USD: '$', RUB: '₽', GBP: '£' };
const money = (n, cur = 'EUR') => (n == null ? '' : `${new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 }).format(n)} ${CUR[cur] || cur}`);

// ---------- сеть ----------
async function api(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = {};
  try { data = await r.json(); } catch { /* пустой ответ */ }
  if (r.status === 401) { location.href = '/login.html'; throw new Error('Нужен вход'); }
  if (!r.ok) throw new Error(data.error || `Ошибка ${r.status}`);
  return data;
}
function toast(msg, bad = false) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast' + (bad ? ' bad' : '');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.add('hidden'), bad ? 6000 : 3000);
}

// ---------- внешний вид брони ----------
const HOLD_ICON = { repair: '🔧', owner: '🏠', tentative: '⏳', other: '⛔' };
function srcKind(b) {
  const s = (b.source || '').toLowerCase();
  if (s.includes('booking')) return 'booking';
  if (s.includes('airbnb')) return 'airbnb';
  if (s.includes('expedia')) return 'expedia';
  if (s.includes('vrbo') || s.includes('homeaway')) return 'vrbo';
  return 'direct';
}
const SRC_ICON = { booking: 'B.', airbnb: 'A', expedia: 'E', vrbo: 'V' };
function srcBadge(b) {
  if (b.kind === 'hold') return `<span class="ic">${HOLD_ICON[b.hold_type] || '⛔'}</span>`;
  const k = srcKind(b);
  if (SRC_ICON[k]) return `<span class="ic ic-${k}">${SRC_ICON[k]}</span>`;
  return `<span class="ic ic-direct">${esc((b.source || '•').slice(0, 2))}</span>`;
}
function barLabel(b) {
  if (b.kind === 'hold') return `${state.holdTypes[b.hold_type] || HOLD_NAMES[b.hold_type] || 'Удержание'}${b.title ? ': ' + b.title : ''}`;
  return b.guest_name || b.source || 'Бронь';
}
const HOLD_NAMES = { repair: 'Ремонт', owner: 'Владелец', tentative: 'Держим для клиента', other: 'Другое' };
function timeLeft(ms) {
  const m = Math.round((ms - Date.now()) / 60000);
  if (m <= 0) return 'истекает';
  if (m < 60) return `${m} мин`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} ч` : `${Math.round(h / 24)} дн`;
}

// ---------- шахматка ----------
async function load() {
  state.data = await api('GET', `/api/calendar?from=${state.from}&days=${state.days}`);
  render();
}

function render() {
  if (!state.data) return;
  const { properties, bookings, daily } = state.data;
  const { from, days } = state;
  const dailyMap = new Map(daily.map((d) => [`${d.property_id}|${d.date}`, d]));
  const t = todayStr();
  const free = state.free;
  const inFree = (ds) => free && ds >= free.from && ds < free.to;

  let html = '<div class="grid"><div class="hrow"><div class="name">Квартира</div>';
  for (let i = 0; i < days; i++) {
    const ds = addDays(from, i);
    const d = parse(ds);
    const we = d.getDay() === 0 || d.getDay() === 6;
    html += `<div class="day${we ? ' we' : ''}${ds === t ? ' today' : ''}${inFree(ds) ? ' frange' : ''}" data-h="${ds}">${WD[d.getDay()]}<b>${d.getDate()}</b><i>${d.getDate() === 1 || i === 0 ? MON[d.getMonth()] : ''}</i></div>`;
  }
  html += '</div>';

  let shownRows = 0;
  for (const p of properties) {
    const fq = free?.map.get(p.id);
    if (free && free.hideBusy && fq && !fq.free) continue;
    shownRows++;
    const dim = free && fq && !fq.free ? ' dim' : '';
    const chip = free && fq
      ? fq.free
        ? `<button class="fchip" data-fbook="${p.id}" title="Оформить бронь на эти даты">${fq.total != null ? money(fq.total, p.currency) : 'свободно'}${fq.warnings.length ? ' ⚠' : ''}</button>`
        : '<span class="fchip busy">занято</span>'
      : '';
    html += `<div class="row${dim}" data-p="${p.id}"><div class="name" style="${p.color ? `--pc:${esc(p.color)}` : ''}" title="${esc(p.name)}${p.ready === 0 ? ' — не готова после выезда' : ''}">
      <span class="pname">${p.ready === 0 ? '<span class="notready" title="Не готова после выезда">🧹</span>' : ''}${esc(p.name)}</span>${chip}</div>`;
    for (let i = 0; i < days; i++) {
      const ds = addDays(from, i);
      const d = parse(ds);
      const we = d.getDay() === 0 || d.getDay() === 6;
      const dl = dailyMap.get(`${p.id}|${ds}`) || {};
      const price = dl.price != null ? dl.price : p.base_price;
      const minStay = dl.min_stay > 1 ? dl.min_stay : null;
      const cls = ['day', we ? 'we' : '', dl.price != null ? 'custom' : '', dl.stop_sell ? 'stop' : '', dl.cta ? 'cta' : '', dl.ctd ? 'ctd' : '', inFree(ds) ? 'frange' : '', ds < t ? 'past' : ''];
      const tip = [dl.stop_sell ? 'продажи закрыты' : '', dl.cta ? 'заезд запрещён' : '', dl.ctd ? 'выезд запрещён' : '', minStay ? `мин. ${minStay} ноч.` : ''].filter(Boolean).join(', ');
      html += `<div class="${cls.filter(Boolean).join(' ')}" data-p="${p.id}" data-d="${ds}"${tip ? ` title="${tip}"` : ''}>${P().money && price != null ? `<span class="pr">${Math.round(price)}</span>` : ''}${minStay ? `<span class="ms">${minStay}</span>` : ''}</div>`;
    }
    html += barsFor(p, bookings.filter((x) => x.property_id === p.id));
    html += '</div>';
  }
  html += '</div>';
  if (!properties.length) html = `<div class="empty">Квартир пока нет.${P().properties ? ' Откройте меню ☰ → «Квартиры» и добавьте первую.' : ''}</div>`;
  else if (!shownRows) html += '<div class="empty">На эти даты свободных квартир нет.</div>';
  const { scrollTop, scrollLeft } = $('cal');
  $('cal').innerHTML = html;
  $('cal').scrollTop = scrollTop;
  $('cal').scrollLeft = scrollLeft;
  paintSelection();
}

function barsFor(p, list) {
  const { from, days } = state;
  const confirmed = list.filter((b) => b.status === 'confirmed');
  let html = '';
  for (const b of list) {
    const s = diffDays(from, b.check_in);
    const e = diffDays(from, b.check_out);
    const startIdx = Math.max(0, s);
    const endIdx = Math.min(days, e);
    if (endIdx <= startIdx && !(s < days && e > 0)) continue;
    const clipL = s < 0;
    const clipR = e > days;
    const left = `calc(var(--name) + ${startIdx} * var(--w) + ${clipL ? '0px' : 'var(--w) / 2'})`;
    const width = `calc(${Math.max(endIdx - startIdx, 0)} * var(--w) - ${clipL ? '0px' : 'var(--w) / 2'} + ${clipR ? '0px' : 'var(--w) / 2'} - 3px)`;
    const cls = ['bar'];
    if (b.kind === 'hold') cls.push('hold', `hold-${b.hold_type || 'other'}`);
    else cls.push(`src-${srcKind(b)}`);
    if (b.status === 'inquiry') {
      cls.push('inquiry');
      if (confirmed.some((c) => c.check_in < b.check_out && c.check_out > b.check_in)) cls.push('low');
    }
    if (b.conflict) cls.push('conflict');
    if (clipL) cls.push('clipl');
    if (clipR) cls.push('clipr');
    const nights = diffDays(b.check_in, b.check_out);
    const marks = [];
    if (b.kind === 'booking' && b.status === 'confirmed' && P().money && !b.from_channel && b.payment_status && b.payment_status !== 'paid') {
      marks.push(`<span class="mk-pay ${b.payment_status}" title="${b.payment_status === 'partial' ? 'Оплачено частично' : 'Не оплачено'}"></span>`);
    }
    if (b.checked_in) marks.push('<span title="Заселён">✓</span>');
    if (b.notes_count) marks.push(`<span title="Заметок: ${b.notes_count}">💬</span>`);
    if (b.kind === 'hold' && b.expires_at) marks.push(`<span class="exp" title="Снимется автоматически">${timeLeft(b.expires_at)}</span>`);
    const guests = b.adults != null ? ` · ${b.adults}${b.children ? '+' + b.children : ''}` : '';
    const tip = `${barLabel(b)} · ${short(b.check_in)} → ${short(b.check_out)} · ${nights} ${nightsWord(nights)}${guests}${b.kind === 'booking' ? ' · ' + b.source : ''}${b.status === 'inquiry' ? ' · ЗАПРОС' : ''}${b.conflict ? ' · ПЕРЕСЕЧЕНИЕ!' : ''}`;
    const style = `left:${left};width:${width}${b.color ? `;--bc:${esc(b.color)}` : ''}`;
    html += `<div class="${cls.join(' ')}${b.color ? ' custom-color' : ''}" data-b="${b.id}" style="${style}" title="${esc(tip)}">${srcBadge(b)}<span class="bl">${b.conflict ? '⚠ ' : ''}${esc(barLabel(b))}</span><span class="marks">${marks.join('')}</span></div>`;
  }
  return html;
}

// ---------- выделение дат мышью или двумя касаниями ----------
function cellAt(x, y) {
  const el = document.elementFromPoint(x, y);
  return el?.closest?.('.row .day') || null;
}
function paintSelection() {
  document.querySelectorAll('.row .day.sel, .row .day.start').forEach((c) => c.classList.remove('sel', 'start'));
  const r = state.drag || state.sel;
  if (r) {
    const [a, b] = r.d0 <= r.d1 ? [r.d0, r.d1] : [r.d1, r.d0];
    document.querySelectorAll(`.row[data-p="${r.pid}"] .day`).forEach((c) => {
      if (c.dataset.d >= a && c.dataset.d <= b) c.classList.add('sel');
    });
  }
  if (state.pending) document.querySelector(`.row[data-p="${state.pending.pid}"] .day[data-d="${state.pending.d}"]`)?.classList.add('start');
}

$('cal').addEventListener('pointerdown', (e) => {
  if (e.button !== 0 || e.target.closest('.bar, .fchip')) return;
  const cell = e.target.closest('.row .day');
  if (!cell) return;
  closePop();
  state.drag = { pid: Number(cell.dataset.p), d0: cell.dataset.d, d1: cell.dataset.d, moved: false, x: e.clientX, y: e.clientY };
  paintSelection();
});
document.addEventListener('pointermove', (e) => {
  const dr = state.drag;
  if (!dr) return;
  const cell = cellAt(e.clientX, e.clientY);
  if (cell && Number(cell.dataset.p) === dr.pid && cell.dataset.d !== dr.d1) {
    dr.d1 = cell.dataset.d;
    dr.moved = true;
    paintSelection();
  }
});
document.addEventListener('pointercancel', () => { if (state.drag) { state.drag = null; paintSelection(); } });
document.addEventListener('pointerup', (e) => {
  const dr = state.drag;
  if (!dr) return;
  state.drag = null;
  let range;
  if (dr.moved && dr.d0 !== dr.d1) range = { pid: dr.pid, d0: dr.d0, d1: dr.d1 };
  else if (state.pending && state.pending.pid === dr.pid) range = { pid: dr.pid, d0: state.pending.d, d1: dr.d0 };
  if (!range) {
    state.pending = { pid: dr.pid, d: dr.d0 };
    paintSelection();
    toast('Заезд выбран. Нажмите последнюю ночь — или ту же дату для одной ночи');
    return;
  }
  // повторное касание той же даты = одна ночь
  state.pending = null;
  $('toast').classList.add('hidden');
  const [a, b] = range.d0 <= range.d1 ? [range.d0, range.d1] : [range.d1, range.d0];
  state.sel = { pid: range.pid, d0: a, d1: b, checkIn: a, checkOut: addDays(b, 1) };
  paintSelection();
  openSelectionPop(e.clientX, e.clientY);
});

// ---------- меню выделенных дат ----------
function closePop() { $('pop').hidden = true; $('pop').innerHTML = ''; }
function clearSel() { state.sel = null; state.pending = null; paintSelection(); }

async function openSelectionPop(x, y) {
  const s = state.sel;
  const p = state.data.properties.find((q) => q.id === s.pid);
  const nights = diffDays(s.checkIn, s.checkOut);
  const pop = $('pop');
  const can = P();
  pop.innerHTML = `
    <div class="ph"><b>${esc(p.name)}</b><br>${short(s.checkIn)} → ${short(s.checkOut)} · ${nights} ${nightsWord(nights)}</div>
    <div class="pq" id="popq">Проверяю…</div>
    <div class="pb">
      ${can.edit_bookings ? '<button class="primary" data-act="book">Бронь</button><button data-act="inquiry">Запрос</button>' : ''}
      ${can.edit_bookings || can.block ? '<button data-act="hold">Удержать</button>' : ''}
      ${can.prices ? '<button data-act="price">Цена и мин. ночей</button>' : ''}
      ${can.prices ? '<button data-act="stop">Закрыть продажи</button><button data-act="open">Открыть продажи</button>' : ''}
    </div>`;
  pop.hidden = false;
  const r = pop.getBoundingClientRect();
  pop.style.left = `${Math.max(8, Math.min(x + 8, innerWidth - r.width - 8))}px`;
  pop.style.top = `${Math.max(8, Math.min(y + 8, innerHeight - r.height - 8))}px`;
  try {
    const [q] = await api('POST', '/api/quote', { property_ids: [s.pid], check_in: s.checkIn, check_out: s.checkOut });
    s.quote = q;
    const el = $('popq');
    if (!el) return;
    el.innerHTML = `${q.free ? '<span class="ok">Свободно</span>' : '<span class="no">Занято</span>'}
      ${q.total != null ? ` · ${money(q.accommodation, p.currency)}${q.cleaning ? ` + уборка ${money(q.cleaning, p.currency)}` : ''} = <b>${money(q.total, p.currency)}</b>` : ''}
      ${q.warnings.length ? `<div class="warn">⚠ ${esc(q.warnings.join(', '))}</div>` : ''}`;
  } catch (e) { $('popq') && ($('popq').textContent = e.message); }
}

$('pop').addEventListener('click', async (e) => {
  const act = e.target.closest('button')?.dataset.act;
  if (!act) return;
  const s = state.sel;
  closePop();
  if (act === 'book' || act === 'inquiry') {
    openBookingDrawer(null, { property_id: s.pid, check_in: s.checkIn, check_out: s.checkOut, status: act === 'inquiry' ? 'inquiry' : 'confirmed', quote: s.quote });
  } else if (act === 'hold') {
    openHoldDrawer(null, { property_id: s.pid, check_in: s.checkIn, check_out: s.checkOut });
  } else if (act === 'price') {
    openPriceDrawer({ property_ids: [s.pid], date_from: s.checkIn, date_to: addDays(s.checkOut, -1) });
  } else if (act === 'stop' || act === 'open') {
    try {
      await api('PUT', '/api/daily', { property_ids: [s.pid], date_from: s.checkIn, date_to: addDays(s.checkOut, -1), stop_sell: act === 'stop' });
      toast(act === 'stop' ? 'Продажи закрыты — уходит в каналы' : 'Продажи открыты — уходит в каналы');
      clearSel();
      await refreshAll();
    } catch (err) { toast(err.message, true); }
  }
});

document.addEventListener('pointerdown', (e) => {
  if (!$('pop').hidden && !e.target.closest('#pop') && !e.target.closest('.row .day')) { closePop(); clearSel(); }
  if (!$('menu').hidden && !e.target.closest('#menu, #menuBtn')) $('menu').hidden = true;
  if (!$('qres').hidden && !e.target.closest('.search')) $('qres').hidden = true;
});

$('cal').addEventListener('click', (e) => {
  const fb = e.target.closest('[data-fbook]');
  if (fb) {
    const pid = Number(fb.dataset.fbook);
    const q = state.free.map.get(pid);
    return openBookingDrawer(null, { property_id: pid, check_in: state.free.from, check_out: state.free.to, status: 'confirmed', quote: q, adults: state.free.guests || undefined });
  }
  const bar = e.target.closest('.bar');
  if (bar) {
    const b = state.data.bookings.find((x) => x.id === Number(bar.dataset.b));
    if (b?.kind === 'hold') openHoldDrawer(b.id);
    else openBookingDrawer(b.id);
  }
});

// ---------- боковая панель ----------
function openDrawer(html) {
  const d = $('drawer');
  d.innerHTML = `<button class="dclose" id="dClose" aria-label="Закрыть">×</button>${html}`;
  d.hidden = false;
  document.body.classList.add('drawer-open');
  $('dClose').onclick = closeDrawer;
}
function closeDrawer() {
  $('drawer').hidden = true;
  $('drawer').innerHTML = '';
  state.drawer = null;
  document.body.classList.remove('drawer-open');
  clearSel();
}
const val = (id) => $(id)?.value ?? '';
const numVal = (id) => (val(id) === '' ? null : Number(val(id)));
const propOptions = (sel) => state.data.properties.map((p) => `<option value="${p.id}"${p.id === sel ? ' selected' : ''}>${esc(p.name)}</option>`).join('');
const COLORS = ['', '#2563eb', '#0f9d6a', '#7c3aed', '#db2777', '#ea580c', '#ca8a04', '#0891b2', '#64748b'];
const colorPicker = (cur, dis) => `<div class="colors">${COLORS.map((c) => `<label class="sw" style="${c ? `background:${c}` : ''}" title="${c ? c : 'по каналу'}"><input type="radio" name="d_color" value="${c}"${(cur || '') === c ? ' checked' : ''}${dis}>${c ? '' : 'авто'}</label>`).join('')}</div>`;
function setErr(m) { const e = $('dErr') || $('err'); if (e) e.textContent = m || ''; }

function notesBlock(b) {
  if (!P().notes || !b.id) return '';
  const list = (b.notes_list || []).map((n) => `<div class="note"><div class="nmeta">${esc(n.user_name || '—')} · ${esc(n.created_at)}</div>${esc(n.text)}</div>`).join('');
  return `<section class="dsec"><h3>Заметки персонала</h3>${list || '<div class="muted">Пока нет</div>'}
    <textarea id="d_note" rows="2" placeholder="Например: поздний выезд, оставили ключи у соседа"></textarea>
    <div class="row-btns"><button id="dNoteAdd">Добавить заметку</button></div></section>`;
}
function bindNotes(b, reopen) {
  if (!$('dNoteAdd')) return;
  $('dNoteAdd').onclick = async () => {
    try { await api('POST', `/api/bookings/${b.id}/notes`, { text: val('d_note') }); await reopen(); refreshAll(); } catch (e) { setErr(e.message); }
  };
}

// ----- бронь / запрос -----
async function openBookingDrawer(id, draft = null) {
  closePop();
  let b;
  if (id) {
    try { b = await api('GET', `/api/bookings/${id}`); } catch (e) { return toast(e.message, true); }
  } else {
    const p = state.data.properties.find((q) => q.id === draft.property_id);
    b = {
      kind: 'booking', status: draft.status || 'confirmed', property_id: draft.property_id, check_in: draft.check_in, check_out: draft.check_out,
      check_in_time: p?.check_in_time || '16:00', check_out_time: p?.check_out_time || '11:00', adults: draft.adults ?? 2, children: 0,
      source: state.sources[0] || 'Прямая', guest_name: draft.guest_name || '', guest_phone: '', guest_email: '', notes: '', tags: '', color: null,
      price_accommodation: draft.quote?.accommodation ?? null, price_cleaning: draft.quote?.cleaning ?? null, price_extra: null,
      payment_status: 'unpaid', paid_amount: null,
    };
  }
  state.drawer = { type: 'booking', id: b.id || null };
  const isNew = !b.id;
  const can = P();
  const editable = can.edit_bookings && b.status !== 'cancelled';
  const dis = editable ? '' : ' disabled';
  const dateDis = editable && !b.from_channel ? '' : ' disabled';
  const prop = state.data.properties.find((q) => q.id === b.property_id);
  const cur = prop?.currency || 'EUR';
  const nights = diffDays(b.check_in, b.check_out);
  const statusBadge = b.status === 'inquiry' ? '<span class="badge inq">Запрос</span>' : b.status === 'cancelled' ? '<span class="badge bad">Отменена</span>' : '<span class="badge ok">Бронь</span>';
  const payBadge = can.money && b.kind === 'booking' && b.payment_status ? `<span class="badge ${b.payment_status === 'paid' ? 'ok' : 'warn'}">${b.payment_status === 'paid' ? 'Оплачено' : b.payment_status === 'partial' ? 'Частично' : 'Не оплачено'}</span>` : '';
  const sources = [...new Set([...(state.sources || []), b.source].filter(Boolean))];

  openDrawer(`
    <div class="dhead">
      <h2>${isNew ? (b.status === 'inquiry' ? 'Новый запрос' : 'Новая бронь') : esc(b.guest_name || 'Без имени')}</h2>
      <div class="badges">${srcBadge(b)} <span class="badge">${esc(b.source)}${b.ota_code ? ' · ' + esc(b.ota_code) : ''}</span> ${statusBadge} ${payBadge} ${b.checked_in ? '<span class="badge ok">Заселён</span>' : ''}</div>
      ${b.conflict ? '<div class="alert">⚠ Пересекается с другой бронью — решите вручную (перенесите в другую квартиру).</div>' : ''}
      ${b.from_channel ? '<div class="muted small">Бронь из канала: даты меняются только в Booking.com / Airbnb. Перенести в другую квартиру можно здесь.</div>' : ''}
    </div>
    ${!isNew && editable ? `<div class="quick">
      ${b.status === 'inquiry' ? '<button class="primary" data-q="confirm">Подтвердить бронь</button>' : ''}
      ${b.status === 'confirmed' && can.money ? `<button data-q="${b.payment_status === 'paid' ? 'unpay' : 'pay'}">${b.payment_status === 'paid' ? 'Снять «оплачено»' : 'Оплачено'}</button>` : ''}
      ${b.status === 'confirmed' ? `<button data-q="checkin">${b.checked_in ? 'Снять «заселён»' : 'Заселён'}</button>` : ''}
      <button class="danger" data-q="cancel">${b.status === 'inquiry' ? 'Отменить запрос' : 'Отменить бронь'}</button>
    </div>` : ''}
    <section class="dsec">
      <label>Квартира</label><select id="d_p"${dis}>${propOptions(b.property_id)}</select>
      <div class="g2">
        <div><label>Заезд</label><input type="date" id="d_in" value="${b.check_in}"${dateDis}></div>
        <div><label>Время</label><input type="time" id="d_tin" value="${esc(b.check_in_time || '')}"${dis}></div>
        <div><label>Выезд</label><input type="date" id="d_out" value="${b.check_out}"${dateDis}></div>
        <div><label>Время</label><input type="time" id="d_tout" value="${esc(b.check_out_time || '')}"${dis}></div>
      </div>
      <div class="muted small" id="d_n">${nights} ${nightsWord(nights)}</div>
      <div id="d_quote" class="small"></div>
    </section>
    <section class="dsec">
      <div class="g2">
        <div class="span2"><label>Гость</label><input id="d_name" value="${esc(b.guest_name)}"${dis} autocomplete="off"></div>
        ${can.contacts ? `<div><label>Телефон</label><input id="d_phone" type="tel" value="${esc(b.guest_phone)}"${dis}></div>
        <div><label>E-mail</label><input id="d_email" type="email" value="${esc(b.guest_email)}"${dis}></div>` : ''}
        <div><label>Взрослые</label><input id="d_ad" type="number" min="0" value="${b.adults ?? ''}"${dis}></div>
        <div><label>Дети</label><input id="d_ch" type="number" min="0" value="${b.children ?? ''}"${dis}></div>
        <div class="span2"><label>Источник</label><select id="d_src"${b.from_channel ? ' disabled' : dis}>${sources.map((s) => `<option${s === b.source ? ' selected' : ''}>${esc(s)}</option>`).join('')}</select></div>
      </div>
    </section>
    ${can.money ? `<section class="dsec">
      <h3>Стоимость, ${esc(CUR[cur] || cur)}</h3>
      <div class="g2">
        <div><label>Проживание</label><input id="d_acc" type="number" step="0.01" value="${b.price_accommodation ?? ''}"${dis}></div>
        <div><label>Уборка</label><input id="d_cln" type="number" step="0.01" value="${b.price_cleaning ?? ''}"${dis}></div>
        <div><label>Доплата (−скидка)</label><input id="d_ext" type="number" step="0.01" value="${b.price_extra ?? ''}"${dis}></div>
        <div><label>Итого</label><input id="d_tot" type="number" step="0.01" value="${b.total ?? ''}"${dis}></div>
        ${b.status !== 'inquiry' || !isNew ? `<div><label>Оплачено</label><input id="d_paid" type="number" step="0.01" value="${b.paid_amount ?? ''}"${dis}></div>` : ''}
      </div>
      ${!isNew && b.net != null && b.net !== b.total ? `<div class="muted small">Чистыми после комиссии канала: <b>${money(b.net, cur)}</b></div>` : ''}
    </section>` : ''}
    <section class="dsec">
      <label>Цвет на шахматке</label>${colorPicker(b.color, dis)}
      <label>Теги</label><input id="d_tags" value="${esc(b.tags)}" placeholder="через запятую: VIP, повторный"${dis}>
      ${can.contacts ? `<label>Комментарий к брони</label><textarea id="d_notes" rows="2"${dis}>${esc(b.notes)}</textarea>` : ''}
      ${!isNew ? `<div class="muted small">Создано: ${esc(b.created_at || '')}${b.created_by_name ? ' · ' + esc(b.created_by_name) : ''}</div>` : ''}
    </section>
    ${!isNew ? propertyInfoBlock(prop, b) : ''}
    ${notesBlock(b)}
    <div class="dErr" id="dErr"></div>
    ${editable ? `<div class="dfoot"><button class="primary" id="dSave">${isNew ? (b.status === 'inquiry' ? 'Создать запрос' : 'Создать бронь') : 'Сохранить'}</button></div>` : ''}
  `);
  if (!isNew) bindGuestText(prop, b);

  // пересчёт ночей и цены при смене дат или квартиры
  const dirty = new Set();
  ['d_acc', 'd_cln', 'd_ext', 'd_tot'].forEach((k) => $(k)?.addEventListener('input', () => dirty.add(k)));
  const recalcTotal = () => {
    if (!$('d_tot') || dirty.has('d_tot')) return;
    const parts = ['d_acc', 'd_cln', 'd_ext'].map(numVal).filter((x) => x != null);
    if (parts.length) $('d_tot').value = Math.round(parts.reduce((a, c) => a + c, 0) * 100) / 100;
  };
  ['d_acc', 'd_cln', 'd_ext'].forEach((k) => $(k)?.addEventListener('input', recalcTotal));
  const requote = async () => {
    const ci = val('d_in');
    const co = val('d_out');
    if (!ci || !co || co <= ci) { $('d_n').textContent = 'Проверьте даты'; return; }
    const n = diffDays(ci, co);
    $('d_n').textContent = `${n} ${nightsWord(n)}`;
    try {
      const [q] = await api('POST', '/api/quote', { property_ids: [Number(val('d_p'))], check_in: ci, check_out: co, exclude_id: b.id || 0 });
      $('d_quote').innerHTML = `${q.free ? '<span class="ok">Свободно</span>' : '<span class="no">Занято другой бронью</span>'}${q.warnings.length ? ` · <span class="warn">⚠ ${esc(q.warnings.join(', '))}</span>` : ''}${q.total != null ? ` · по тарифу ${money(q.total, cur)}` : ''}`;
      if (isNew && q.total != null) {
        if ($('d_acc') && !dirty.has('d_acc')) $('d_acc').value = q.accommodation;
        if ($('d_cln') && !dirty.has('d_cln')) $('d_cln').value = q.cleaning || '';
        recalcTotal();
      }
    } catch { /* без расчёта */ }
  };
  if (editable) {
    ['d_in', 'd_out', 'd_p'].forEach((k) => $(k)?.addEventListener('change', requote));
    requote();
  }

  const collect = () => {
    const body = {
      property_id: Number(val('d_p')), check_in: val('d_in'), check_out: val('d_out'),
      check_in_time: val('d_tin'), check_out_time: val('d_tout'),
      guest_name: val('d_name'), adults: numVal('d_ad'), children: numVal('d_ch'),
      tags: val('d_tags'), color: document.querySelector('input[name="d_color"]:checked')?.value || null,
    };
    if (!b.from_channel) body.source = val('d_src');
    if ($('d_phone')) { body.guest_phone = val('d_phone'); body.guest_email = val('d_email'); }
    if ($('d_notes')) body.notes = val('d_notes');
    if ($('d_acc')) {
      body.price_accommodation = numVal('d_acc'); body.price_cleaning = numVal('d_cln'); body.price_extra = numVal('d_ext'); body.total = numVal('d_tot');
      if ($('d_paid')) body.paid_amount = numVal('d_paid');
    }
    if (b.from_channel) { delete body.check_in; delete body.check_out; }
    return body;
  };
  const reopen = () => openBookingDrawer(b.id);
  if ($('dSave')) {
    $('dSave').onclick = async () => {
      try {
        if (isNew) {
          const r = await api('POST', '/api/bookings', { ...collect(), kind: 'booking', status: b.status });
          toast(b.status === 'inquiry' ? 'Запрос создан' : 'Бронь создана — даты закрываются в каналах');
          clearSel();
          await refreshAll();
          openBookingDrawer(r.id);
        } else {
          await api('PUT', `/api/bookings/${b.id}`, collect());
          toast('Сохранено');
          await refreshAll();
          reopen();
        }
      } catch (e) { setErr(e.message); }
    };
  }
  document.querySelectorAll('.quick [data-q]').forEach((btn) => (btn.onclick = async () => {
    const q = btn.dataset.q;
    try {
      if (q === 'cancel') {
        if (!confirm(b.status === 'inquiry' ? 'Отменить запрос?' : 'Отменить бронь? Даты освободятся во всех каналах.')) return;
        await api('POST', `/api/bookings/${b.id}/cancel`);
        toast('Отменено');
        await refreshAll();
        return closeDrawer();
      }
      if (q === 'confirm') await api('POST', `/api/bookings/${b.id}/confirm`);
      if (q === 'pay') await api('POST', `/api/bookings/${b.id}/payment`, { payment_status: 'paid' });
      if (q === 'unpay') await api('POST', `/api/bookings/${b.id}/payment`, { payment_status: 'unpaid' });
      if (q === 'checkin') await api('POST', `/api/bookings/${b.id}/checkin`, { checked_in: !b.checked_in });
      await refreshAll();
      reopen();
    } catch (e) { setErr(e.message); }
  }));
  bindNotes(b, reopen);
  $('d_name')?.focus();
}

// ----- данные квартиры и текст для гостя -----
function propertyInfoBlock(p, b) {
  if (!p) return '';
  const can = P();
  const lines = [
    p.address && ['Адрес', p.address],
    p.registration_number && ['Лицензия VV', p.registration_number],
    can.notes && p.wifi_name && ['Wi-Fi', `${p.wifi_name}${p.wifi_password ? ' / ' + p.wifi_password : ''}`],
    can.notes && p.door_code && ['Код', p.door_code],
  ].filter(Boolean);
  const staff = can.notes && p.staff_notes ? `<div class="note">${esc(p.staff_notes)}</div>` : '';
  const text = can.contacts && b.kind === 'booking' && b.status !== 'cancelled';
  if (!lines.length && !staff && !text) return '';
  return `<section class="dsec"><h3>Квартира и заселение</h3>
    ${lines.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${esc(v)}</b></div>`).join('')}
    ${staff}
    ${text ? `<div class="row-btns"><button id="gtOpen">Текст для гостя</button></div>
    <div id="gtBox" hidden>
      <div class="row-btns">${['ru', 'en', 'es'].map((l) => `<button type="button" class="gtl" data-l="${l}">${l.toUpperCase()}</button>`).join('')}</div>
      <textarea id="gtText" rows="9"></textarea>
      <div class="row-btns"><button class="primary" id="gtCopy">Скопировать</button>${(b.guest_phone || '').replace(/\D/g, '').length >= 8 ? '<a class="btnlink" id="gtWa" target="_blank" rel="noopener">Открыть WhatsApp</a>' : ''}</div>
    </div>` : ''}
  </section>`;
}

const GT = {
  ru: { hi: 'Здравствуйте', wait: 'Ждём вас', from: 'с', checkout: 'Выезд', by: 'до', addr: 'Адрес', wifi: 'Wi-Fi', pass: 'пароль', code: 'Код двери', rules: 'Правила дома', bye: 'Хорошего отдыха!', loc: 'ru-RU' },
  en: { hi: 'Hello', wait: 'We look forward to welcoming you on', from: 'from', checkout: 'Check-out on', by: 'by', addr: 'Address', wifi: 'Wi-Fi', pass: 'password', code: 'Door code', rules: 'House rules', bye: 'Enjoy your stay!', loc: 'en-GB' },
  es: { hi: 'Hola', wait: 'Le esperamos el', from: 'a partir de las', checkout: 'Salida el', by: 'antes de las', addr: 'Dirección', wifi: 'Wi-Fi', pass: 'contraseña', code: 'Código de la puerta', rules: 'Normas de la casa', bye: '¡Feliz estancia!', loc: 'es-ES' },
};
function guestText(p, b, lang) {
  const t = GT[lang];
  const day = (s) => new Intl.DateTimeFormat(t.loc, { day: 'numeric', month: 'long' }).format(parse(s));
  const first = (b.guest_name || '').trim().split(/\s+/)[0];
  const arrive = lang === 'ru' ? `${t.wait} ${day(b.check_in)}${b.check_in_time ? ` ${t.from} ${b.check_in_time}` : ''}.` : `${t.wait} ${day(b.check_in)}${b.check_in_time ? ` ${t.from} ${b.check_in_time}` : ''}.`;
  const leave = `${t.checkout} ${day(b.check_out)}${b.check_out_time ? ` ${t.by} ${b.check_out_time}` : ''}.`;
  return [
    `${t.hi}${first ? ', ' + first : ''}!`,
    `${arrive} ${leave}`,
    p.address && `${t.addr}: ${p.address}`,
    p.checkin_instructions,
    p.wifi_name && `${t.wifi}: ${p.wifi_name}${p.wifi_password ? `, ${t.pass}: ${p.wifi_password}` : ''}`,
    p.door_code && `${t.code}: ${p.door_code}`,
    p.house_rules && `${t.rules}: ${p.house_rules}`,
    t.bye,
  ].filter(Boolean).join('\n');
}
function bindGuestText(p, b) {
  if (!$('gtOpen')) return;
  const setLang = (l) => {
    $('gtText').value = guestText(p, b, l);
    document.querySelectorAll('.gtl').forEach((x) => x.classList.toggle('on', x.dataset.l === l));
    syncWa();
  };
  const syncWa = () => {
    if ($('gtWa')) $('gtWa').href = `https://wa.me/${(b.guest_phone || '').replace(/\D/g, '')}?text=${encodeURIComponent($('gtText').value)}`;
  };
  $('gtOpen').onclick = () => { $('gtBox').hidden = !$('gtBox').hidden; if (!$('gtText').value) setLang('ru'); };
  document.querySelectorAll('.gtl').forEach((x) => (x.onclick = () => setLang(x.dataset.l)));
  $('gtText').oninput = syncWa;
  $('gtCopy').onclick = async () => {
    try { await navigator.clipboard.writeText($('gtText').value); } catch { $('gtText').select(); document.execCommand('copy'); }
    toast('Текст скопирован');
  };
}

// ----- удержание дат -----
async function openHoldDrawer(id, draft = null) {
  closePop();
  let h;
  if (id) {
    try { h = await api('GET', `/api/bookings/${id}`); } catch (e) { return toast(e.message, true); }
  } else {
    const types = Object.keys(state.holdTypes);
    h = { kind: 'hold', status: 'confirmed', hold_type: types.includes('tentative') ? 'tentative' : types[0], title: '', notes: '', expires_at: Date.now() + 24 * 3600_000, ...draft };
  }
  state.drawer = { type: 'hold', id: h.id || null };
  const isNew = !h.id;
  const can = P();
  const editable = h.status !== 'cancelled' && (can.edit_bookings || (can.block && Object.keys(state.holdTypes).includes(h.hold_type)));
  const dis = editable ? '' : ' disabled';
  const expLocal = h.expires_at ? new Date(h.expires_at - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
  const typeBtns = Object.entries({ ...HOLD_NAMES, ...state.holdTypes })
    .filter(([k]) => state.holdTypes[k] || k === h.hold_type)
    .map(([k, v]) => `<label class="tbtn"><input type="radio" name="h_type" value="${k}"${k === h.hold_type ? ' checked' : ''}${dis}>${HOLD_ICON[k]} ${esc(v)}</label>`).join('');

  openDrawer(`
    <div class="dhead"><h2>${isNew ? 'Удержать даты' : `${HOLD_ICON[h.hold_type] || ''} ${esc(HOLD_NAMES[h.hold_type] || 'Удержание')}`}</h2>
      <div class="muted small">Даты закрываются во всех каналах, как при брони.</div></div>
    <section class="dsec">
      <div class="types">${typeBtns}</div>
      <label>Название</label><input id="h_title" value="${esc(h.title)}" placeholder="Например: замена бойлера / Андрей, ждём предоплату"${dis}>
      <label>Квартира</label><select id="h_p"${dis}>${propOptions(h.property_id)}</select>
      <div class="g2">
        <div><label>С</label><input type="date" id="h_in" value="${h.check_in}"${dis}></div>
        <div><label>До (день выезда)</label><input type="date" id="h_out" value="${h.check_out}"${dis}></div>
      </div>
      <div id="h_expwrap">
        <label>Снять автоматически</label>
        <div class="row-btns">
          ${[[2, '2 ч'], [6, '6 ч'], [24, '24 ч'], [72, '3 дня']].map(([hh, t]) => `<button type="button" data-exp="${hh}"${dis}>${t}</button>`).join('')}
        </div>
        <input type="datetime-local" id="h_exp" value="${expLocal}"${dis}>
      </div>
      ${can.contacts ? `<label>Комментарий</label><textarea id="h_notes" rows="2"${dis}>${esc(h.notes)}</textarea>` : ''}
      ${!isNew ? `<div class="muted small">Поставил(а): ${esc(h.created_by_name || '—')} · ${esc(h.created_at || '')}</div>` : ''}
    </section>
    ${notesBlock(h)}
    <div class="dErr" id="dErr"></div>
    ${editable ? `<div class="dfoot">
      ${!isNew && can.edit_bookings ? '<button id="hConvert">Оформить в бронь</button>' : ''}
      ${!isNew ? '<button class="danger" id="hCancel">Снять удержание</button>' : ''}
      <button class="primary" id="hSave">${isNew ? 'Удержать' : 'Сохранить'}</button></div>` : ''}
  `);
  const syncExp = () => { $('h_expwrap').hidden = document.querySelector('input[name="h_type"]:checked')?.value !== 'tentative'; };
  document.querySelectorAll('input[name="h_type"]').forEach((r) => (r.onchange = syncExp));
  syncExp();
  document.querySelectorAll('[data-exp]').forEach((btn) => (btn.onclick = () => {
    const t = Date.now() + Number(btn.dataset.exp) * 3600_000;
    $('h_exp').value = new Date(t - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }));
  const reopen = () => openHoldDrawer(h.id);
  if ($('hSave')) {
    $('hSave').onclick = async () => {
      const type = document.querySelector('input[name="h_type"]:checked')?.value;
      const body = {
        kind: 'hold', hold_type: type, title: val('h_title'), property_id: Number(val('h_p')), check_in: val('h_in'), check_out: val('h_out'),
        expires_at: type === 'tentative' && val('h_exp') ? new Date(val('h_exp')).getTime() : null,
      };
      if ($('h_notes')) body.notes = val('h_notes');
      try {
        if (isNew) {
          const r = await api('POST', '/api/bookings', body);
          toast('Даты удержаны');
          clearSel();
          await refreshAll();
          openHoldDrawer(r.id);
        } else {
          delete body.kind;
          await api('PUT', `/api/bookings/${h.id}`, body);
          toast('Сохранено');
          await refreshAll();
          reopen();
        }
      } catch (e) { setErr(e.message); }
    };
  }
  if ($('hCancel')) {
    $('hCancel').onclick = async () => {
      if (!confirm('Снять удержание? Даты откроются для продажи.')) return;
      try { await api('POST', `/api/bookings/${h.id}/cancel`); toast('Удержание снято'); await refreshAll(); closeDrawer(); } catch (e) { setErr(e.message); }
    };
  }
  if ($('hConvert')) {
    $('hConvert').onclick = async () => {
      try { const r = await api('POST', `/api/bookings/${h.id}/convert`); toast('Оформлено в бронь — заполните гостя и стоимость'); await refreshAll(); openBookingDrawer(r.id); } catch (e) { setErr(e.message); }
    };
  }
  bindNotes(h, reopen);
}

// ----- цены и ограничения на выбранные даты -----
function openPriceDrawer(init) {
  closePop();
  state.drawer = { type: 'price' };
  const pid = init.property_ids?.[0];
  openDrawer(`
    <div class="dhead"><h2>Цена и ограничения</h2><div class="muted small">Пустое поле — не менять. Изменения уходят в каналы.</div></div>
    <section class="dsec">
      <label>Квартиры</label>
      <div class="plist">${state.data.properties.map((p) => `<label class="chk"><input type="checkbox" class="pp_chk" value="${p.id}"${(init.property_ids || []).includes(p.id) ? ' checked' : ''}> ${esc(p.name)}</label>`).join('')}</div>
      <div class="row-btns"><button type="button" id="ppAll">Все</button><button type="button" id="ppNone">Ни одной</button></div>
      <div class="g2">
        <div><label>С даты</label><input type="date" id="pp_from" value="${init.date_from}"></div>
        <div><label>По дату (последняя ночь)</label><input type="date" id="pp_to" value="${init.date_to}"></div>
      </div>
      <label>Дни недели</label>
      <div class="wdays">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<label class="wd${w === 0 || w === 6 ? ' we' : ''}"><input type="checkbox" class="pp_wd" value="${w}" checked>${WD[w]}</label>`).join('')}</div>
      <div class="row-btns"><button type="button" id="ppWeekend">Только пт–сб</button><button type="button" id="ppWeekdays">Только вс–чт</button><button type="button" id="ppEvery">Все дни</button></div>
      <div class="g2">
        <div><label>Цена</label><select id="pp_mode"><option value="set">новая цена за ночь</option><option value="percent">изменить на %</option><option value="amount">изменить на €</option></select></div>
        <div><label id="pp_vlabel">Цена за ночь</label><input type="number" step="0.01" id="pp_price" placeholder="${pid ? Math.round(state.data.properties.find((p) => p.id === pid)?.base_price || 0) : ''}"></div>
        <div><label>Мин. ночей</label><input type="number" min="1" id="pp_min"></div>
        <div><label>Продажи</label><select id="pp_stop"><option value="">не менять</option><option value="0">открыть</option><option value="1">закрыть</option></select></div>
        <div class="span2"><label>Заезд / выезд</label><select id="pp_cta"><option value="">не менять</option><option value="0">разрешены</option><option value="1">без заезда</option><option value="2">без выезда</option></select></div>
      </div>
      <div class="muted small" id="pp_hint"></div>
    </section>
    <div class="dErr" id="dErr"></div>
    <div class="dfoot"><button class="primary" id="ppSave">Применить</button></div>`);
  $('ppAll').onclick = () => document.querySelectorAll('.pp_chk').forEach((c) => (c.checked = true));
  $('ppNone').onclick = () => document.querySelectorAll('.pp_chk').forEach((c) => (c.checked = false));
  const setWd = (list) => document.querySelectorAll('.pp_wd').forEach((c) => (c.checked = list.includes(Number(c.value))));
  $('ppWeekend').onclick = () => setWd([5, 6]);
  $('ppWeekdays').onclick = () => setWd([0, 1, 2, 3, 4]);
  $('ppEvery').onclick = () => setWd([0, 1, 2, 3, 4, 5, 6]);
  const syncMode = () => {
    const mode = val('pp_mode');
    $('pp_vlabel').textContent = mode === 'set' ? 'Цена за ночь' : mode === 'percent' ? 'На сколько %, например 10 или −15' : 'На сколько €, например 20 или −10';
    $('pp_hint').textContent = mode === 'set' ? '' : 'Меняется текущая цена каждого дня (ручная или базовая).';
  };
  $('pp_mode').onchange = syncMode;
  $('ppSave').onclick = async () => {
    const body = { property_ids: [...document.querySelectorAll('.pp_chk:checked')].map((c) => Number(c.value)), date_from: val('pp_from'), date_to: val('pp_to') };
    const wd = [...document.querySelectorAll('.pp_wd:checked')].map((c) => Number(c.value));
    if (!wd.length) return setErr('Выберите хотя бы один день недели');
    if (wd.length < 7) body.weekdays = wd;
    if (val('pp_price') !== '') {
      if (val('pp_mode') === 'set') body.price = Number(val('pp_price'));
      else body.price_change = { mode: val('pp_mode'), value: Number(val('pp_price')) };
    }
    if (val('pp_min') !== '') body.min_stay = Number(val('pp_min'));
    if (val('pp_stop') !== '') body.stop_sell = val('pp_stop') === '1';
    if (val('pp_cta') !== '') { body.cta = val('pp_cta') === '1'; body.ctd = val('pp_cta') === '2'; }
    if (!['price', 'price_change', 'min_stay', 'stop_sell', 'cta'].some((k) => k in body)) return setErr('Укажите, что поменять');
    if (!body.property_ids.length) return setErr('Выберите квартиры');
    try {
      const r = await api('PUT', '/api/daily', body);
      toast(`Применено: ${r.days} дн. × ${body.property_ids.length} кв. — уходит в каналы`);
      closeDrawer();
      await refreshAll();
    } catch (e) { setErr(e.message); }
  };
}

// ---------- свободно на даты ----------
$('freeBtn').onclick = (e) => {
  const pop = $('pop');
  const f = state.free;
  const from = f?.from || todayStr();
  pop.innerHTML = `<div class="ph"><b>Какие квартиры свободны?</b></div>
    <div class="g2"><div><label>Заезд</label><input type="date" id="fr_in" value="${from}"></div>
    <div><label>Выезд</label><input type="date" id="fr_out" value="${f?.to || addDays(from, 7)}"></div>
    <div><label>Гостей</label><input type="number" id="fr_g" min="1" value="${f?.guests || ''}" placeholder="—"></div></div>
    <div class="pb"><button class="primary" id="frGo">Найти</button>${f ? '<button id="frClear">Сбросить</button>' : ''}</div>`;
  pop.hidden = false;
  const r = e.target.getBoundingClientRect();
  pop.style.left = `${Math.max(8, Math.min(r.left, innerWidth - 300))}px`;
  pop.style.top = `${r.bottom + 6}px`;
  $('frGo').onclick = async () => {
    try {
      const ci = val('fr_in');
      const co = val('fr_out');
      const rows = await api('POST', '/api/quote', { check_in: ci, check_out: co });
      const guests = numVal('fr_g');
      const map = new Map(rows.map((q) => [q.property_id, q]));
      if (guests) for (const p of state.data.properties) if (p.max_guests && p.max_guests < guests && map.get(p.id)) map.get(p.id).free = false;
      state.free = { from: ci, to: co, guests, map, hideBusy: state.free?.hideBusy || false };
      closePop();
      state.from = addDays(ci, -2);
      $('jump').value = state.from;
      if (diffDays(state.from, co) > state.days) { state.days = diffDays(state.from, co) + 3 > 30 ? 60 : 30; $('span').value = String(state.days); }
      await load();
      renderFreebar();
    } catch (err) { toast(err.message, true); }
  };
  if ($('frClear')) $('frClear').onclick = () => { state.free = null; closePop(); renderFreebar(); render(); };
};
function renderFreebar() {
  const f = state.free;
  const bar = $('freebar');
  if (!f) { bar.hidden = true; return; }
  const total = state.data.properties.length;
  const freeN = state.data.properties.filter((p) => f.map.get(p.id)?.free).length;
  const n = diffDays(f.from, f.to);
  bar.innerHTML = `<b>Свободно ${freeN} из ${total}</b> · ${short(f.from)} → ${short(f.to)} · ${n} ${nightsWord(n)}${f.guests ? ` · гостей: ${f.guests}` : ''}
    <label class="chk"><input type="checkbox" id="frHide"${f.hideBusy ? ' checked' : ''}> скрыть занятые</label>
    <span class="muted">Нажмите на цену у квартиры — откроется бронь.</span>
    <button id="frX" aria-label="Сбросить">×</button>`;
  bar.hidden = false;
  $('frHide').onchange = () => { f.hideBusy = $('frHide').checked; render(); };
  $('frX').onclick = () => { state.free = null; renderFreebar(); render(); };
}

// ---------- быстрый поиск ----------
let qTimer;
$('q').addEventListener('input', () => {
  clearTimeout(qTimer);
  qTimer = setTimeout(async () => {
    const q = $('q').value.trim();
    if (q.length < 2) { $('qres').hidden = true; return; }
    try {
      const rows = await api('GET', `/api/search?q=${encodeURIComponent(q)}`);
      $('qres').innerHTML = rows.length
        ? rows.map((b) => `<button data-sid="${b.id}" data-kind="${b.kind}" data-ci="${b.check_in}">${srcBadge(b)} <b>${esc(barLabel(b))}</b> · ${esc(b.property_name)}<br><span class="muted">${short(b.check_in)} → ${short(b.check_out)}${b.status === 'cancelled' ? ' · отменена' : b.status === 'inquiry' ? ' · запрос' : ''}</span></button>`).join('')
        : '<div class="muted pad">Ничего не найдено</div>';
      $('qres').hidden = false;
    } catch (e) { toast(e.message, true); }
  }, 250);
});
$('qres').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-sid]');
  if (!btn) return;
  $('qres').hidden = true;
  state.from = addDays(btn.dataset.ci, -3);
  $('jump').value = state.from;
  if (state.view !== 'cal') setView('cal');
  await load();
  if (btn.dataset.kind === 'hold') openHoldDrawer(Number(btn.dataset.sid));
  else openBookingDrawer(Number(btn.dataset.sid));
  document.querySelector(`.bar[data-b="${btn.dataset.sid}"]`)?.scrollIntoView({ block: 'center', inline: 'center' });
});

// ---------- заезды и выезды ----------
const agenda = { from: null, to: null };
async function loadAgenda() {
  if (!agenda.from) { agenda.from = todayStr(); agenda.to = addDays(agenda.from, 6); }
  const events = await api('GET', `/api/agenda?from=${agenda.from}&to=${agenda.to}`);
  const props = new Map(state.data.properties.map((p) => [p.id, p]));
  const can = P();
  const byDay = new Map();
  for (const e of events) { if (!byDay.has(e.date)) byDay.set(e.date, []); byDay.get(e.date).push(e); }
  const preset = (n, label) => `<button data-ap="${n}"${diffDays(agenda.from, agenda.to) === n && agenda.from === todayStr() ? ' class="on"' : ''}>${label}</button>`;
  let html = `<div class="atools">
    ${preset(0, 'Сегодня')}<button data-ap="tomorrow">Завтра</button>${preset(6, 'Неделя')}${preset(13, '2 недели')}
    <input type="date" id="ag_from" value="${agenda.from}"> — <input type="date" id="ag_to" value="${agenda.to}">
    <span class="grow"></span><button id="agPrint">Печать</button><button id="agCsv">Скачать CSV</button></div>`;
  if (!events.length) html += '<div class="empty">В этот период нет заездов и выездов.</div>';
  for (const [day, list] of byDay) {
    const arr = list.filter((e) => e.type === 'arrival').length;
    const dep = list.filter((e) => e.type === 'departure').length;
    html += `<section class="aday"><h3>${longDay(day)} <span class="muted">· заездов ${arr} · выездов ${dep}</span></h3><table><tbody>`;
    for (const e of list) {
      const b = e.booking;
      const p = props.get(b.property_id);
      const label = e.type === 'arrival' ? '<span class="ev in">Заезд</span>' : e.type === 'departure' ? '<span class="ev out">Выезд</span>' : '<span class="ev hold">Удержание</span>';
      const guests = b.adults != null ? `${b.adults}${b.children ? ' + ' + b.children + ' реб.' : ''}` : '';
      const ready = e.type === 'arrival' && p ? (can.notes || can.properties ? `<button class="rdy ${p.ready === 0 ? 'no' : 'yes'}" data-ready="${p.id}" data-v="${p.ready === 0 ? 1 : 0}">${p.ready === 0 ? '🧹 Не готова' : '✓ Готова'}</button>` : p.ready === 0 ? '🧹' : '') : '';
      html += `<tr data-open="${b.id}" data-kind="${b.kind}">
        <td class="t">${esc(e.time || '')}</td><td>${label}${e.turnover ? ' <span class="badge warn" title="Выезд и заезд в один день">смена</span>' : ''}</td>
        <td><b>${esc(b.property_name)}</b></td><td>${srcBadge(b)} ${esc(barLabel(b))}</td><td>${esc(guests)}</td>
        <td>${b.notes_count ? `💬 ${b.notes_count}` : ''}${b.checked_in ? ' ✓ заселён' : ''}</td><td>${ready}</td></tr>`;
    }
    html += '</tbody></table></section>';
  }
  $('agenda').innerHTML = html;
  $('agenda').querySelectorAll('[data-ap]').forEach((btn) => (btn.onclick = () => {
    const v = btn.dataset.ap;
    agenda.from = v === 'tomorrow' ? addDays(todayStr(), 1) : todayStr();
    agenda.to = v === 'tomorrow' ? agenda.from : addDays(agenda.from, Number(v));
    loadAgenda();
  }));
  $('ag_from').onchange = () => { agenda.from = val('ag_from'); if (agenda.to < agenda.from) agenda.to = agenda.from; loadAgenda(); };
  $('ag_to').onchange = () => { agenda.to = val('ag_to'); if (agenda.to < agenda.from) agenda.from = agenda.to; loadAgenda(); };
  $('agPrint').onclick = () => print();
  $('agCsv').onclick = () => {
    const rows = [['Дата', 'Время', 'Событие', 'Квартира', 'Гость', 'Взрослые', 'Дети']];
    for (const e of events) rows.push([e.date, e.time || '', { arrival: 'Заезд', departure: 'Выезд', hold: 'Удержание' }[e.type], e.booking.property_name, barLabel(e.booking), e.booking.adults ?? '', e.booking.children ?? '']);
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
    a.download = `zaezdy-${agenda.from}_${agenda.to}.csv`;
    a.click();
  };
}
$('agenda').addEventListener('click', async (e) => {
  const rb = e.target.closest('[data-ready]');
  if (rb) {
    e.stopPropagation();
    try { await api('POST', `/api/properties/${rb.dataset.ready}/ready`, { ready: rb.dataset.v === '1' }); await load(); loadAgenda(); } catch (err) { toast(err.message, true); }
    return;
  }
  const tr = e.target.closest('[data-open]');
  if (!tr) return;
  if (tr.dataset.kind === 'hold') openHoldDrawer(Number(tr.dataset.open));
  else openBookingDrawer(Number(tr.dataset.open));
});

// ---------- список броней ----------
const monthStart = (s) => `${s.slice(0, 7)}-01`;
const monthEnd = (s) => addDays(addMonths(monthStart(s), 1), -1);
const addMonths = (s, n) => { const d = parse(monthStart(s)); d.setMonth(d.getMonth() + n); return fmt(d); };
const list = { from: null, to: null, property_id: '', status: '', source: '', payment: '', q: '' };
const STATUS_RU = { confirmed: 'Бронь', inquiry: 'Запрос', cancelled: 'Отменена' };
const PAY_RU = { paid: 'оплачено', partial: 'частично', unpaid: 'не оплачено' };

async function loadList() {
  if (!list.from) { list.from = monthStart(todayStr()); list.to = monthEnd(todayStr()); }
  const qs = new URLSearchParams(Object.entries(list).filter(([, v]) => v !== '' && v != null));
  const rows = await api('GET', `/api/bookings?${qs}`);
  const can = P();
  const props = state.data.properties;
  const cur = props[0]?.currency || 'EUR';
  const sources = [...new Set([...state.sources, 'Booking.com', 'Airbnb', ...rows.map((r) => r.source)])].filter(Boolean);
  const sel = (id, opts, v) => `<select id="${id}">${opts.map(([k, t]) => `<option value="${esc(k)}"${String(v) === String(k) ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
  const live = rows.filter((r) => r.status === 'confirmed');
  const sum = (k) => live.reduce((t, r) => t + (r[k] || 0), 0);
  let html = `<div class="atools">
    <button data-lp="this">Этот месяц</button><button data-lp="prev">Прошлый</button><button data-lp="next">Следующий</button><button data-lp="30">Ближайшие 30 дней</button>
    <span class="muted small">заезд с</span><input type="date" id="l_from" value="${list.from}"><span class="muted small">по</span><input type="date" id="l_to" value="${list.to}">
  </div>
  <div class="atools">
    ${sel('l_prop', [['', 'Все квартиры'], ...props.map((p) => [p.id, p.name])], list.property_id)}
    ${sel('l_status', [['', 'Брони и запросы'], ['confirmed', 'Только брони'], ['inquiry', 'Только запросы'], ['cancelled', 'Отменённые']], list.status)}
    ${sel('l_src', [['', 'Все источники'], ...sources.map((s) => [s, s])], list.source)}
    ${can.money ? sel('l_pay', [['', 'Любая оплата'], ['unpaid', 'Не оплачено'], ['partial', 'Частично'], ['paid', 'Оплачено']], list.payment) : ''}
    <input id="l_q" type="search" placeholder="Гость, телефон, № брони" value="${esc(list.q)}" style="max-width:220px">
    <span class="grow"></span><button id="lCsv">Скачать CSV</button>
  </div>
  <div class="ltotal"><b>${live.length}</b> броней · <b>${live.reduce((t, r) => t + r.nights, 0)}</b> ночей${can.money ? ` · сумма <b>${money(sum('total'), cur)}</b> · чистыми <b>${money(sum('net'), cur)}</b> · оплачено <b>${money(sum('paid_amount'), cur)}</b>` : ''}${rows.length - live.length ? ` · запросов и отмен: ${rows.length - live.length}` : ''}</div>`;
  if (!rows.length) html += '<div class="empty">Ничего не найдено. Измените период или фильтры.</div>';
  else {
    html += `<div class="tablewrap"><table class="ltable"><thead><tr><th>Заезд</th><th>Выезд</th><th>Ноч.</th><th>Квартира</th><th>Гость</th><th>Гостей</th><th>Источник</th><th>Статус</th>${can.money ? '<th>Оплата</th><th class="num">Сумма</th><th class="num">Чистыми</th><th class="num">Оплачено</th>' : ''}</tr></thead><tbody>`;
    for (const r of rows) {
      html += `<tr data-open="${r.id}" class="${r.status}">
        <td>${short(r.check_in)}</td><td>${short(r.check_out)}</td><td>${r.nights}</td><td>${esc(r.property_name)}</td>
        <td>${srcBadge(r)} ${esc(r.guest_name || '—')}</td><td>${r.adults != null ? `${r.adults}${r.children ? '+' + r.children : ''}` : ''}</td>
        <td>${esc(r.source)}</td><td><span class="st ${r.status}">${STATUS_RU[r.status] || r.status}</span></td>
        ${can.money ? `<td>${r.status === 'confirmed' ? `<span class="pay ${r.payment_status}">${PAY_RU[r.payment_status] || ''}</span>` : ''}</td>
        <td class="num">${money(r.total, r.currency)}</td><td class="num">${money(r.net, r.currency)}</td><td class="num">${money(r.paid_amount, r.currency)}</td>` : ''}</tr>`;
    }
    html += '</tbody></table></div>';
  }
  $('list').innerHTML = html;
  const reload = () => loadList().catch((e) => toast(e.message, true));
  $('list').querySelectorAll('[data-lp]').forEach((b) => (b.onclick = () => {
    const t = todayStr();
    const v = b.dataset.lp;
    if (v === '30') { list.from = t; list.to = addDays(t, 30); }
    else { const base = v === 'prev' ? addMonths(t, -1) : v === 'next' ? addMonths(t, 1) : t; list.from = monthStart(base); list.to = monthEnd(base); }
    reload();
  }));
  $('l_from').onchange = () => { list.from = val('l_from'); reload(); };
  $('l_to').onchange = () => { list.to = val('l_to'); reload(); };
  $('l_prop').onchange = () => { list.property_id = val('l_prop'); reload(); };
  $('l_status').onchange = () => { list.status = val('l_status'); reload(); };
  $('l_src').onchange = () => { list.source = val('l_src'); reload(); };
  if ($('l_pay')) $('l_pay').onchange = () => { list.payment = val('l_pay'); reload(); };
  let t;
  $('l_q').oninput = () => { clearTimeout(t); t = setTimeout(() => { list.q = val('l_q'); reload().then(() => { const q = $('l_q'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }); }, 350); };
  $('lCsv').onclick = () => downloadCsv(`broni-${list.from}_${list.to}.csv`, [
    ['Заезд', 'Выезд', 'Ночей', 'Квартира', 'Гость', 'Взрослые', 'Дети', 'Источник', 'Статус', ...(can.money ? ['Оплата', 'Сумма', 'Чистыми', 'Оплачено'] : [])],
    ...rows.map((r) => [r.check_in, r.check_out, r.nights, r.property_name, r.guest_name, r.adults ?? '', r.children ?? '', r.source, STATUS_RU[r.status] || r.status,
      ...(can.money ? [PAY_RU[r.payment_status] || '', r.total ?? '', r.net ?? '', r.paid_amount ?? ''] : [])]),
  ]);
}
$('list').addEventListener('click', (e) => {
  const tr = e.target.closest('[data-open]');
  if (tr) openBookingDrawer(Number(tr.dataset.open));
});
function downloadCsv(name, rows) {
  const csv = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
  a.download = name;
  a.click();
}

// ---------- доход за месяц ----------
const report = { month: null, details: false };
async function loadReport() {
  if (!report.month) report.month = todayStr().slice(0, 7);
  const r = await api('GET', `/api/report?month=${report.month}`);
  const cur = state.data.properties[0]?.currency || 'EUR';
  const [y, m] = report.month.split('-').map(Number);
  const title = `${['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'][m - 1]} ${y}`;
  let html = `<div class="atools"><button id="rPrev" aria-label="Предыдущий месяц">‹</button><b class="rtitle">${title}</b><button id="rNext" aria-label="Следующий месяц">›</button>
    <input type="month" id="r_month" value="${report.month}"><span class="grow"></span>
    <label class="chk"><input type="checkbox" id="rDet"${report.details ? ' checked' : ''}> показать брони</label><button id="rCsv">Скачать CSV</button></div>
    <div class="kpis">
      <div><span>Загрузка</span><b>${r.totals.occupancy} %</b></div>
      <div><span>Ночей продано</span><b>${r.totals.nights}</b></div>
      <div><span>Доход</span><b>${money(r.totals.gross, cur)}</b></div>
      <div><span>Чистыми</span><b>${money(r.totals.net, cur)}</b></div>
    </div>
    <div class="tablewrap"><table class="ltable"><thead><tr><th>Квартира</th><th class="num">Ночей</th><th class="num">Загрузка</th><th class="num">Броней</th><th class="num">Средняя цена</th><th class="num">Доход</th><th class="num">Чистыми</th><th class="num">Удержано ноч.</th></tr></thead><tbody>`;
  for (const row of r.rows) {
    html += `<tr><td><b>${esc(row.name)}</b>${row.no_amount ? ` <span class="badge warn" title="У части броней не указана сумма">без суммы: ${row.no_amount}</span>` : ''}</td>
      <td class="num">${row.nights}</td><td class="num"><span class="occ" style="--o:${Math.min(100, row.occupancy)}%">${row.occupancy} %</span></td><td class="num">${row.bookings}</td>
      <td class="num">${money(row.adr, row.currency)}</td><td class="num">${money(row.gross, row.currency)}</td><td class="num">${money(row.net, row.currency)}</td><td class="num">${row.hold_nights || ''}</td></tr>`;
  }
  html += `</tbody><tfoot><tr><td>Итого</td><td class="num">${r.totals.nights}</td><td class="num">${r.totals.occupancy} %</td><td class="num">${r.totals.bookings}</td><td></td>
    <td class="num">${money(r.totals.gross, cur)}</td><td class="num">${money(r.totals.net, cur)}</td><td class="num">${r.totals.hold_nights || ''}</td></tr></tfoot></table></div>
    <div class="muted small" style="margin:8px 2px">Доход распределён по ночам этого месяца. «Чистыми» — после комиссий каналов (меню ☰ → «Комиссии каналов»).</div>`;
  if (report.details) {
    html += `<div class="tablewrap"><table class="ltable"><thead><tr><th>Квартира</th><th>Гость</th><th>Источник</th><th>Заезд</th><th>Выезд</th><th class="num">Ночей в месяце</th><th class="num">Сумма брони</th><th class="num">Доход месяца</th><th class="num">Чистыми</th></tr></thead><tbody>
      ${r.items.map((i) => `<tr data-open="${i.id}"><td>${esc(i.property_name)}</td><td>${esc(i.guest_name || '—')}</td><td>${esc(i.source)}</td><td>${short(i.check_in)}</td><td>${short(i.check_out)}</td>
        <td class="num">${i.nights_in_month} из ${i.nights}</td><td class="num">${money(i.total, cur)}</td><td class="num">${money(i.gross_month, cur)}</td><td class="num">${money(i.net_month, cur)}</td></tr>`).join('')}
      </tbody></table></div>`;
  }
  $('report').innerHTML = html;
  const go = (mm) => { report.month = mm; loadReport().catch((e) => toast(e.message, true)); };
  $('rPrev').onclick = () => go(addMonths(`${report.month}-01`, -1).slice(0, 7));
  $('rNext').onclick = () => go(addMonths(`${report.month}-01`, 1).slice(0, 7));
  $('r_month').onchange = () => { if (val('r_month')) go(val('r_month')); };
  $('rDet').onchange = () => { report.details = $('rDet').checked; loadReport(); };
  $('rCsv').onclick = () => downloadCsv(`dohod-${report.month}.csv`, [
    ['Квартира', 'Гость', 'Источник', 'Заезд', 'Выезд', 'Ночей в месяце', 'Ночей всего', 'Сумма брони', 'Доход месяца', 'Чистыми'],
    ...r.items.map((i) => [i.property_name, i.guest_name, i.source, i.check_in, i.check_out, i.nights_in_month, i.nights, i.total ?? '', i.gross_month, i.net_month]),
  ]);
}
$('report').addEventListener('click', (e) => {
  const tr = e.target.closest('[data-open]');
  if (tr) openBookingDrawer(Number(tr.dataset.open));
});

const VIEWS = { cal: 'viewCal', agenda: 'viewAgenda', list: 'viewList', report: 'viewReport' };
function setView(v) {
  state.view = v;
  for (const [k, btn] of Object.entries(VIEWS)) {
    $(btn).classList.toggle('on', k === v);
    $(k).hidden = k !== v;
  }
  document.querySelectorAll('.nav').forEach((n) => n.classList.toggle('off', v !== 'cal'));
  const loaders = { agenda: loadAgenda, list: loadList, report: loadReport };
  if (loaders[v]) loaders[v]().catch((e) => toast(e.message, true));
}
$('viewCal').onclick = () => setView('cal');
$('viewAgenda').onclick = () => setView('agenda');
$('viewList').onclick = () => setView('list');
$('viewReport').onclick = () => setView('report');

// ---------- модальные окна (настройки) ----------
function openModal(html) { $('box').innerHTML = html; $('modal').classList.remove('hidden'); }
function closeModal() { $('modal').classList.add('hidden'); $('box').innerHTML = ''; }
$('modal').addEventListener('mousedown', (e) => { if (e.target === $('modal')) closeModal(); });

const MENU = [
  ['prices', 'Цены и ограничения', () => openPriceDrawer({ property_ids: [], date_from: todayStr(), date_to: addDays(todayStr(), 29) })],
  ['properties', 'Квартиры', () => openProps()],
  ['properties', 'Источники броней', () => openSources()],
  ['properties', 'Комиссии каналов', () => openCommissions()],
  ['channex', 'Channex', () => openChannex()],
  ['users', 'Пользователи', () => openUsers()],
  ['audit', 'Журнал действий', () => openAudit()],
  [null, 'Мой пароль и выход', () => openMe()],
];
$('menuBtn').onclick = () => {
  const m = $('menu');
  m.innerHTML = MENU.filter(([perm]) => !perm || P()[perm]).map(([, label], i) => `<button data-mi="${MENU.findIndex((x) => x[1] === label)}">${label}</button>`).join('')
    + `<div class="muted small pad">${esc(state.me.name)} · ${esc(state.me.role_label)}</div>`;
  m.hidden = !m.hidden;
};
$('menu').addEventListener('click', (e) => {
  const i = e.target.closest('[data-mi]')?.dataset.mi;
  if (i == null) return;
  $('menu').hidden = true;
  MENU[Number(i)][2]();
});

function openProps() {
  const props = state.data.properties;
  openModal(`<h2>Квартиры</h2>
    <div class="plist" id="plist">${props.map((p) => `<div class="prow" data-id="${p.id}"><span>${p.color ? `<i class="dot" style="background:${esc(p.color)}"></i>` : ''}${esc(p.name)} <span class="muted small">· ${money(p.base_price, p.currency)} · уборка ${money(p.cleaning_fee || 0, p.currency)}${p.channex_property_id ? ' · Channex ✓' : ''}</span></span><button class="p_edit">Изменить</button></div>`).join('') || '<div class="muted">Пока пусто</div>'}</div>
    <h3>Добавить квартиру</h3>
    <div class="g2"><div><label>Название</label><input id="n_name" placeholder="0.1 Olympia Studio"></div><div><label>Цена за ночь</label><input id="n_price" type="number" value="100"></div>
    <div><label>Уборка</label><input id="n_clean" type="number" value="0"></div></div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button><button class="primary" id="n_add">Добавить</button></div>`);
  $('x_close').onclick = closeModal;
  $('n_add').onclick = async () => {
    try { await api('POST', '/api/properties', { name: val('n_name'), base_price: Number(val('n_price')), cleaning_fee: Number(val('n_clean')) || 0 }); await refreshAll(); openProps(); toast('Квартира добавлена'); } catch (e) { setErr(e.message); }
  };
  document.querySelectorAll('.p_edit').forEach((btn) => (btn.onclick = () => openPropForm(props.find((p) => p.id === Number(btn.closest('.prow').dataset.id)))));
}
function openPropForm(p) {
  openModal(`<h2>${esc(p.name)}</h2>
    <div class="g2">
      <div class="span2"><label>Название</label><input id="pf_name" value="${esc(p.name)}"></div>
      <div><label>Базовая цена за ночь</label><input id="pf_price" type="number" step="0.01" value="${p.base_price ?? ''}"></div>
      <div><label>Уборка за проживание</label><input id="pf_clean" type="number" step="0.01" value="${p.cleaning_fee ?? 0}"></div>
      <div><label>Время заезда</label><input id="pf_in" type="time" value="${esc(p.check_in_time || '16:00')}"></div>
      <div><label>Время выезда</label><input id="pf_out" type="time" value="${esc(p.check_out_time || '11:00')}"></div>
      <div><label>Макс. гостей</label><input id="pf_max" type="number" min="1" value="${p.max_guests ?? ''}"></div>
      <div><label>Теги</label><input id="pf_tags" value="${esc(p.tags || '')}" placeholder="Адехе, студия"></div>
    </div>
    <label>Цвет</label>${colorPicker(p.color, '')}
    <h3>Адрес и заселение</h3>
    <div class="g2">
      <div class="span2"><label>Адрес</label><input id="pf_addr" value="${esc(p.address || '')}" placeholder="Avenida de España, 5, Costa Adeje"></div>
      <div><label>Лицензия VV</label><input id="pf_reg" value="${esc(p.registration_number || '')}" placeholder="VV-38-4-00…"></div>
      <div><label>Код двери / сейфа</label><input id="pf_code" value="${esc(p.door_code || '')}"></div>
      <div><label>Wi-Fi сеть</label><input id="pf_wn" value="${esc(p.wifi_name || '')}"></div>
      <div><label>Wi-Fi пароль</label><input id="pf_wp" value="${esc(p.wifi_password || '')}"></div>
    </div>
    <label>Как заселиться (для гостя)</label><textarea id="pf_ci" rows="3" placeholder="Где ключ, как пройти, парковка">${esc(p.checkin_instructions || '')}</textarea>
    <label>Правила дома</label><textarea id="pf_rules" rows="2">${esc(p.house_rules || '')}</textarea>
    <label>Служебные заметки (видит только персонал)</label><textarea id="pf_staff" rows="2">${esc(p.staff_notes || '')}</textarea>
    <label class="chk"><input type="checkbox" id="pf_active"${p.active !== 0 ? ' checked' : ''}> Показывать на шахматке</label>
    ${P().channex && !p.channex_property_id ? '<div class="btns" style="justify-content:flex-start"><button id="pf_cx">Создать в Channex</button></div>' : ''}
    <div class="err" id="err"></div>
    <div class="btns"><button id="pf_back">Назад</button><button class="primary" id="pf_save">Сохранить</button></div>`);
  $('pf_back').onclick = openProps;
  $('pf_save').onclick = async () => {
    try {
      await api('PUT', `/api/properties/${p.id}`, {
        name: val('pf_name'), base_price: Number(val('pf_price')), cleaning_fee: Number(val('pf_clean')) || 0, check_in_time: val('pf_in'), check_out_time: val('pf_out'),
        max_guests: numVal('pf_max'), tags: val('pf_tags'), color: document.querySelector('input[name="d_color"]:checked')?.value || null, active: $('pf_active').checked,
        address: val('pf_addr'), registration_number: val('pf_reg'), door_code: val('pf_code'), wifi_name: val('pf_wn'), wifi_password: val('pf_wp'),
        checkin_instructions: val('pf_ci'), house_rules: val('pf_rules'), staff_notes: val('pf_staff'),
      });
      await refreshAll(); openProps(); toast('Сохранено');
    } catch (e) { setErr(e.message); }
  };
  if ($('pf_cx')) $('pf_cx').onclick = async () => {
    try { await api('POST', `/api/channex/setup/${p.id}`); await refreshAll(); openProps(); toast('Создано в Channex, цены и доступность отправлены'); } catch (e) { setErr(e.message); }
  };
}
async function openSources() {
  openModal(`<h2>Источники броней</h2><div class="muted small">По одному в строке. Брони из Booking.com и Airbnb получают источник автоматически.</div>
    <textarea id="src_list" rows="10">${esc(state.sources.join('\n'))}</textarea><div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button><button class="primary" id="src_save">Сохранить</button></div>`);
  $('x_close').onclick = closeModal;
  $('src_save').onclick = async () => {
    try { state.sources = await api('PUT', '/api/sources', { sources: val('src_list').split('\n') }); closeModal(); toast('Сохранено'); } catch (e) { setErr(e.message); }
  };
}
async function openCommissions(editId = null) {
  const rules = await api('GET', '/api/commission-rules');
  const props = state.data.properties;
  const pname = (id) => (id ? props.find((p) => p.id === id)?.name || `#${id}` : 'Все квартиры');
  const channels = [...new Set(['Booking.com', 'Airbnb', 'Expedia', ...state.sources])];
  const e = rules.find((r) => r.id === editId) || { channel: 'Booking.com', property_id: null, percent: 15, add_fixed: 0, sub_fixed: 0, note: '' };
  openModal(`<h2>Комиссии каналов</h2>
    <div class="muted small">Чистыми = (сумма брони + прибавка) × (1 − комиссия %) − вычет. Правило для квартиры важнее общего. Пример из AdvanceCM: Booking.com, 17,4 %, прибавка 50 (уборка).</div>
    <div class="plist">${rules.map((r) => `<div class="prow"><span><b>${esc(r.channel === '*' ? 'Любой канал' : r.channel)}</b> · ${esc(pname(r.property_id))}<br>
      <span class="muted small">${r.percent} %${r.add_fixed ? ` · +${r.add_fixed}` : ''}${r.sub_fixed ? ` · −${r.sub_fixed}` : ''}${r.note ? ' · ' + esc(r.note) : ''}</span></span>
      <span><button data-ce="${r.id}">Изменить</button> <button class="danger" data-cd="${r.id}" aria-label="Удалить">×</button></span></div>`).join('') || '<div class="muted">Правил пока нет — чистый доход равен сумме брони.</div>'}</div>
    <h3>${editId ? 'Изменить правило' : 'Новое правило'}</h3>
    <div class="g2">
      <div><label>Канал</label><select id="cm_ch"><option value="*"${e.channel === '*' ? ' selected' : ''}>Любой канал</option>${channels.map((c) => `<option${c === e.channel ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
      <div><label>Квартира</label><select id="cm_p"><option value="">Все квартиры</option>${props.map((p) => `<option value="${p.id}"${p.id === e.property_id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>
      <div><label>Комиссия, %</label><input id="cm_pct" type="number" step="0.01" value="${e.percent}"></div>
      <div><label>Прибавить до комиссии</label><input id="cm_add" type="number" step="0.01" value="${e.add_fixed}"></div>
      <div><label>Вычесть после комиссии</label><input id="cm_sub" type="number" step="0.01" value="${e.sub_fixed}"></div>
      <div><label>Заметка</label><input id="cm_note" value="${esc(e.note)}"></div>
    </div>
    <div class="err" id="err"></div>
    <div class="btns"><button id="x_close">Закрыть</button>${editId ? '<button id="cm_new">Новое правило</button>' : ''}<button class="primary" id="cm_save">${editId ? 'Сохранить' : 'Добавить'}</button></div>`);
  $('x_close').onclick = closeModal;
  if ($('cm_new')) $('cm_new').onclick = () => openCommissions();
  document.querySelectorAll('[data-ce]').forEach((b) => (b.onclick = () => openCommissions(Number(b.dataset.ce))));
  document.querySelectorAll('[data-cd]').forEach((b) => (b.onclick = async () => {
    if (!confirm('Удалить правило?')) return;
    try { await api('DELETE', `/api/commission-rules/${b.dataset.cd}`); openCommissions(); } catch (err) { setErr(err.message); }
  }));
  $('cm_save').onclick = async () => {
    try {
      await api('POST', '/api/commission-rules', { id: editId || undefined, channel: val('cm_ch'), property_id: val('cm_p') || null, percent: Number(val('cm_pct')), add_fixed: Number(val('cm_add')) || 0, sub_fixed: Number(val('cm_sub')) || 0, note: val('cm_note') });
      toast('Сохранено');
      openCommissions();
    } catch (err) { setErr(err.message); }
  };
}

async function openChannex() {
  const st = await api('GET', '/api/sync/status');
  openModal(`<h2>Channex</h2>
    <div class="muted small">Адрес: ${esc(st.base_url)} · ключ: ${esc(st.api_key) || 'не задан'} · связано квартир: ${st.linked} из ${st.total} · в очереди: ${st.pending} · ошибок: ${st.failed}</div>
    <label>API-ключ</label><input id="c_key" placeholder="вставьте ключ, чтобы заменить" autocomplete="off">
    <label>Адрес API (staging — для тестов, app.channex.io/api/v1 — боевой)</label><input id="c_url" value="${esc(st.base_url)}">
    <div class="btns" style="justify-content:flex-start"><button id="c_save">Сохранить</button><button id="c_poll">Забрать брони сейчас</button></div>
    <div class="log">${st.log.map((l) => `<div class="${l.ok ? '' : 'bad'}">${esc(l.ts)} · ${esc(l.kind)} · ${esc(l.message)}</div>`).join('')}</div>
    <div class="err" id="err"></div><div class="btns"><button id="x_close">Закрыть</button></div>`);
  $('x_close').onclick = closeModal;
  $('c_save').onclick = async () => { try { await api('POST', '/api/channex/settings', { api_key: val('c_key'), base_url: val('c_url') }); toast('Сохранено'); refreshStatus(); } catch (e) { setErr(e.message); } };
  $('c_poll').onclick = async () => { try { await api('POST', '/api/channex/poll'); await refreshAll(); toast('Готово'); } catch (e) { setErr(e.message); } };
}

const ROLE_HINT = {
  chief: 'всё, включая пользователей и Channex', admin: 'брони, цены, квартиры, журнал', manager: 'брони и цены',
  housekeeper: 'шахматка и заезды без денег и контактов, заметки, «готова»', technician: 'удержания на ремонт, заметки', owner: 'только свои квартиры, без контактов гостей',
};
async function openUsers() {
  const users = await api('GET', '/api/users');
  openModal(`<h2>Пользователи</h2>
    <div class="plist">${users.map((u) => `<div class="prow urow" data-id="${u.id}"><span>${esc(u.name)} <span class="badge">${esc(u.login)}</span> ${u.active ? '' : '<span class="badge bad">отключён</span>'}<br><span class="muted small">${esc(state.roles[u.role])}${u.role === 'owner' ? ' · квартир: ' + u.property_ids.length : ''}</span></span><button class="u_edit">Изменить</button></div>`).join('')}</div>
    <div class="btns"><button id="u_close">Закрыть</button><button class="primary" id="u_new">Добавить пользователя</button></div><div class="err" id="err"></div>`);
  $('u_close').onclick = closeModal;
  $('u_new').onclick = () => userForm(null);
  document.querySelectorAll('.u_edit').forEach((b) => (b.onclick = () => userForm(users.find((u) => u.id === Number(b.closest('.urow').dataset.id)))));
}
function userForm(u) {
  openModal(`<h2>${u ? 'Пользователь' : 'Новый пользователь'}</h2>
    <div class="g2"><div><label>Имя</label><input id="u_name" value="${esc(u?.name)}"></div>
    <div><label>Логин</label><input id="u_login" value="${esc(u?.login)}"${u ? ' disabled' : ''} autocapitalize="none"></div></div>
    <label>Роль</label><select id="u_role">${Object.entries(state.roles).map(([k, v]) => `<option value="${k}"${k === (u?.role || 'manager') ? ' selected' : ''}>${esc(v)} — ${esc(ROLE_HINT[k] || '')}</option>`).join('')}</select>
    <div id="u_props_wrap"><label>Какие квартиры видит собственник</label><div class="plist">${state.data.properties.map((p) => `<label class="chk"><input type="checkbox" class="u_prop" value="${p.id}"${(u?.property_ids || []).includes(p.id) ? ' checked' : ''}> ${esc(p.name)}</label>`).join('')}</div></div>
    <label>${u ? 'Новый пароль (пусто — не менять)' : 'Пароль (не короче 8 символов)'}</label><input id="u_pw" type="text" autocomplete="off">
    ${u ? `<label class="chk"><input type="checkbox" id="u_active"${u.active ? ' checked' : ''}> Доступ разрешён</label>` : ''}
    <div class="err" id="err"></div>
    <div class="btns"><button id="u_back">Назад</button><button class="primary" id="u_save">Сохранить</button></div>`);
  const sync = () => { $('u_props_wrap').hidden = $('u_role').value !== 'owner'; };
  $('u_role').onchange = sync; sync();
  $('u_back').onclick = openUsers;
  $('u_save').onclick = async () => {
    const body = { name: val('u_name'), role: val('u_role'), property_ids: [...document.querySelectorAll('.u_prop:checked')].map((c) => Number(c.value)) };
    if (val('u_pw')) body.password = val('u_pw');
    try {
      if (u) { body.active = $('u_active').checked; await api('PUT', `/api/users/${u.id}`, body); } else { body.login = val('u_login'); body.password = val('u_pw'); await api('POST', '/api/users', body); }
      toast('Сохранено'); openUsers();
    } catch (e) { setErr(e.message); }
  };
}
async function openAudit() {
  const rows = await api('GET', '/api/audit');
  openModal(`<h2>Журнал действий</h2><div class="log tall">${rows.map((r) => `<div><b>${esc(r.ts)}</b> · ${esc(r.user_name)} · ${esc(r.action)}${r.details ? ' · ' + esc(r.details) : ''}</div>`).join('') || 'Пока пусто'}</div>
    <div class="btns"><button id="a_close">Закрыть</button></div>`);
  $('a_close').onclick = closeModal;
}
function openMe() {
  openModal(`<h2>${esc(state.me.name)}</h2><div class="muted small">${esc(state.me.role_label)} · логин ${esc(state.me.login)}</div>
    <label>Текущий пароль</label><input id="m_old" type="password" autocomplete="current-password">
    <label>Новый пароль (не короче 8 символов)</label><input id="m_new" type="password" autocomplete="new-password">
    <div class="err" id="err"></div>
    <div class="btns"><button id="m_out">Выйти</button><button id="m_close">Закрыть</button><button class="primary" id="m_save">Сменить пароль</button></div>`);
  $('m_close').onclick = closeModal;
  $('m_out').onclick = async () => { await fetch('/api/logout', { method: 'POST' }); location.href = '/login.html'; };
  $('m_save').onclick = async () => { try { await api('POST', '/api/me/password', { old_password: val('m_old'), new_password: val('m_new') }); closeModal(); toast('Пароль изменён'); } catch (e) { setErr(e.message); } };
}

// ---------- статус синхронизации ----------
async function refreshStatus() {
  if (!P().prices) return;
  try {
    const s = await api('GET', '/api/sync/status');
    const pill = $('syncPill');
    pill.hidden = false;
    if (!s.configured) { pill.className = 'pill warn'; pill.textContent = 'Channex не настроен'; return; }
    pill.className = 'pill ' + (s.failed ? 'bad' : s.pending ? 'warn' : 'ok');
    pill.textContent = s.failed ? `Channex: ошибок ${s.failed}` : s.pending ? `Channex: в очереди ${s.pending}` : 'Channex ✓';
  } catch { $('syncPill').textContent = 'Нет связи'; }
}
$('syncPill').onclick = () => { if (P().channex) openChannex(); };

async function refreshAll() {
  await Promise.all([load(), refreshStatus()]);
  if (state.free) renderFreebar();
  if (state.view === 'agenda') await loadAgenda();
  if (state.view === 'list' && !document.activeElement?.closest?.('#list')) await loadList();
  if (state.view === 'report') await loadReport();
}

// ---------- навигация ----------
const shift = (n) => { state.from = addDays(state.from, n); $('jump').value = state.from; load(); };
$('prev').onclick = () => shift(-Math.floor(state.days / 2));
$('next').onclick = () => shift(Math.floor(state.days / 2));
$('todayBtn').onclick = () => { state.from = addDays(todayStr(), -2); $('jump').value = state.from; if (state.view !== 'cal') setView('cal'); load(); };
$('jump').onchange = () => { if ($('jump').value) { state.from = $('jump').value; load(); } };
$('span').onchange = () => { state.days = Number($('span').value); load(); };
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('modal').classList.contains('hidden')) return closeModal();
  if (!$('pop').hidden) { closePop(); return clearSel(); }
  if (!$('drawer').hidden) return closeDrawer();
  if (state.pending) clearSel();
});

async function start() {
  const me = await api('GET', '/api/me');
  state.me = me.user;
  state.perms = me.perms;
  state.roles = me.roles;
  state.holdTypes = me.hold_types || {};
  state.sources = me.sources || [];
  state.from = addDays(todayStr(), -2);
  $('jump').value = state.from;
  $('viewReport').hidden = !me.perms.money;
  if (innerWidth < 700) { state.days = 14; $('span').value = '14'; }
  await refreshAll();
  if (state.me.role === 'housekeeper') setView('agenda');
}
start().catch((e) => toast(e.message, true));
setInterval(() => {
  if (document.hidden || state.drag || state.sel || !$('pop').hidden || !$('modal').classList.contains('hidden')) return;
  if (state.drawer && state.drawer.type !== 'booking' && state.drawer.type !== 'hold') return;
  refreshAll().catch(() => {});
}, 30000);
